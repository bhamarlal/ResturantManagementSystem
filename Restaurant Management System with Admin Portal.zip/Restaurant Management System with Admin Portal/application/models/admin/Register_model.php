<?php
class Register_model extends CI_Model {
   public function insert($data){
    $this->db->insert('users',$data);
    $id=$this->db->insert_id();
    $this->db->select("*");
        $this->db->from("users");
        $this->db->where('id',$id);
        $query = $this->db->get()->result_array();
        return $query;

    
   }
   public function login($data){
                $password = md5($data['password']);
                $this->db->select('*');
                $this->db->from('users');
                $this->db->where('email', $data['email']);
                $this->db->where('password',$data['password']);
                $this->db->limit(1);
                $query = $this->db->get()->result_array();
                if($query){
                  return $query;
                }else{
                  return false;
                }
                
                
    
    
   }
}