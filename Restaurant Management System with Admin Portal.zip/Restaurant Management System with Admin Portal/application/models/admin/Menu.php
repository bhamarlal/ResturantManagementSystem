<?php
class Menu extends CI_Model {
   public function addMenuCategory($data){
   	$this->db->insert('menu_category',$data);
   	if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function addMenu($data){
   	$this->db->insert('menu',$data);
   	if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function editMenu($data){
    $this->db->where('id',$data['id']);
    $this->db->update('menu',$data);
   if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function deleteMenu($menu_id){
    $this->db->where('id',$menu_id);
    $this->db->delete('menu');
    if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function menuList($perPage="2",$offset = 0){
   /* $query = $this->db->select('*')->from('menu')->limit($limit,$offset)->get()->result();
    return $query;*/
    $this->db->select("*");
        $this->db->from("menu");
        $this->db->limit($perPage,$offset);
        $query = $this->db->get()->result_array();
        return $query;
    /*print_r($query);
    die;*/
   }
   public function allmenu(){
    $this->db->select("*");
    $this->db->from('menu');
    $query = $this->db->get();
    return $query;

   }
   public function menu_category_db($data){
    $this->db->where('id',$data['id']);
    $this->db->update('menu_category',$data);
   if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }

   }
   public function deleteMenuCategory($menu_cat_id){
    $this->db->where('id',$menu_cat_id);
    $this->db->delete('menu_category');
    if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }

}