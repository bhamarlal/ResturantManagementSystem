<?php
class OrderModel extends CI_Model {
   
    public function create($order){
      $this->db->insert('orders',$order);
      return $this->db->insert_id();


    }
    public function allorder(){
    	$this->db->select('*');    
		$this->db->from('orderpaymentdetail');
		$this->db->join('users', 'users.id =orderpaymentdetail.userid');
		$query = $this->db->get();
		return $query->result_array();
    }
    public function orderList($perPage="2",$offset = 0){
        $this->db->select('*');    
		$this->db->from('orderpaymentdetail');
		$this->db->join('users', 'users.id =orderpaymentdetail.userid');
		$this->db->limit($perPage,$offset);
		$query = $this->db->get();
		return $query->result_array();
    }

   }



   


