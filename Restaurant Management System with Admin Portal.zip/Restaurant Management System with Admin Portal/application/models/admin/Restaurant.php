<?php
class Restaurant extends CI_Model {
   public function addrestaurant($data){
   	$this->db->insert('restaurant',$data);
   	if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function getrestaurant($city_id){
   	$this->db->select("*");
    $this->db->from('restaurant');
    $this->db->where('city_id',$city_id);
    $query = $this->db->get()->result_array();
    
    /*echo"<pre/>";
    print_r($query);
    die;*/
    if($this->db->affected_rows() > 0){
        //return true;
        return $query;
    } else {
        return false;
    }
   }
   public function deleteRestaurant($restaurant_id){
    $this->db->where('id',$restaurant_id);
    $this->db->delete('restaurant');
    if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
  }
    public function editRestaurant($restaurant_id){
    $this->db->select("*");
    $this->db->from('restaurant');
    $this->db->where('id',$restaurant_id);
    $query = $this->db->get()->result_array();
    if($this->db->affected_rows() > 0){
        
        return $query;
    } else {
        return false;
    }
   }
   public function editRestaurantdb($data){
    $this->db->where('id',$data['id']);
    $this->db->update('restaurant',$data);
   if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }
   public function alluser(){
    $this->db->select('*');    
    $this->db->from('users');
    $query = $this->db->get();
    return $query->result_array();
   }
   public function userlist($perPage="2",$offset = 0){
    $this->db->select('*');    
    $this->db->from('users');
    $this->db->limit($perPage,$offset);
    $query = $this->db->get();
    return $query->result_array();

   }
   public function deleteUserDb($userid){
    $this->db->where('id',$userid);
    $this->db->delete('users');
    if($this->db->affected_rows() > 0){
        return true;
    } else {
        return false;
    }
   }

   



   


}