<?php
class OrderDetailModel extends CI_Model {
   
    public function create($ordersDetail){
      $this->db->insert('ordersDetail',$ordersDetail);
    }
    public function createPaymentOrder($ordersDetailPayment){
    	$this->db->insert('orderpaymentdetail',$ordersDetailPayment);
    	
    	

    }

   }



   


