<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $this->load->helper("url");
        $this->load->helper("form");
        $this->load->library('email');
        $this->load->database();
        $this->load->model('admin/Restaurant');
        $this->load->model('admin/OrderModel');
        $this->load->model('admin/OrderDetailModel');
        $this->load->library('session');
        $this->load->library('form_validation');
  		$this->load->library('encryption');
  		$this->load->model('admin/Register_model');
  	}
	public function contact()
	{
		$data["page"] = "contact";
		$this->load->view("includes/template",$data);
	}
	public function blog()
	{
		$data["page"] = "blog";
		$this->load->view("includes/template",$data);
	}
	public function restraurantMarketing()
	{
		$data["page"] = "restaurant_marketing";
		$this->load->view("includes/template",$data);
	}
	public function restraurantWebsite()
	{
		$data["page"] = "restaurant_website";
		$this->load->view("includes/template",$data);
	}
	public function about()
	{
		$data["page"] = "about";
		$this->load->view("includes/template",$data);
	}
	public function refund()
	{
		$data["page"] = "refund";
		$this->load->view("includes/template",$data);
	}
	public function termsAndServices()
	{
		$data["page"] = "terms-of-service";
		$this->load->view("includes/template",$data);
	}
	public function privacyPolicy()
	{
		$data["page"] = "privacy-policy";
		$this->load->view("includes/template",$data);
	}
	public function demoRequest()
	{
		$this->load->view('demo/index');
	}
	public function socialMedia()
	{
		$data["page"] = "socialmedia";
		$this->load->view("includes/template",$data);
	}
	public function customerDataRestaurant()
	{
		$data["page"] = "customer-data-restaurant-success";
		$this->load->view("includes/template",$data);
	}
	public function emailMarketing()
	{
		$data["page"] = "Email-Marketing-Made-Easy-for-Restaurants";
		$this->load->view("includes/template",$data);
	}
	public function restaurantAppGuide()
	{
		$data["page"] = "restaurateurs-guide-custom-mobile-apps";
		$this->load->view("includes/template",$data);
	}
	public function chosingOnlineOrder()
	{
		$data["page"] = "Choosing-an-Online-Ordering-Partner";
		$this->load->view("includes/template",$data);
	}
	public function socialMediaGuide()
	{
		$data["page"] = "Ultimate-Guide-to-Social-Media-for-Restaurants";
		$this->load->view("includes/template",$data);
	}
	public function capricing()
	{
		$data["page"] = "ca/pricing";
		$this->load->view("includes/template",$data);
	}
	public function seeUsdPrice()
	{
		$data["page"] = "pricing11ea";
		$this->load->view("includes/template",$data);
	}
	public function clientSpotLight()
	{
		$data["page"] = "category/client-spotlight/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function clientStory()
	{
		$data["page"] = "category/client-story/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function howTo()
	{
		$data["page"] = "category/how-to/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function theNews()
	{
		$data["page"] = "category/in-the-news/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function marketingBlog()
	{
		$data["page"] = "category/marketing/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function mobileBlog()
	{
		$data["page"] = "category/mobile/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function onlineBlog()
	{
		$data["page"] = "category/online-ordering-system-2/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function restaurantBlog()
	{
		$data["page"] = "category/restaurant-tech/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function socialMediaBlog()
	{
		$data["page"] = "category/social-media/index";
		$this->load->view("includes/blogtemplate",$data);
	}
	public function marketplacesEating()
	{
		$data["page"] = "blog/how-marketplaces-are-eating-away-at-your-restaurants-bottom-line/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function appleDeveloperProgram()
	{
		$data["page"] = "blog/how-to-enroll-apple-developer-program-canada/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function restaurantCafe()
	{
		$data["page"] = "restaurant-spotlight-how-cafe-gratitude-los-angeles-gives-thanks";
		$this->load->view("includes/posttemplate",$data);
	}
	public function celebratingDayofDead()
	{
		$data["page"] = "blog/celebrating-day-of-the-dead-at-toca-madera/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function backToSchool()
	{
		$data["page"] = "blog/back-to-school-in-the-kitchen-with-three-chefs";
		$this->load->view("includes/posttemplate",$data);
	}
	public function sevenBestSeasonalFood()
	{
		$data["page"] = "blog/seven-best-seasonal-foods-eat-in-los-angeles";
		$this->load->view("includes/posttemplate",$data);
	}
	public function onlineFoodDelevery()
	{
		$data["page"] = "blog/how-seamlessly-online-food-delivery-platforms-are-taking-restaurants-orders/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function onlineOrderCaseStudy()
	{
		$data["page"] = "blog/online-ordering-case-study-Two-Boots";
		$this->load->view("includes/posttemplate",$data);
	}
	public function chownowClientStory()
	{
		$data["page"] = "blog/chownow-client-story-xoco";
		$this->load->view("includes/posttemplate",$data);
	}
	public function howToWinBackCustomerProfit()
	{
		$data["page"] = "blog/how-to-win-back-your-customers-and-profits-from-grubhub/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function runingRestaurantMarketing()
	{
		$data["page"] = "blog/running-restaurant-marketing-promotions";
		$this->load->view("includes/posttemplate",$data);
	}
	public function introducingInstagramOrder()
	{
		$data["page"] = "blog/order-food-on-instagram-with-chownow";
		$this->load->view("includes/posttemplate",$data);
	}
	public function howToCreateSecreteMenu()
	{
		$data["page"] = "blog/how-to-create-a-secret-menu";
		$this->load->view("includes/posttemplate",$data);
	}
	public function instagramGuide()
	{
		$data["page"] = "blog/instagram-guide-for-restaurants";
		$this->load->view("includes/posttemplate",$data);
	}
	public function restaurantNeedsAdvantage()
	{
		$data["page"] = "blog/why-your-restaurant-needs-to-take-advantage-of-customer-data/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function createGoogleBusiness()
	{
		$data["page"] = "blog/create-your-restaurants-google-my-business-page";
		$this->load->view("includes/posttemplate",$data);
	}
	public function promoteOnlineOrder()
	{
		$data["page"] = "blog/4-ways-to-promote-online-ordering";
		$this->load->view("includes/posttemplate",$data);
	}
	public function howToConvertOnlineeSearch()
	{
		$data["page"] = "blog/how-to-convert-online-search-customers";
		$this->load->view("includes/posttemplate",$data);
	}
	public function launchYourRestaurant()
	{
		$data["page"] = "blog/launch_your_restaurant_carryout_and_delivery_business";
		$this->load->view("includes/posttemplate",$data);
	}
	public function restaurantKillingDelivery()
	{
		$data["page"] = "blog/restaurant-delivery-killing-restaurants";
		$this->load->view("includes/posttemplate",$data);
	}
	public function increaseEngagementOnline()
	{
		$data["page"] = "blog/increase-engagement-online-with-restaurant-messaging-tools/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function springMarketnigPromotion()
	{
		$data["page"] = "blog/spring-marketing-promotions-for-your-restaurant";
		$this->load->view("includes/posttemplate",$data);
	}
	public function ultimateSnapChat()
	{
		$data["page"] = "blog/ultimate-snapchat-guide-for-restaurants";
		$this->load->view("includes/posttemplate",$data);
	}
	public function viewYourPlans()
	{
		$data["page"] = "restaurant-websites/index";
		$this->load->view("includes/posttemplateheader",$data);
	}
	public function login()
	{
		/*$data["page"] = "login/index";
		$this->load->view("includes/posttemplateheader",$data);*/
		$this->load->view('eat.chownow.com/discover/userlogin');
	}
	public function loginpage()
	{
		$this->load->view('admin.chownow.com/admin/login');
	}
	public function whyYouNeddOnlineOrder()
	{
		$data["page"] = "blog/why-you-need-an-online-food-ordering-system-for-your-restaurant/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function enrollAppleDeveloperProgram()
	{
		$data["page"] = "blog/how-to-enroll-apple-developer-program/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function authorselena()
	{
		$data["page"] = "author/selena/index";
		$this->load->view("includes/posttemplate",$data);
	}
	public function eatnow()
	{
		$query = $this->db->select('*')
                  ->from('restaurant')
                  ->join('cities', 'cities.city_idd = restaurant.city_id')
                  ->group_by('city_idd')->distinct()
                  ->get();
                  $data['cities']=$query->result_array();
                 $this->load->view('eat.chownow.com/discover/eat',$data);
	}
	public function sendemail(){
		$from_email = "bhamarlaltogani98@gmail.com"; 
        $to_email ="bhamarlaltogani98@gmail.com"; //$this->input->post('email'); 
   		$this->load->library('email'); 
        $this->email->from($from_email, 'bhamar'); 
        $this->email->to($to_email);
        $this->email->subject('Email Test'); 
        $this->email->message('Testing the email class.');
        $this->email->send();
	}
	public function viewRestaurantsPage(){
		$this->db->select('*');
    	$this->db->from('restaurant');
    	$query = $this->db->get();
    	$data['restaurant']=$query->result_array();
 		$this->load->view('eat.chownow.com/discover/search',$data);
	}
	public function orderSchedule(){
		$restaurant_id =$this->uri->segment(3);
		$this->db->select('*');
        $this->db->from('restaurant');
        $this->db-> where('id', $restaurant_id);
        $query = $this->db->get();
        $data['restaurant']=$query->result_array();
		$this->load->view('eat.chownow.com/discover/order_schedule',$data);
	}
	public function scheduletime(){
		$rid =$this->uri->segment(3);
		$data['schedule'] = array(
        'selectedDate'=>$this->input->post('selectedDateOption'),
        'selectedTime'=>$this->input->post('selectedTimeOption')
        );
        $_SESSION['selectedDate']=$this->input->post('selectedDateOption');
        $_SESSION['selectedTime']=$this->input->post('selectedTimeOption');
		$this->db->select('*');
        $this->db->from('restaurant');
        $this->db-> where('id', $rid);
        $query = $this->db->get();
        $data['restaurant']=$query->result_array();
       	$query = $this->db->select('*')
                  ->from('menu_category')
                  ->where('restaurant_id', $rid)
                  ->get();
                  $data['menu_cat']=$query->result_array();
                  if($data['menu_cat']){
                  	foreach($data['menu_cat'] as $val){
                  	$ids=$val['id'].",";
                  	$array[] = $ids;
                }
                   	$i=implode($array);
                 	$catid=rtrim($i,',');
                  	$query=$this->db->query('SELECT * FROM menu WHERE menu_category_id IN('.$catid.')');
                  	$data['menu']=$query->result_array();
                }
                  	$this->load->view('eat.chownow.com/discover/menucart',$data);
	}
	public function searchmenu(){
		$this->db->select('*');
        $this->db->from('menu');
        $query = $this->db->get();
        $data['menu']=$query->result_array();
        $this->load->view('eat.chownow.com/discover/searchrestaurant',$data);
	}
	public function getparticularrestaurant(){
		$menucatid =$this->uri->segment(3);
		$query = $this->db->select('id,restaurant_id')
                ->from('menu_category')
                ->where('id', $menucatid)
                ->get();
                $data['menu_cat']=$query->result_array();
                $rid=$data['menu_cat']['0']['restaurant_id'];
                $query = $this->db->select('id,name,description,time')
                ->from('restaurant')
                ->where('id', $rid)
                ->get();
                $data['restaurant']=$query->result_array();
				$this->load->view('eat.chownow.com/discover/viewparticularrestaurant',$data);
	}
	public function getmenu(){
		$mcatid =$this->uri->segment(3);
		$query = $this->db->select('id,restaurant_id')
                  ->from('menu_category')
                  ->where('id', $mcatid)
                  ->get();
                  $data['menu_cat']=$query->result_array();
                  $rid=$data['menu_cat']['0']['restaurant_id'];
                  $query = $this->db->select('*')
                  ->from('restaurant')
                  ->where('id', $rid)
                  ->get();
                  $data['restaurant']=$query->result_array();
                  $this->load->view('eat.chownow.com/discover/order_schedule',$data);
    }
	public function getRestaurant(){
        $city_id =$this->uri->segment(3);
        $data['restaurant']=$this->Restaurant->getrestaurant($city_id);
       	$this->load->view('eat.chownow.com/discover/search',$data);  
    }
    public function getcartitem(){
    	$menuid = $this->input->post('menuid');
    	$this->db->select('*');
        $this->db->from('menu');
        $this->db-> where('id', $menuid);
        $query = $this->db->get();
        $data['menu']=$query->result_array();
        $dataa   = "";
        foreach($data['menu'] as $val){
        	$dataa.='<span id="menuid" style="display:none;">'.$val['id'].'</span>';
        	$dataa.='<div style="position: relative; height: 100%;"  ><div class="_3ljYJ"><div class="_1UsCm"><a class="_2rG1g _2B15f">
        			<span id="cartid" class="isvg loaded"><svg xmlns="www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17">
    				<g  fill="none" fill-rule="evenodd" stroke="#0B2135" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5">
        			<path d="M.835 15.529L7.5 8.863M10.366 6.065l4.847-4.848M15.165 15.529L.835 1.198"></path>
    				</g>
					</svg>
					</span></a><div class="mnzrP"><h4 id="menuname">'.$val['menu_name'].'</h4><p class="_2CZqL" id="menudescription">'.$val['menu_description'].'</p></div><div class="_1iN66"><h5 class="_27QHW">.</h5></div></div><div class="u48W4"><div class="_2wlcU"><a class="_4EGTH _2bsro"><span class="isvg loaded">
					<svg width="32px" height="32px" viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
   					</svg></span></a><input type="number" min="0" id="quantity" class="_3yVbJ" value="1"><a class="_2Hiyu"><span class="isvg loaded">
					<svg width="32px" height="32px" viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    				</svg></span></a></div><button class="_2jjjt _2o_iK _2BP2c _3bRlB _2x5M6 _2uOCG" ><span class="_2SE-l" id="external">Add to Cart</span><span id="menuprice">'.$val['menu_price'].'</span></button></div></div></div>';
    	}
        header('Content-Type: application/json');
        echo json_encode($dataa);
        
    }
    public function addtocart(){
    	$this->load->library("cart");
    	$data = array(
   			"id"  => $_POST["menuid"],
   			"name"  => $_POST["menuname"],
   			"qty"  => $_POST["quantity"],
   			"price"  => $_POST["menuprice"]
  		);
  		$this->cart->insert($data);
  		echo $this->view();
   }
 function view()
 {
  $this->load->library("cart");
  $output = '';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   		$count++;
   		$output .= '<ul class="gItfW">
    	<li class="_2Shjg">
    		<div class="_2nPNq">'.$items["qty"].'</div>
		    		<div class="S76YM">
		    			<h4 class="_1TgoR">'.$items["name"].'</h4>
		    		</div>
		    	<div class="WfReY">
		    	
		    	<div class="_1c-wW">'.$items["subtotal"].'</div>
		    	<div class="_28vGr"><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Remove</button></div>
		  	</div>
		  </li>
		</ul>';
  }
  		$output .= '
 		</div>
  		<ul class="_2MIYm"><li class="_3emWo"><h6 class="FobyI">Subtotal</h6><span class="_3daJt">'.$this->cart->total().'</span></li><li class="_3emWo"></li><div class="_2Ghso"><h4 class="_3nlzc">Total</h4><span class="_1h0XJ">'.$this->cart->total().'</span></div></ul>
  		';
  		$output.='<div class="_2eHs0">
                            <div class="_36AsU _2Xjxj"></div>
                            <a href="http://localhost/DumyCi/UserController/checkout"><button class="_2jjjt _2Va97 _2x5M6 _3bRlB _2BP2c _2uOCG">
                                <div class="_1YZNL">Checkout ('.count($this->cart->contents()).' ITEM)</div><span>'.$this->cart->total().'</span></button></a>
                            
                        </div>';

  		if($count == 0)
  		{
   			$output = '<div class="_1Y2xR"><h5 class="_1ixw1">Choose an item from the menu to get started.</h5><img src="https://cf.chownowcdn.com/marketplace-react-prod/static/media/bag-illustration.6a7e5e50.svg" alt="empty cart" class="_3Meei"></div>';
  		}
  			return $output;
}
 function remove()
 {
  $this->load->library("cart");
  $row_id = $_POST["row_id"];
  $data = array(
   'rowid'  => $row_id,
   'qty'  => 0
  );
  $this->cart->update($data);
  echo $this->view();
 }
 public function checkout(){
 	$this->load->library("cart");
 	if($this->session->userdata('fname')== null){
 		$this->load->view('eat.chownow.com/discover/userlogin');
 		
 	}else{
 		if(isset($_SESSION['selectedDate'])){
 			$order=array(
 			'name'=>'new order',
 			'orderdate'=>date('Y-m-d'),
 			'schedule'=>($_SESSION['selectedDate']." ".$_SESSION['selectedTime']),
 			'status'=>0,
 			'userid'=>$this->session->userdata('id')
 		);
 		}else{
 			$order=array(
 			'name'=>'new order',
 			'orderdate'=>date('Y-m-d'),
 			'schedule'=>'schedule is cant selected',
 			'status'=>0,
 			'userid'=>$this->session->userdata('id')
 		);
 		}
 		
 		$orderId=$this->OrderModel->create($order);
 		$_SESSION['ordersid']=$orderId;

 		foreach($this->cart->contents() as $items){
 			$ordersDetail=array(
 				'productid'=>$items['id'],
 				'ordersid'=>$orderId,
 				'price'=>$items['price'],
 				'quantity'=>$items['qty'],

 			);
 			$this->OrderDetailModel->create($ordersDetail);
 		}
 			redirect('UserController/placeholder');
 	}	

}
public function Register(){
	$this->load->view('eat.chownow.com/discover/userregister');
}
public function UserLogin(){
	$this->load->view('eat.chownow.com/discover/userlogin');
}
public function registerdb(){
	$this->load->library("cart");
	$this->form_validation->set_rules('fname', 'fname', 'required|trim');
  	$this->form_validation->set_rules('lname', 'lname', 'required|trim');
  	$this->form_validation->set_rules('fnumber', 'fnumber', 'required|trim');
  	$this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
  	$this->form_validation->set_rules('password', 'password', 'required');
  if($this->form_validation->run())
  {
  	$verification_key = md5(rand());
   $encrypted_password = md5($this->input->post('password'));
   $data = array(
    'fname'  => $this->input->post('fname'),
    'lname'  => $this->input->post('lname'),
    'phone_number'  => $this->input->post('fnumber'),
    'email'  => $this->input->post('email'),
    'password' =>$encrypted_password,
    'verification_key' => $verification_key,
    'roll'=>0
    );
   $result = $this->Register_model->insert($data);
   foreach($result as $key=>$row){
   	$data = array(
          'id'           => $row['id'],
          'fname'        => $row['fname'],
          'lname'      => $row['lname'],
          'fnumber'=>$row['phone_number'],
          'email'=>$row['email'],
          'password'=>$row['password'],
          'roll'=>$row['roll']
        );
   }
   $this->session->set_userdata($data);
   		if(count($this->cart->contents())>0){
   			redirect('UserController/checkout');
   		}else{
   			
   			redirect('UserController/eatnow');
   		}
        
   
	}else{
		$data['error'] = validation_errors();
		$this->load->view('eat.chownow.com/discover/userregister',$data);
	}

}
public function loginuser(){
	$this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
  	$this->form_validation->set_rules('password', 'password', 'required');
  	if($this->form_validation->run()){
  		$verification_key = md5(rand());
 		$encrypted_password = md5($this->input->post('password'));
   		$data = array(
    		'email'  => $this->input->post('email'),
    		'password'  =>$encrypted_password
    	);
    	$result = $this->Register_model->login($data);
    	if($result){
    		foreach($result as $key=>$row){
		   	$data = array(
		          'id'           => $row['id'],
		          'fname'        => $row['fname'],
		          'lname'      => $row['lname'],
		          'fnumber'=>$row['phone_number'],
		          'email'=>$row['email'],
		          'password'=>$row['password'],
		          'roll'=>$row['roll']
		        );
   	
   		}
   
   $this->session->set_userdata($data);
        redirect('UserController/checkout');
   
}else{
	$data['errorinvalid'] ="Unvalid user name or password";
	$this->load->view('eat.chownow.com/discover/userlogin',$data);
	
}
    	}else{
	$data['error'] = validation_errors();
	$this->load->view('eat.chownow.com/discover/userlogin',$data);

    	

  	}
  	
}
public function placeholder(){
	$this->load->library("cart");
	if($this->session->flashdata('success')){
	$ordersDetailPayment=array(
 				'orderid'=>$_SESSION['ordersid'],
 				'userid'=>$this->session->userdata('id'),
 				'totalamount'=>$this->cart->total(),
 				'payment_status'=>'success'

 			);
 			$this->OrderDetailModel->createPaymentOrder($ordersDetailPayment);
}
	
  $output['output'] = '';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   $count++;
   $output['output'] .= '<ul class="gItfW">
    	<li class="_2Shjg">
    		<div class="_2nPNq">'.$items["qty"].'</div>
		    		<div class="S76YM">
		    			<h4 class="_1TgoR">'.$items["name"].'</h4>
		    		</div>
		    	<div class="WfReY">
		    	
		    	<div class="_1c-wW">'.$items["subtotal"].'</div>
		    	<div class="_28vGr"><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory_item" id="'.$items["rowid"].'">Remove</button></div>
		  	</div>
		  </li>
		</ul>';
  }
  
  $output['output'].='<ul class="_2MIYm"><li class="_3emWo"><h6 class="FobyI">Subtotal</h6><span class="_3daJt">'.$this->cart->total().'</span></li><li class="_3emWo"></li><div class="_2Ghso"><h4 class="_3nlzc">Total</h4><span class="_1h0XJ">'.$this->cart->total().'</span></div></ul>';
  if($count == 0)
  {
   $output['output'] = '<div class="_1Y2xR"><h5 class="_1ixw1">Choose an item from the menu to get started.</h5><img src="https://cf.chownowcdn.com/marketplace-react-prod/static/media/bag-illustration.6a7e5e50.svg" alt="empty cart" class="_3Meei"></div>';
  }
  
	$this->load->view('eat.chownow.com/discover/placeorder',$output);
}
public function removeorderitem(){
	$this->load->library("cart");
  	$row_id = $_POST["row_id"];
  	$data = array(
   'rowid'  => $row_id,
   'qty'  => 0
  );
  $this->cart->update($data);
  echo $this->vieworderitem();
}
public function vieworderitem(){
	$this->load->library("cart");
  $output = '';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   $count++;
   $output .= '<ul class="gItfW">
    	<li class="_2Shjg">
    		<div class="_2nPNq">'.$items["qty"].'</div>
		    		<div class="S76YM">
		    			<h4 class="_1TgoR">'.$items["name"].'</h4>
		    		</div>
		    	<div class="WfReY">
		    	
		    	<div class="_1c-wW">'.$items["subtotal"].'</div>
		    	<div class="_28vGr"><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Remove</button></div>
		  	</div>
		  </li>
		</ul>';
  }
  $output.='</div>
  <ul class="_2MIYm"><li class="_3emWo"><h6 class="FobyI">Subtotal</h6><span class="_3daJt">'.$this->cart->total().'</span></li><li class="_3emWo"></li><div class="_2Ghso"><h4 class="_3nlzc">Total</h4><span class="_1h0XJ">'.$this->cart->total().'</span></div></ul>
  ';
  

  if($count == 0)
  {
   $output = '<div class="_1Y2xR"><h5 class="_1ixw1">Choose an item from the menu to get started.</h5><img src="https://cf.chownowcdn.com/marketplace-react-prod/static/media/bag-illustration.6a7e5e50.svg" alt="empty cart" class="_3Meei"></div>';
  }
  return $output;
}
public function logout(){
	session_destroy();
	
	redirect('UserController/eatnow');

}
}


