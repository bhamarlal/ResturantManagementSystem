<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $this->load->helper("url");
        $this->load->database();
        $this->load->model('admin/OrderModel');
        $this->load->model('admin/Restaurant');
        $this->load->model('admin/Menu');
        $this->load->library('session');
        
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data["page"] = "admin/index";
		$this->load->view("admin/includes/template",$data);
	}
	public function menuOne()
	{
		$data["page"] = "admin/restaurant-menu-one";
		$this->load->view("admin/includes/template",$data);
	}
	public function menuTwo()
	{
		$data["page"] = "admin/restaurant-menu-two";
		$this->load->view("admin/includes/template",$data);
	}
	public function menuThree()
	{
		$data["page"] = "admin/restaurant-menu-three";
		$this->load->view("admin/includes/template",$data);
	}
	public function restaurantFavouriteList()
	{
		$data["page"] = "admin/restaurant-favourite-list";
		$this->load->view("admin/includes/template",$data);
	}
	public function restaurantOrderList()
	{
    
		$offset = $this->uri->segment(4);
    	$data["order"] = $this->OrderModel->allorder();
    	$perPage = 4;
      $this->load->library('pagination');
      $config['base_url'] =     site_url("admin/Welcome/restaurantOrderList");
      $config['total_rows'] =   $this->db->count_all('orderpaymentdetail');
      $config['per_page'] =     $perPage;
      $config['full_tag_open'] =  "<ul class='pagination'>";
      $config['full_tag_close'] = "</ul>";
      $config['next_tag_open']  =  "<li>";
      $config['next_tag_close']  =  "</li>";
      $config['prev_tag_open']  =  "<li>";
      $config['prev_tag_close']  =  "</li>";
      $config['num_tag_open']   =  "<li>";
      $config['num_tag_close']    =  "</li>";
      $config['cur_tag_open']   = "<li class='active'><a>";
      $config['cur_tag_close'] =    "</a></li>";
      $config['last_link'] = "Last";
      $config['last_tag_open'] = "<li id='link'>";
      $config['last_tag_close'] = "</li>";
      $config['first_link'] = "First";
      $config['first_tag_open'] = "<li id='link'>";
      $config['first_tag_close'] = "</li>";
      $this->pagination->initialize($config);
      $data["orders"] = $this->OrderModel->orderList($perPage,$offset);
      $data["page"] = "admin/restaurant-order-list";
		$this->load->view("admin/includes/template",$data);
	}
	public function restaurantBooking()
	{
		$data["page"] = "admin/restaurant-booking";
		$this->load->view("admin/includes/template",$data);
	}
	public function restaurantUploadMenu()
	{
		$data["page"] = "admin/restaurant-upload-menu";
		$this->load->view("admin/includes/template",$data);
	}
	public function getorderdetail(){
		$orderid = $this->uri->segment(4);
		$this->db->select('Orders.*,ordersdetail.*,menu.*');
		$this->db->from('orders');
		$this->db->join('ordersdetail','orders.id=ordersdetail.ordersid');
		$this->db->join('menu','ordersdetail.productid =menu.id');
		$this->db->where('orders.id',$orderid);
		$query=$this->db->get();
		$data['orderdetail']= $query->result_array();
		$data["page"] = "admin/single-order-list";
		$this->load->view("admin/includes/template",$data);

	}
	public function viewrestaurant(){
		$this->db->select('*');
		$this->db->from('restaurant');
		$this->db->join('cities','restaurant.city_id=cities.city_idd');
		$query=$this->db->get();
		$data['restaurant']= $query->result_array();
		$data["page"] = "admin/restaurant-list";
		$this->load->view("admin/includes/template",$data);
	}
	public function deleteRestaurant(){
    $restaurant_id =$this->uri->segment(4);
    
     $result=$this->Restaurant->deleteRestaurant($restaurant_id);
     if($result){
            $this->session->set_flashdata('msg', 'Restaurant Delete Successfully');
            redirect('admin/Welcome/viewrestaurant');
        } else {
            $this->session->set_flashdata('msg', 'Restaurant can not Delete');
            redirect('admin/Welcome/viewrestaurant');
            
        }
   }
   public function editRestaurant(){
   		$restaurant_id =$this->uri->segment(4);
   		$this->db->select('*');
        $this->db->from('restaurant');
        $this->db-> where('id', $restaurant_id);
        $query = $this->db->get();
        $data['restaurant']=$query->result_array();
   		$data["page"] = "admin/editRestaurant";
		$this->load->view("admin/includes/template",$data);
   	

   }
   public function editRestaurantDb(){
   	
   	if(isset($_FILES['cityImage']['name']) && !empty($_FILES['cityImage']['name'])){
      $errors= array();
      $file_name = $_FILES['cityImage']['name'];
      $file_size =$_FILES['cityImage']['size'];
      $file_tmp =$_FILES['cityImage']['tmp_name'];
      $file_type=$_FILES['cityImage']['type'];
      $tmp = explode('.', $file_name);
        $file_ext = end($tmp);
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"admin/assets/uploads/".$file_name);
         $data = array(
        'city_image'=>$file_name,
        'name'=>$this->input->post('restaurantName'),
        'description'=>$this->input->post('restaurantDescription'),
        'time'=>$this->input->post('restaurantTime'),
        'id'=>$this->input->post('rid')
        );
        $result=$this->Restaurant->editRestaurantdb($data);
        if($result){
            $this->session->set_flashdata('emsg', 'Restaurant Updated Successfully');
            redirect('admin/Welcome/viewrestaurant');
            
        } else {
            $this->session->set_flashdata('emsg', 'Restaurant can not Update');
            redirect('admin/Welcome/viewrestaurant');
            
        }
      }else{
         print_r($errors);
      }
   }else{
      $data = array(
        'name'=>$this->input->post('restaurantName'),
        'description'=>$this->input->post('restaurantDescription'),
        'time'=>$this->input->post('restaurantTime'),
        'id'=>$this->input->post('rid')
        );
        $result=$this->Restaurant->editRestaurantdb($data);
        if($result){
            $this->session->set_flashdata('emsg', 'Restaurant Updated Successfully');
            redirect('admin/Welcome/viewrestaurant'); 
        } else {
            $this->session->set_flashdata('emsg', 'Restaurant can not Update');
            redirect('admin/Welcome/viewrestaurant');
            
        }
   }
   }
   public function view_menu_category(){
    $this->db->select('*');
        $this->db->from('menu_category');
        $query = $this->db->get();
        $data['menucategory']=$query->result_array();
      $data["page"] = "admin/viewmenucategory";
    $this->load->view("admin/includes/template",$data);
   }
   public function edit_menu_category(){
    $menu_cat_id =$this->uri->segment(4);
    $this->db->select('*');
        $this->db->from('menu_category');
        $this->db-> where('id', $menu_cat_id);
        $query = $this->db->get();
        $data['menuCategory']=$query->result_array();
      $data["page"] = "admin/editMenuCategory";
    $this->load->view("admin/includes/template",$data);
   }
   public function edit_menu_category_db(){
    $data = array(
        'name'=>$this->input->post('menuCategoryName'),
        'id'=>$this->input->post('menuid')
        );
        $result=$this->Menu->menu_category_db($data);
        if($result){
            $this->session->set_flashdata('msg', 'Menu Category Updated Successfully');
            redirect('admin/Welcome/view_menu_category'); 
        } else {
            $this->session->set_flashdata('msg', 'Menu Category can not Update');
            redirect('admin/Welcome/view_menu_category');
            
        }
   }
   public function delete_menu_category(){
    $menu_cat_id =$this->uri->segment(4);
    $result=$this->Menu->deleteMenuCategory($menu_cat_id);
     if($result){
            $this->session->set_flashdata('dmsg', 'Menu Category Delete Successfully');
            redirect('admin/Welcome/view_menu_category');
        } else {
            $this->session->set_flashdata('dmsg', 'Menu Category can not Delete');
            redirect('admin/Welcome/view_menu_category');
            
        }
   }
   public function users(){
    $offset = $this->uri->segment(4);
      $data["user"] = $this->Restaurant->alluser();
      $perPage = 4;
      $this->load->library('pagination');
      $config['base_url'] =     site_url("admin/Welcome/users");
      $config['total_rows'] =   $this->db->count_all('users');
      $config['per_page'] =     $perPage;
      $config['full_tag_open'] =  "<ul class='pagination'>";
      $config['full_tag_close'] = "</ul>";
      $config['next_tag_open']  =  "<li>";
      $config['next_tag_close']  =  "</li>";
      $config['prev_tag_open']  =  "<li>";
      $config['prev_tag_close']  =  "</li>";
      $config['num_tag_open']   =  "<li>";
      $config['num_tag_close']    =  "</li>";
      $config['cur_tag_open']   = "<li class='active'><a>";
      $config['cur_tag_close'] =    "</a></li>";
      $config['last_link'] = "Last";
      $config['last_tag_open'] = "<li id='link'>";
      $config['last_tag_close'] = "</li>";
      $config['first_link'] = "First";
      $config['first_tag_open'] = "<li id='link'>";
      $config['first_tag_close'] = "</li>";
      $this->pagination->initialize($config);
      $data["users"] = $this->Restaurant->userlist($perPage,$offset);
      $data["page"] = "admin/restaurant-users-list";
    $this->load->view("admin/includes/template",$data);

   }
   public function deleteUser(){
    $userid =$this->uri->segment(4);
    $result=$this->Restaurant->deleteUserDb($userid);
     if($result){
            $this->session->set_flashdata('msg', 'User Delete Successfully');
            redirect('admin/Welcome/users');
        } else {
            $this->session->set_flashdata('msg', 'User can not Delete');
            redirect('admin/Welcome/users');
            
        }
   }
	
}
