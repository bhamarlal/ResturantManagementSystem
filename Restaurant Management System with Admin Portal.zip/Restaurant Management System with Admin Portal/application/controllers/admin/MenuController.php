<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MenuController extends CI_Controller {
	public function __construct(){
        parent::__construct();
        
        $this->load->helper("url");
        $this->load->database();
        $this->load->model('admin/Menu');
        $this->load->library("session");
        //$this->load->library('pagination');
        
        
    }
	public function index()
	{
		$this->db->select('*');
    	$this->db->from('restaurant');
    	$query = $this->db->get();
    	$data['restaurant']=$query->result_array();
		$data["page"] = "admin/Menu/addMenuCategory";
		$this->load->view("admin/includes/template",$data);
	}
    public function addMenuCategory(){
        $data = array(
        'name'=>$this->input->post('menuCategoryName'),
        'restaurant_id'=>$this->input->post('restaurantName')
        );
        $result=$this->Menu->addMenuCategory($data);
        if($result){
            $this->session->set_flashdata('msg', 'Menu Category added Successfully');
            redirect('admin/MenuController/index');
        } else {
            $this->session->set_flashdata('msg', 'Menu Category can not added');
            redirect('admin/MenuController/index');
        }
        
    }
    public function addMenu(){
        $this->db->select('*');
        $this->db->from('menu_category');
        $query = $this->db->get();
        $data['menuCategory']=$query->result_array();
        $data["page"] = "admin/Menu/addMenu";
        $this->load->view("admin/includes/template",$data);
    }
    public function addMenuDb(){
    if(isset($_FILES['menuImage'])){
      $errors= array();
      $file_name = $_FILES['menuImage']['name'];
      $file_size =$_FILES['menuImage']['size'];
      $file_tmp =$_FILES['menuImage']['tmp_name'];
      $file_type=$_FILES['menuImage']['type'];
      $tmp = explode('.', $file_name);
        $file_ext = end($tmp);
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"admin/assets/uploads/".$file_name);
         $data = array(
        'menu_image'=>$file_name,
        'menu_name'=>$this->input->post('menuName'),
        'menu_description'=>$this->input->post('menuDescription'),
        'menu_category_id'=>$this->input->post('menuCategory'),
        'menu_price'=>$this->input->post('menuPrice')
        );
        $result=$this->Menu->addMenu($data);
        if($result){
            $this->session->set_flashdata('msg', 'Menu added Successfully');
            redirect('admin/MenuController/addMenu');
        } else {
            $this->session->set_flashdata('msg', 'Menu can not added');
            redirect('admin/MenuController/addMenu');
            
        }
      }else{
         print_r($errors);
      }
   }

 }
 public function viewMenu(){
  $offset = $this->uri->segment(4);
    $data["menu"] = $this->Menu->allmenu();
    $perPage = 8;
      $this->load->library('pagination');
      $config['base_url'] =     site_url("admin/MenuController/viewMenu");
      $config['total_rows'] =   $this->db->count_all('menu');
      $config['per_page'] =     $perPage;
      $config['full_tag_open'] =  "<ul class='pagination'>";
      $config['full_tag_close'] = "</ul>";
      $config['next_tag_open']  =  "<li>";
      $config['next_tag_close']  =  "</li>";
      $config['prev_tag_open']  =  "<li>";
      $config['prev_tag_close']  =  "</li>";
      $config['num_tag_open']   =  "<li>";
      $config['num_tag_close']    =  "</li>";
      $config['cur_tag_open']   = "<li class='active'><a>";
      $config['cur_tag_close'] =    "</a></li>";
      $config['last_link'] = "Last";
      $config['last_tag_open'] = "<li id='link'>";
      $config['last_tag_close'] = "</li>";
      $config['first_link'] = "First";
      $config['first_tag_open'] = "<li id='link'>";
      $config['first_tag_close'] = "</li>";
      $this->pagination->initialize($config);
      $data["menu"] = $this->Menu->menuList($perPage,$offset);
      $data["page"] = "admin/Menu/viewMenu";
      $this->load->view("admin/includes/template",$data);
   }
   public function editMenu(){
    
    $menu_id =$this->uri->segment(4);
    $this->db->select('*');
        $this->db->from('menu');
        $this->db-> where('id', $menu_id);
        $query = $this->db->get();
        $data['menu']=$query->result_array();
        $this->db->select('*');
        $this->db->from('menu_category');
        $query = $this->db->get();
        $data['menu_category']=$query->result_array();
        $data["page"] = "admin/Menu/editMenu";
        $this->load->view("admin/includes/template",$data); 

   }
   public function editMenuDb(){
    if(isset($_FILES['menupic']['name']) && !empty($_FILES['menupic']['name'])){
      $errors= array();
      $file_name = $_FILES['menupic']['name'];
      $file_size =$_FILES['menupic']['size'];
      $file_tmp =$_FILES['menupic']['tmp_name'];
      $file_type=$_FILES['menupic']['type'];
      $tmp = explode('.', $file_name);
        $file_ext = end($tmp);
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"admin/assets/uploads/".$file_name);
         $data = array(
        'menu_image'=>$file_name,
        'menu_name'=>$this->input->post('menuName'),
        'menu_description'=>$this->input->post('menuDescription'),
        'menu_category_id'=>$this->input->post('menuCategory'),
        'menu_price'=>$this->input->post('menuPrice'),
        'id'=>$this->input->post('menuid')
        );
        $result=$this->Menu->editMenu($data);
        if($result){
            $this->session->set_flashdata('msg', 'Menu Updated Successfully');
            redirect('admin/MenuController/editMenu');
            
        } else {
            $this->session->set_flashdata('msg', 'Menu can not Update');
            redirect('admin/MenuController/editMenu');
            
        }
      }else{
         print_r($errors);
      }
   }else{
      $data = array(
        
        'menu_name'=>$this->input->post('menuName'),
        'menu_description'=>$this->input->post('menuDescription'),
        'menu_category_id'=>$this->input->post('menuCategory'),
        'menu_price'=>$this->input->post('menuPrice'),
        'id'=>$this->input->post('menuid')
        );
        $result=$this->Menu->editMenu($data);
        if($result){
            $this->session->set_flashdata('msg', 'Menu Updated Successfully');
            redirect('admin/MenuController/editMenu'); 
        } else {
            $this->session->set_flashdata('msg', 'Menu can not Update');
            redirect('admin/MenuController/editMenu');
            
        }
   }
   }
   public function deleteMenu(){
     $menu_id =$this->uri->segment(4);
     $result=$this->Menu->deleteMenu($menu_id);
     if($result){
            $this->session->set_flashdata('msg', 'Menu Delete Successfully');
            redirect('admin/MenuController/viewMenu');
        } else {
            $this->session->set_flashdata('msg', 'Menu can not Delete');
            redirect('admin/MenuController/viewMenu');
            
        }
   }

	
    	
}
