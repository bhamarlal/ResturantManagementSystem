<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RestaurantController extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $this->load->helper("url");
        $this->load->database();
        $this->load->model('admin/Restaurant');
        $this->load->library("session");
    }
	public function index()
	{
		$this->db->select('*');
    	$this->db->from('countries');
    	$query = $this->db->get();
    	$data['cities']=$query->result_array();
		$data["page"] = "admin/Restaurant/addRestaurant";
		$this->load->view("admin/includes/template",$data);
	}
	public function addRestaurant()
	{
        $id = $this->input->post('countryid');
        $this->db->select('*');
        $this->db->from('states');
        $this->db-> where('country_id', $id);
        $query = $this->db->get();
       $data=$query->result();
       
        foreach($data as $key=>$val){
           echo  $data   = "<option value='".$val->id."'>".$val->name."</option>";      
        }
        
	}
    public function addRestaurantCity()
    {
        $id = $this->input->post('stateid');
        $this->db->select('*');
        $this->db->from('cities');
        $this->db-> where('state_id', $id);
        $query = $this->db->get();
       $data=$query->result();
       
        foreach($data as $key=>$val){
           echo  $data   = "<option value='".$val->id."'>".$val->name."</option>";      
        }
        
    }
    public function addRestaurantDb(){
       /* $data = array(
        'name'=>$this->input->post('restaurantName'),
        'description'=>$this->input->post('restaurantDescription'),
        'time'=>$this->input->post('restaurantTime'),
        'city_id'=>$this->input->post('restaurantCity'),
          );
     $result=$this->Restaurant->addrestaurant($data);
     if($result){
            $this->session->set_flashdata('msg', 'Restaurant added Successfully');
            redirect('admin/RestaurantController/index');
        } else {
            $this->session->set_flashdata('msg', 'Restaurant can not added');
            redirect('admin/RestaurantController/index');
        }*/
    if(isset($_FILES['cityImage'])){
      $errors= array();
      $file_name = $_FILES['cityImage']['name'];
      $file_size =$_FILES['cityImage']['size'];
      $file_tmp =$_FILES['cityImage']['tmp_name'];
      $file_type=$_FILES['cityImage']['type'];
      $tmp = explode('.', $file_name);
        $file_ext = end($tmp);
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"admin/assets/uploads/".$file_name);
         $data = array(
        'name'=>$this->input->post('restaurantName'),
        'description'=>$this->input->post('restaurantDescription'),
        'time'=>$this->input->post('restaurantTime'),
        'city_id'=>$this->input->post('restaurantCity'),
        'city_image'=>$file_name

        );
         $result=$this->Restaurant->addrestaurant($data);
     if($result){
            $this->session->set_flashdata('msg', 'Restaurant added Successfully');
            redirect('admin/RestaurantController/index');
        } else {
            $this->session->set_flashdata('msg', 'Restaurant can not added');
            redirect('admin/RestaurantController/index');
        }
        
      }else{
         print_r($errors);
      }
   }
    }
   
    	
}
