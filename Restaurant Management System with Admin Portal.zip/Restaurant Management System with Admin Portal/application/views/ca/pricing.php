<div class="swipe"></div>

<div class="site">

    <div class="header">
                <div class="header__menu">
                            <div class="h1_logo"><a href="<?php echo site_url('Welcome/index') ?>"><span>ChowNow</span></a></div>
                        <a href="tel:18887072469" class="phone">888-707-2469</a><ul class="center_menu">
                                                    <li class="option how"><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                                            <li class="option testimonials"><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                                            <li class="option pricing"><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                    </ul><p><a href="#"><svg width="12" height="15" viewBox="0 0 12 15" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 12h-9c-.828 0-1.5.672-1.5 1.5S.672 15 1.5 15h9c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5m0-6h-9C.672 6 0 6.672 0 7.5 0 8.33.672 9 1.5 9h9c.828 0 1.5-.67 1.5-1.5 0-.828-.672-1.5-1.5-1.5m-9-3h9c.828 0 1.5-.672 1.5-1.5S11.328 0 10.5 0h-9C.672 0 0 .672 0 1.5S.672 3 1.5 3" fill="#FFF" fill-rule="evenodd"/></svg></a></p><ul>                        <li class="demo"><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>

            <div class="header__menu__fill force"></div>
        </div>
    </div>

<div class="main">
<div class="banner mini center">
  <div class="container">
    <div class="banner__headline">
      <div class="common-table">
        <div class="common-cell">
          <div class="dc-banner-block">
            <!-- dynamic content block for banner headline -->
            <div id="dc-pricing-banner-headline"></div>
            <!-- dynamic content block for banner subhead -->
            <div id="dc-pricing-banner-subhead"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="pricing" style="position:relative;">
    <div class="pricing__plans">
        <div class="container">
            <div class="common-wrap">
                <div class="pricing__plan monthly">
                    <div class="pricing__plan__frame">
                        <div class="pricing__plan__tag hide">&nbsp;</div>
                        <h3>Monthly Plan</h3>
                        <h5 class="canadian">
                            <sup>$</sup>189<span
                                class="canada-prc-tag">CDN</span><sub> /mo</sub>
                        </h5>
                        <h4>+$499 Setup Fee</h4>
                        <h6>Per Location</h6>
                        <a href="../demo/index.html" id="monthly-plan" class="common-button pill red slim">Get Started</a>
                    </div>
                </div>
                <div class="pricing__plan annual">
                    <div class="pricing__plan__frame">
                        <div class="pricing__plan__tag common-tag"><span>Most Popular</span></div>
                        <h3>Annual Plan</h3>
                        <h5 class="canadian"><sup>$</sup>159<span
                                class="canada-prc-tag annual-middle-taggie-do">CDN</span><sub> /mo</sub>
                        </h5>

                        <h4>+$249 Setup Fee</h4>
                        <h6>Per Location</h6>
                        <a href="../demo/index.html" id="annual-plan" class="common-button pill red slim">Get Started</a>
                    </div>
                </div>
                <div class="pricing__plan twoyear">
                    <div class="pricing__plan__frame">
                        <div class="pricing__plan__tag hide">&nbsp;</div>
                        <h3>Two-Year Plan</h3>
                        <h5 class="canadian">
	                        <sup>$</sup>
	                        	129			                        			                        	<span class="canada-prc-tag">CDN</span>
			                        <sub> /mo</sub>
                        </h5>
                        <h4>+$249 Setup Fee</h4>
                        <h6>Per Location</h6>
                        <a href="../demo/index.html" id="two-year-plan" class="common-button pill red slim">Get Started</a>
                    </div>
                </div>
                <div class="pricing__plans__note">
                    <p>Sales tax may apply. Annual and Two-Year plans paid up-front.
                       Pricing shown in CAD.</p> <a href="<?php echo site_url('UserController/seeUsdPrice') ?>" class="common-button standard red">See USD pricing here</a>
                                      </div>
            </div>
        </div>
    </div>


    
    <div class="pricing__fees">
        <div class="container">
            <div class="common-wrap">
                <h3>Credit Card Processing Fees</h3>
                                    <p>VISA, MASTERCARD: 13 CENTS + 2.8% PER TRANSACTION • AMERICAN EXPRESS: 19 CENTS + 3.5% PER TRANSACTION</p>
                            </div>
        </div>
    </div>

    <div class="pricing__includes">
      <div class="container">
        <div class="common-wrap">
          <h3>What You Get With ChowNow Direct</h3>
          <dl class="x0">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-unlimited-orders.svg" alt=""/></span></dt>
            <dd>
              <p>Unlimited Commission-<br />Free Orders</p>
            </dd>
          </dl>
          <dl class="x1">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-website-ordering.svg" alt=""/></span></dt>
            <dd>
              <p>Website Ordering</p>
            </dd>
          </dl>
          <dl class="x2">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-social-ordering.svg" alt=""/></span></dt>
            <dd>
              <p>Social Ordering</p>
            </dd>
          </dl>
          <dl class="x3">
            <dt>
                <span>
                    <img class="management-tools-icon" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/features-management-tools.svg" alt=""/>
                </span>
            </dt>
            <dd>
              <p>Management Tools</p>
            </dd>
          </dl>
          <dl class="x4">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-menu-upload.svg" alt=""/></span></dt>
            <dd>
              <p>Menu Upload</p>
            </dd>
          </dl>
          <dl class="x5">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-chownow-tablet.svg" alt=""/></span></dt>
            <dd>
              <p>1 Wi-Fi Enabled<br />ChowNow Tablet</p>
              <p class="note">(Per Location)</p>
            </dd>
          </dl>
          <dl class="x6">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-chownow-dashboard.svg" alt=""/></span></dt>
            <dd>
              <p>Unlimited ChowNow<br />Dashboard Access</p>
            </dd>
          </dl>
          <dl class="x7">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-marketing-launch-package.svg" alt=""/></span></dt>
            <dd>
              <p>1 ChowNow Marketing<br />Launch Package</p>
              <p class="note">(Per Location)</p>
            </dd>
          </dl>
          <dl class="x8">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/dedicated-onboarding.svg" alt=""/></span></dt>
            <dd>
              <p>Dedicated<br />Account Onboarding</p>
            </dd>
          </dl>
          <dl class="x9">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-one-on-one-training.svg" alt=""/></span></dt>

            <dd>
              <p>Comprehensive<br />Training Materials</p>
            </dd>
          </dl>
          <dl class="x10">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-marketing-services.svg" alt=""/></span></dt>
            <dd>
              <p>Ongoing Marketing<br />Strategy</p>
            </dd>
          </dl>
          <dl class="x11">
            <dt><span><img src="<?php echo base_url();?>assets/wp-content/themes/chownow4/svg/feature-icons/pricing-customer-support.svg" alt=""/></span></dt>
            <dd>
              <p>24/7 Support</p>
            </dd>
          </dl>
        </div>
      </div>
    </div>


        <div class="pricing__optional__addons">
      <h3>Add-Ons</h3>
      <div class="container">
        <div class="common-wrap">
    
    
            <div class="pricing__optional__addon">
      <div class="pricing__optional__addon__float">
        <h4>Wireless Data Connection</h4>
        <h5>No Wi-Fi? Lease an LTE-enabled ChowNow Tablet.</h5>
      </div>
      <span class="opt-price">
        <sup>$</sup><span>25</span>
        <span class="canada-price-tag">CDN</span>        <sub>/mo</sub>
      </span>
    </div>
                <div class="pricing__optional__addon">
      <div class="pricing__optional__addon__float">
        <h4>Restaurant Website</h4>
        <h5>Need a website? We can help. <a class="common-button standard red" href="<?php echo site_url('UserController/restraurantWebsite') ?>">view our plans</a></h5>
      </div>
      <span class="opt-price">
        <sup>$</sup><span>19</span>
        <span class="canada-price-tag">CDN</span>        <sub>/mo</sub>
      </span>
    </div>
                <div class="pricing__optional__addon">
      <div class="pricing__optional__addon__float">
        <h4>Menu Sync</h4>
        <h5>Sync your menu with over 30 websites.</h5>
      </div>
      <span class="opt-price">
        <sup>$</sup><span>39</span>
        <span class="canada-price-tag">CDN</span>        <sub>/mo</sub>
      </span>
    </div>
                  
        </div>
      </div>
    </div>

    </div>

        <div class="request">
          <div class="container">
            <div class="request__content common-content">
              <h3>Ready to learn more?</h3>
              <p>Request a free product demo today.</p>
            </div>
            <div class="request__form common-form">
              <div class="gate-c789ef96-e21e-4d17-a443-23e40b0530c9"></div>
            </div>
            <div class="request__note"></div>
          </div>
          <div class="error">
            <div class="container">
              <div class="error__content"></div>
              <div class="error__close common-close"><a href="#"><svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M10.667 0L6 4.666 1.334 0 0 1.333 4.667 6 0 10.665 1.333 12 6 7.333 10.668 12 12 10.666 7.333 6 12 1.332 10.667 0z" fill="#36363D" fill-rule="evenodd"/></svg></a></div>
            </div>
          </div>
        </div>
</div>

