<html lang="en">
<!-- App Version: 1.7.11 -->

<head>
    <style type="text/css">
        .gm-control-active>img {
            box-sizing: content-box;
            display: none;
            left: 50%;
            pointer-events: none;
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%)
        }
        
        .gm-control-active>img:nth-child(1) {
            display: block
        }
        
        .gm-control-active:hover>img:nth-child(1),
        .gm-control-active:active>img:nth-child(1) {
            display: none
        }
        
        .gm-control-active:hover>img:nth-child(2),
        .gm-control-active:active>img:nth-child(3) {
            display: block
        }
    </style>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Google+Sans">
    <style type="text/css">
        .gm-ui-hover-effect {
            opacity: .6
        }
        
        .gm-ui-hover-effect:hover {
            opacity: 1
        }
    </style>
    <style type="text/css">
        .gm-style .gm-style-cc span,
        .gm-style .gm-style-cc a,
        .gm-style .gm-style-mtc div {
            font-size: 10px;
            box-sizing: border-box
        }
    </style>
    <style type="text/css">
        @media print {
            .gm-style .gmnoprint,
            .gmnoprint {
                display: none
            }
        }
        
        @media screen {
            .gm-style .gmnoscreen,
            .gmnoscreen {
                display: none
            }
        }
    </style>
    <style type="text/css">
        .gm-style-pbc {
            transition: opacity ease-in-out;
            background-color: rgba(0, 0, 0, 0.45);
            text-align: center
        }
        
        .gm-style-pbt {
            font-size: 22px;
            color: white;
            font-family: Roboto, Arial, sans-serif;
            position: relative;
            margin: 0;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="apple-itunes-app" content="app-id=1210943577">
    <link rel="shortcut icon" type="image/png" href="https://cf.chownowcdn.com/marketplace-react-prod/cn-favicon.png">
    <link rel="stylesheet" href="https://cf.chownowcdn.com/marketplace-react-prod/leitura.css">
    <title>Search and Order from Restaurants Near You - ChowNow</title>
    <script type="text/javascript" async="" src="https://cdn.amplitude.com/libs/amplitude-4.2.1-min.gz.js"></script>
    <script type="text/javascript" async="" src="//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script src="https://jssdkcdns.mparticle.com/js/v2/b8d12eac313e7346815ffa7251890c8f/mparticle.js" async=""></script>
    <script src="https://connect.facebook.net/signals/config/127575507831621?v=2.8.45&amp;r=stable" async=""></script>
    <script src="https://connect.facebook.net/signals/config/2235850063405947?v=2.8.45&amp;r=stable" async=""></script>
    <script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/gtm/js?id=GTM-PCJXRV5&amp;cid=1417183059.1553583506"></script>

    <script src="https://maps.googleapis.com/maps/api/js?client=gme-chownowinc&amp;libraries=places&amp;callback=initMap&amp;channel=discover-web" async=""></script>
    <script async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-PWPXQFW"></script>
    <script>
        window.dataLayer = []
    </script>
    <script async="" src="https://pay.google.com/gp/p/js/pay.js"></script>
    <script type="text/javascript">
        window.cn = {
            appVersion: "1.7.11",
            isMparticleReady: !1
        }
    </script>
    <script>
        ! function(e, t, a, n, g) {
            e[n] = e[n] || [], e[n].push({
                "gtm.start": (new Date).getTime(),
                event: "gtm.js"
            });
            var m = t.getElementsByTagName(a)[0],
                r = t.createElement(a);
            r.async = !0, r.src = "https://www.googletagmanager.com/gtm.js?id=GTM-PWPXQFW", m.parentNode.insertBefore(r, m)
        }(window, document, "script", "dataLayer")
    </script>
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/vendor.c1f28a76.css" rel="stylesheet">
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/main.cf5db557.css" rel="stylesheet">
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/0.e4bdc38e.chunk.js"></script>
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/3.b47ed560.chunk.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/common.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/util.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/controls.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/places_impl.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/geocoder.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/usage.js"></script>
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/1.355c2953.chunk.js"></script>
    <style id="detectElementResize" type="text/css">
        @keyframes resizeanim {
            from {
                opacity: 0;
            }
            to {
                opacity: 0;
            }
        }
        
        .resize-triggers {
            animation: 1ms resizeanim;
            visibility: hidden;
            opacity: 0;
        }
        
        .resize-triggers,
        .resize-triggers > div,
        .contract-trigger:before {
            content: " ";
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            overflow: hidden;
            z-index: -1;
        }
        
        .resize-triggers > div {
            background: #eee;
            overflow: auto;
        }
        
        .contract-trigger:before {
            width: 200%;
            height: 200%;
        }
    </style>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/map.js"></script>
    <style type="text/css">
        .gm-style {
            font: 400 11px Roboto, Arial, sans-serif;
            text-decoration: none;
        }
        
        .gm-style img {
            max-width: none;
        }
    </style>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/onion.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/stats.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/marker.js"></script>
</head>

<body style="overflow: visible;">
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PWPXQFW" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <script type="text/javascript">
        ! function() {
            function n() {
                var n = document.createElement("script");
                n.src = "https://cdn.siftscience.com/s.js", document.body.appendChild(n)
            }
            window.attachEvent ? window.attachEvent("onload", n) : window.addEventListener("load", n, !1)
        }()
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/custom.js"></script>
    <!-- <div id="root"><div class="_3D-MR"><div><nav class="_279YF Q4N6P"><div class="_1ejiX"><div class=""><a class="_1_jiM" href="/discover/"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
</svg>
</span></a><div><div class="bm-overlay _39lkJ" style="position: fixed; z-index: 1000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 0; transform: translate3d(100%, 0px, 0px); transition: opacity 0.3s ease 0s, transform 0s ease 0.3s;"></div><div id="" class="bm-menu-wrap _2EsCV _3kSno" style="position: fixed; right: inherit; z-index: 1100; width: 300px; height: 100%; transform: translate3d(-100%, 0px, 0px); transition: all 0.5s ease 0s;"><div class="bm-menu _13dWY" style="height: 100%; box-sizing: border-box; overflow: auto;"><nav class="bm-item-list _2p5QV" style="height: 100%;"><div class="e7rlY" style="display: block; outline: none;"><header class="_3Y-p3"><span class="isvg loaded _2gHpi"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
</svg>
</span></header><div class="csPk3"><ul class="_3FgVj"><li class="_3gq9n"><a class="_2kuAl" href="/discover/">Home</a></li><li class="_3gq9n"><a class="_2kuAl">Sign Up</a></li><li class="_3gq9n"><a class="_2kuAl">Log In</a></li></ul></div></div><footer class="_34O-K"><div class="_3fFTo _15_Nm"><div class="i4GhA _3R0zp"></div><div class="_3hM1C"><a href="https://get.chownow.com/" target="_blank" rel="noopener"><h5>About ChowNow</h5></a><a href="https://get.chownow.com/terms-of-service" target="_blank" rel="noopener"><h5>Terms of Use</h5></a><a href="https://get.chownow.com/privacy-policy" target="_blank" rel="noopener"><h5>Privacy Policy</h5></a></div><ol class="_2vI3K"><li class="_2Ygxm"><a href="https://instagram.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M14.194 12.184c-1.15 0-2.082.914-2.082 2.043 0 1.128.932 2.043 2.082 2.043s2.082-.915 2.082-2.043c0-1.129-.932-2.043-2.082-2.043zm4.001 1.256h-.911c.086.287.133.588.133.902 0 1.745-1.443 3.161-3.223 3.161-1.78 0-3.223-1.416-3.223-3.162 0-.313.048-.614.133-.901h-.951v4.436c0 .23.185.416.412.416h7.218a.414.414 0 0 0 .412-.416V13.44zm-1.642-3.274a.472.472 0 0 0-.467.473v1.132c0 .26.21.472.467.472h1.171a.471.471 0 0 0 .467-.473v-1.13c0-.26-.21-.475-.467-.475h-1.171zM10.33 9h7.706c.732 0 1.33.606 1.33 1.348v7.804c0 .742-.598 1.348-1.33 1.348H10.33A1.343 1.343 0 0 1 9 18.152v-7.804C9 9.606 9.599 9 10.331 9z"></path>
    </g>
</svg>
</span></a></li><li class="_2Ygxm"><a href="https://twitter.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M19.17 11.024a4.367 4.367 0 0 1-1.037 1.135v.283a6.46 6.46 0 0 1-.982 3.435 6.406 6.406 0 0 1-1.195 1.425c-.462.411-1.018.74-1.665.987a5.81 5.81 0 0 1-2.09.37c-1.256 0-2.322-.296-3.201-.889.164.025.33.038.494.038.903 0 1.766-.346 2.59-1.036a1.952 1.952 0 0 1-1.207-.439 2.152 2.152 0 0 1-.735-1.078 2.06 2.06 0 0 0 .94-.037 2 2 0 0 1-1.193-.753 2.184 2.184 0 0 1-.477-1.394v-.024c.298.172.612.263.942.271-.62-.436-.93-1.04-.93-1.813 0-.362.093-.716.282-1.06a5.913 5.913 0 0 0 1.901 1.585c.741.39 1.54.61 2.395.659a2.316 2.316 0 0 1-.046-.506c0-.6.202-1.114.605-1.541A1.957 1.957 0 0 1 16.04 10c.596 0 1.106.231 1.53.691a4.153 4.153 0 0 0 1.318-.53 2.063 2.063 0 0 1-.918 1.209c.401-.05.8-.165 1.201-.346"></path>
    </g>
</svg>
</span></a></li><li class="_2Ygxm"><a href="https://facebook.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <path fill="#172534" d="M13.03 19.333v-4.984h-1.342v-1.813h1.343V10.95c0-.704.225-1.297.677-1.774.452-.479 1.12-.718 2.007-.718.223 0 .447.01.67.024.225.019.391.034.498.051l.174.026-.074 1.712h-1.156c-.315 0-.525.075-.628.226-.103.151-.155.378-.155.68v1.36h2.013l-.136 1.812h-1.877v4.984H13.03z"></path>
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
    </g>
</svg>
</span></a></li></ol></div></footer></nav></div><div><div class="bm-cross-button" style="position: absolute; width: 24px; height: 24px; right: 8px; top: 8px;"><span style="position: absolute; top: 6px; right: 14px;"><span class="bm-cross" style="position: absolute; width: 3px; height: 14px; transform: rotate(45deg);"></span><span class="bm-cross" style="position: absolute; width: 3px; height: 14px; transform: rotate(-45deg);"></span></span><button style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; margin: 0px; padding: 0px; border: none; text-indent: -9999px; background: transparent; outline: none; cursor: pointer;">Close Menu</button></div></div></div><div><div class="bm-burger-button _3-Pa0" style="z-index: 1000;"><span class="isvg loaded bm-icon" style="width: 100%; height: 100%;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12">
    <g fill="#0B2135" fill-rule="nonzero">
        <path d="M.686 6.5C.307 6.5 0 6.164 0 5.75S.307 5 .686 5h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686zM.686 1.5C.307 1.5 0 1.164 0 .75S.307 0 .686 0h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686zM.686 11.5c-.379 0-.686-.336-.686-.75S.307 10 .686 10h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686z"></path>
    </g>
</svg>
</span><button style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; margin: 0px; padding: 0px; border: none; opacity: 0; font-size: 8px; cursor: pointer;">Open Menu</button></div></div></div></div><div class="FUzDZ"><div class="geosuggest _2mRdX"><div class="geosuggest__input-wrapper"><input class="geosuggest__input _3VqJs hdyK6" type="text" autocomplete="nope" placeholder="City or Address" value="Gulshan-e-Iqbal, Bl-6,Aladin Park, karachi, Pakistan, Block 10-A Gulshan-e-Iqbal, Karachi, Karachi City, Sindh, Pakistan"></div><div class="geosuggest__suggests-wrapper"><ul class="geosuggest__suggests _1j2-_ geosuggest__suggests--hidden _321SV"></ul></div></div></div></div><div><div class=""><ul class="_7BFWB"><li><h5><a class="_3pRye">Sign Up</a></h5></li><li><h5><a class="_3pRye">Log In</a></h5></li></ul></div></div></nav><div class="_1yCYr"><div><div class="_1Wbti"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="130" height="32" viewBox="0 0 130 32">
    <g fill="#FFF" fill-rule="evenodd">
        <path d="M22.478 19.672a.194.194 0 0 1-.274 0l-2.818-3.182a.494.494 0 0 0-.698.697l2.843 3.156a.351.351 0 1 1-.498.498l-3.162-2.838a.492.492 0 1 0-.698.697l3.187 2.813a.193.193 0 0 1-.206.318s-2.208-.822-3.323-1.936c-.689-.687-1.031-1.512-1.045-2.29l-.004.004c-.005-.775.1-1.285-.564-1.964l-.846-.78-.89.82c-.666.85-.511 1.42-.515 2.115l-.004-.004c-.015.824-.378 1.699-1.107 2.427-1.363 1.36-3.882 2.1-4.98 1.003-1.099-1.096-.36-3.612 1.003-4.973.729-.728 1.605-1.09 2.43-1.106l-.004-.004c.692-.004 1.249.136 2.061-.548l6.17-6.679a1.15 1.15 0 0 1 1.66-.036 1.145 1.145 0 0 1-.036 1.656l-4.57 4.207.743.803c.676.655 1.187.551 1.96.556l-.003.003c.779.015 1.605.357 2.294 1.044 1.12 1.118 1.937 3.313 1.937 3.313a.193.193 0 0 1-.043.21zM8.548 7.88a1.15 1.15 0 0 1 1.659.036l3.022 3.27-1.311 1.42-3.334-3.07a1.146 1.146 0 0 1-.036-1.656zm20.124 6.426C28.672 6.409 22.26.008 14.351.008 6.44.008.029 6.41.029 14.306c0 .198.005.396.013.593-.013.632.053 2.052.713 3.911a14.272 14.272 0 0 0 2.78 4.867c1.952 2.429 4.984 5.046 9.685 7.454a2.483 2.483 0 0 0 2.26 0c4.702-2.408 7.734-5.025 9.687-7.454a14.275 14.275 0 0 0 2.779-4.867c.66-1.86.726-3.279.713-3.911.008-.197.013-.395.013-.593zM104.626 17.57c0 1.646 1.254 2.986 2.823 2.986s2.845-1.34 2.845-2.986c0-1.645-1.276-2.961-2.845-2.961-1.569 0-2.823 1.316-2.823 2.961zm8.602 0c0 3.241-2.598 5.888-5.779 5.888s-5.778-2.647-5.778-5.887c0-3.24 2.597-5.888 5.778-5.888 3.181 0 5.779 2.648 5.779 5.888zM55.357 11.79a4.225 4.225 0 0 0-2.84 1.032l-.113-4.336c0-.254-.242-.514-.586-.466l-2.326.352v14.927h3.041v-6.536c0-.95.634-1.823 1.564-2.022 1.277-.273 2.434.729 2.434 1.963v6.595h2.997v-7.106c0-2.34-1.828-4.364-4.171-4.402M85.282 12.163l-2.343 6.253-1.988-6.224a.422.422 0 0 0-.399-.294h-2.671l.33.92-1.811 5.598-2.365-6.254a.422.422 0 0 0-.395-.273h-2.885l4.48 11.41h1.714a.422.422 0 0 0 .398-.28l2.321-6.483 2.302 6.482c.06.168.219.28.398.28h1.713l4.48-11.409h-2.884a.422.422 0 0 0-.395.274M63.157 17.57c0 1.646 1.255 2.986 2.824 2.986 1.568 0 2.845-1.34 2.845-2.986 0-1.645-1.277-2.961-2.845-2.961-1.57 0-2.824 1.316-2.824 2.961zm8.602 0c0 3.241-2.597 5.888-5.778 5.888-3.182 0-5.779-2.647-5.779-5.887 0-3.24 2.597-5.888 5.779-5.888 3.18 0 5.778 2.648 5.778 5.888zM126.691 12.163l-2.343 6.253-1.987-6.224a.422.422 0 0 0-.399-.294h-2.672l.33.92-1.81 5.598-2.366-6.254a.421.421 0 0 0-.395-.273h-2.885l4.481 11.41h1.714a.422.422 0 0 0 .398-.28l2.322-6.483 2.3 6.482c.06.168.22.28.398.28h1.714l4.48-11.409h-2.884a.421.421 0 0 0-.396.274M43.144 23.458c-4.107 0-7.448-3.403-7.448-7.587 0-4.183 3.332-7.586 7.427-7.586 2.092 0 3.963.893 5.562 2.655L47.257 12.7a.542.542 0 0 1-.778.073c-.948-.82-2.128-1.526-3.697-1.4-1.988.159-3.678 1.721-4.007 3.725-.465 2.83 1.675 5.288 4.369 5.288 1.2 0 2.363-.468 3.335-1.333a.54.54 0 0 1 .79.09l1.419 1.883c-1.376 1.525-3.441 2.433-5.544 2.433M89.095 23.299V7.953h2.259c.179 0 .347.087.45.233l6.215 9.225V7.953h2.985V23.3h-2.198a.552.552 0 0 1-.45-.233L92.09 13.78V23.3h-2.996"></path>
    </g>
</svg>
</span></div><div class="_3eFiO _23Txc"><ul class="_7BFWB"><li><h5><a class="_3pRye">Sign Up</a></h5></li><li><h5><a class="_3pRye">Log In</a></h5></li></ul></div></div><div class="_1zBBv"><h1 class="_2SF-u">Hungry? Find the food you're looking for.</h1><h2 class="_3YGFz">Your city's best eats, ready to be ordered online.</h2><div class="_2Q2fa"><div class="FUzDZ"><div class="geosuggest _2mRdX"><div class="geosuggest__input-wrapper"><input class="geosuggest__input _3VqJs l81ey" type="text" autocomplete="nope" placeholder="City or Address" value="Gulshan-e-Iqbal, Bl-6,Aladin Park, karachi, Pakistan, Block 10-A Gulshan-e-Iqbal, Karachi, Karachi City, Sindh, Pakistan"></div><div class="geosuggest__suggests-wrapper"><ul class="geosuggest__suggests _1j2-_ geosuggest__suggests--hidden _321SV"></ul></div></div></div><button class="_2jjjt _2oxVn _2xk2l _2uOCG">Search</button></div></div></div><div class="_2GFuf _15_Nm"><p class="izuoC">Order <strong>pickup</strong> or <strong>delivery</strong> from the best restaurants in your city.</p><div class="Ocoal"><div class="_3jW__ _2YVVH"><h2 class="_30Zd8">Los Angeles, CA</h2><div class="_2ZFjK"><h5 class="_1DPcw">Sunny Side Up</h5></div></div><div class="_3jW__ _2gkDy"><h2 class="_30Zd8">Chicago, IL</h2><div class="_2ZFjK"><h5 class="_1DPcw">Windy City Eats</h5></div></div><div class="_3jW__ _3g9Bg"><h2 class="_30Zd8">New York City, NY</h2><div class="_2ZFjK"><h5 class="_1DPcw">Nosh that never sleeps</h5></div></div><div class="_3jW__ _3g6Rj"><h2 class="_30Zd8">Seattle, WA</h2><div class="_2ZFjK"><h5 class="_1DPcw">Fresh Catches Daily</h5></div></div><div class="_3jW__ _2N9N9"><h2 class="_30Zd8">San Francisco, CA</h2><div class="_2ZFjK"><h5 class="_1DPcw">Best of the bay</h5></div></div><div class="_3jW__ _2cwPE"><h2 class="_30Zd8">Denver, CO</h2><div class="_2ZFjK"><h5 class="_1DPcw">Mile High Cravings</h5></div></div></div></div><div class="_3rDWn"><div class="i4GhA"></div><h2 class="_1-_0E">New customers await.</h2><p class="_31mCS"><strong>Own a restaurant?</strong> Help hungry customers discover you through ChowNow.</p><a href="https://get.chownow.com/demo/?utm_source=discover_homepage&amp;utm_medium=banner&amp;utm_campaign=restaurant_learn_more%2Fdemo&amp;utm_content=button" target="_blank" rel="noopener"><button class="_2jjjt _2tWsz _2xk2l _2uOCG">Learn More</button></a></div><div class="_1SJY6"><h2 class="_2Bcv-">Get the ChowNow app.</h2><p class="DZKHZ">It's the easiest way to order the food you want, when you want it, wherever you are.</p><a href="https://app.appsflyer.com/id1210943577?pid=DiscoverWeb&amp;c=home_bottombanner" target="_blank" rel="noopener"><img class="tbTHA" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPQAAABICAYAAADBJ9jwAAAAAXNSR0IArs4c6QAAIXdJREFUeAHtXQd8T9cXPwlaQonE3nvV3tQIRVGb2MSmRY2aRW012moVJWhjh1i1q3ZVtbX33rR2B1o0fv/zvcl9ue/lNzJ+I+n/nc8nuXu883v33XPPPcOLDLBhwwafZ8+etQ5/GV7fy8urMFkoA1fxNlQzkyYGTAy4GwNe9C+vxzsWL8sxb/LelDt37tVly5Z9oU7DS02sXLmyKXnRLIvFkvnJkyd08dJF+vOPP+nly5dqNTNuYsDEgAcwkDRpUvL19aV8+fLRq6++ihlc8vby7hkYGLhDTkdb0CvCVgzyIq+pT58+9Vq+bBnt27+PLC8tsp4ZmhgwMZBAMJAsWTKqU6cONWnSlJIlTRZu8ba806pFq3mYnljQYWFhzSxkWXXx4kWvWbNm0aNHDxPI1M1pmBgwMWALA1mzZqW+fd+jTBkzhXOdBi1bttzqffDgQR9ezDOxM5uL2RbqzHwTAwkPA7du3aI5c+YQ87uS8Ozm7tq1K7n31atXA3FmXrZsqbkzJ7zfzJyRiQG7GLh69Qpt2ryJeWWWHHcf3O3gHR4eXhcMsB/2/2C3oVloYsDEQMLEwI7t24k3ZaKX1NybT9EFLl2+ZDLAEuZvZc7KxIBDDPzxxx909+5dXspeRb35X/o///zTYSOzgokBEwMJFwORazgTBEZAdifcmZozMzFgYsAhBiArwufoJKYEmENUmRVMDCQeDCT6BV2ieAkaN248rV27jiBJY0LMMODv708lS5SkjBkyxqyBE2th7FIlS+H+1Im9uq6rXLlyifn6+Pi4bhAn9ZxoVwAW8qefTqeKFStoqHCniCqkdfq914/8/PzJz9+PkiRJQtevX6fr167R5i2b6d69e9q8EmIEUkYzPv+cP4bjaMrUKW6dYqOGjWjmzJk0cdIkmjRpolvHjstgE8ZPoKZNm1JAjRr0yy8/x6ULt7VJlAt68KDBNGrUh7yIogiMR49+d6vMeYoUKWjs2LEUHv6ScMH/999/U7OmzSh58lfpyZOnNGv2LF4sYyOuE9z2c5oDxQcDGTJkoKxZstKRo0fi041H20atCI9OI+aDT5w4icaMGaNbzGh94KcDMe/EiTXPnz9PhYsUotJlSlG69P7UsFFDun37Ng0ZPJjw4TEhcWCgXLnydPnSFerWvXvimLCNWSaqHbp58+bUv18/q4+yaeNGq/nuzMTl/s6dO6lBw7fpyOGjNGLESFq7bi1duHBBN438+fNT2TJlKWWqVHT8+DH6+Wc9GRcQEEA+Pinpu++20YsXEdpxBQoUYC2b/Nz/Dvrnn39Ef6w+R4ULFxF93Lx5k1KnTk1VqlSls2fP0K+//koNGjSgdOnS0w/79tHxE8d1c7CXQD+VK1WmPHnz0pUrV2g/Cx3hrtMIxYsVp5IlS9JrXP/SxYu0jedr7diDMzOeydc3Lf0Uhw8vNIveeOMNKliwkPhY/vjjfnHvqs5H4mfPnt2UNm1aqlevPr14/lxIUTk6/kB7qXq1auTFmg3Zs2Wn+vXfpjt37tChQwfVIUQ8L+OkerXq9PjJY1q/fr32W6gVQb1Vq1qNChQsQBfOX6A9e/cICk6t47I4q0zefLfPuxaflCkS9F/6DOks9+/f5zXzMtofX6pb0vr5unX+mTJnFPM4ffq01XHnz58nynv16qkr/3T6pxa+JrT8+++/FtY7F3U2bdpoyZwlk1Zv1apVIr9W7Te1vC1bt4i8wJaBWt7iJYtFXoUK5UUeQuAnOHiu5eTJkyKONMYzzqPve31F+dixY7T+8A68VbeO5fbtW6KMJQhFePvX25a69d7S1RswcIAoe/jwoYWPGyJ+8OAvFt+0aXT18Ay8OEQ55oLn3r17t0hPmDhBV9faO1iufFnLmTNnRH05H/64WDp0bK9rO378OFFn2PChFtZL0MZ78OCB5fWiRXR1jePw0UirL98vFqfU2qxZs1qUf/7555bnz59rdU+cOBHtvStWvKgF7wTq8cfQwh84y+Ejhy25cufU+jOO74z0OH7+FStXWBINyd2tazfyZ+aTNRg5cgTx4rBW5LG802fOiLFff/11bQ6dgjrRgP79xU6WNVsW4kVMi5cs4R2hPo0bO06rt3XrFhF/o/IbIsQXP6B6AO/W/1LdunW1ejV417t27TqdOHlC5D17HoGD7kw2YicvXKQwdQzqKM7xkydPoVdeeUVray2CnW3pkmWUIoUP1ahZg/gjSs2aNSO/tH60eNESoYsr221hxl/5CuUpW/aslCNndgoNXUFlypShTp06yypCZ3fB/K/Ejok5ZcqciTp07EAVKkQxMrXKViK4tcC4efLkoZatWon5VKlalfijQPPnLRD5spn8/T8cNZp69Owunn3evHnMtExLY8dE4VbWV8OZs2ZS23btRFZY2CrKxxRUz549tCps6EPEmzRpQo0aN6SSpUoy1fIjFS36OnXl91KFkK9D+D31pxIlixN/SET9UkzFjB49Rq3msniiWdD4Qa3BmjVracnSJdaKPJonSWVv7ygUDxgwkElSC/Xp04f++usvQa69//5Ajj+mzp27MEMtuZjzt9u+FfUqM5kJCAioIa7klrICTd233hJ5IP2gPrdhw3qRxj855s2bt2j4B8MF13316tW0j0nuNGlSE9rYg6COQeKj+cUXM7RjAOaylPGbLp0/BQa21JqDo3/q1Cl67bXXKE/uPHTmzGlRVrx4ca0OSNccObLT8tDltGz5MvHM33yzjubMnaPVsRdp0KAhk9kFKHRFKDEVI6oeOXKYpk//lD9Oyahb16jz7ot/X4jyxYsX0Zo1a8Szjxw1UuSVKlXK3jD0+PFjun8/4lbiydMnfFy5TUx5aG14SxbxkaNG0N69e8URamrkzYDad1X+2JQuXZoW8Ryu8W0HAEew69dvUJPGTUTa1f+i3jZXjxSP/rFz4JrKCKtWraZOnYOM2QkinS9vPjEPJhdFiHMgdhqcdfHCSIBiDBYGOPY4ywGYTOTrkV+oYoWKfK7zEjs4XuQtW7ZQlixZqFjRYlSdd2zAemVBiwz+h5dJvoTIA5MOAC6uPShcpIgo/tlwNSPP+IUKFtSa4zf5asHXdO3qdTpw4IC4dUChv18UFVWAdzrAj/v3i1D+u2jgKch8Y1ikcGGR9YuBxyDnhzOqEa6w9pEELFR8LB09t6zvKMTClHDr9i0RVfsuVChivn379KW7d+5pf/jw+vqmYb6I6++xk8oJJuQQSIukesQ0Hz58xAynD8SXMCHOG6Tt22+/LaZ2/EQEOSznqV61ybxkySJ+Bj77ySwC2V2BSdrC/FK/xdYplsKKzL7vxTVZterVCTvh/fsP6Mcff9TayIi6mJH30hI7E1Js1kZ2JULcuQOe8tWchFVhq4ntWdGQoUNoBe+gGTNmpMOHDstiEeJuHqBSKSIdmS8KY/DP21Bfzufvp1Hzkd1Ee3YWiZTzkHWcEUrmH+tCaN1JwaaVYSujfcRQSf19tUZOjiSKBc0MBtq+Y4fgbILzy4YM3cc1jCXC8fLiPJw3bx5at24dMaNI9IAzHluEIXC4sVNfvnxZ5KdLl47PYsXETsK66dpo2I1Hjx5Nbdu2E6T1Rubi//7778wl/omqVqkiON4QYJEvltYwHpFTp06K1lWZ47t9x3atJ5D8gBORnHJIeEGgBzv33EjyGR8eI5y/cF5k1az5JoUsDNGKwRmPCZxkygUAjjEzGbUmxvloBfGIyOOKH1MecQV57IBuxMJFC+PaTbzaeXRB42WGCGB+vpLJmSOHWLCX+EXfvXuXeHnlkzG3kBo3biSTIsRXF1cZb75Zi/IzqZqMd8WnLNABVdBdu3aKnQvME1dDypQp+eWuSKlSpuJrioLUtk0bwrnqypWr1LtPb93wOHfNnz+fSdWvqHuP7oKRN2vmbGYevULMpdUtTjC6ILDShc/WCOUVymZWZh88eIg4u476cJSu//gmQkJCmGk3kPr07kNHjx4lXAG1bNlKMMbOnj1HOI8DcF7FsRIfIlxdgQKYwkw3gLob48OL8zwYaxcuXqCNnK5StQq14j4BckcTCSv/cG4+deq0aA99/TDe+QICAggkLaiTucFzrbSKW9aNGzdFw6r88WjM592TjP9Lly7FqrM9e/aIoxJ4ETjmrF69SjwjGKPHjx9nPkPE8StWncayskcWdNGiRZkx1Ff8sGBuGAHc3B3MpV3CHOCNGzdozB7UgwBAUFCQYDKkTetrbCrSQ4cM4XvTP2nBVwvo44+nWb1DtdowDplg+uzYvkNriR9y2PBhFBwcHI3zDuZQ9uzZxf300SNHRRswyaZOm0YzmBFlhK1btzIXtSstZ4aSBOzKEyZMENJo4GQ7E6CC1yKwBS0MWUhLFi/WusZ5vlPnTkzuh4s8nPE/+fQTGvT++xrJ//nnM/gYUIJS8odNAqiSdu3bUejy5TRs6FDxB4m+nr16iv6TvxrBBJT1jSHGa9O2tZjPp598QvgDXLhwkZmInZz6u4KvsXJlGH/AAmnZ0qUEDnn/Af2NU7KbBrnfvkN7mvPlXPpg+HDxJxuMHDnSLQvaC/fQu/fuzhry9ddybJeFYPB8+OFoIUUV00F+//0PAhME5oSxE2bLljWmTUW9X3/7jRdFF95t9sSqnaPKeBaQmalYOAS7NIQXQDKDEeMI0qdPrzH5IPAB5XRr4McMpsyZM4sdGuS2BHzxIWoqyXaZj7MlBCzAaMNcJEQwZXxFHsoAYGqBwQYBCr7fl1VFCB4Adt9s2bLx4jnPgipndUw2WRnMudx8fACpjt2sIFMoIF2N8wJ+ypUrJygQfBxQB3Uf8C77253fZHc2Q1BjRViABoIuV5laO3X6lLi6UhvgqihTpkz0G//e+OBIkEeBmO6OlStXpjSp0whBHFBGAOAhTZo04rmAdwBwhOMTfm/J0RYFkf9y5cpFBQswPpiaAW6s1VHrxzc+bNhwgVO3LWhcbyxatJjq1K4d37nHuv3z5y8oqFMQS/Z8E+u2ZgMTA4kBA3JB69mZLpz5vOB5HlnMeCSQ9QvmLxA7qgsf0ezaxIDHMeCWBd2bmSwNGzb06MPO/nI2nTt3zqNzMAc3MeBqDLicKZYpU2aCPqkn4f1Bg9h+8ZeenII5tokBt2DA5Tt0z549BcnrlqexMggU6c3FbAUxZtZ/EgMuXdAQd8Q9qqcA1xtSntdTczDHNTHgTgy4dEFXqlRJCPW784HUsSZMHK+7w1bLzLiJgf8iBlx6hi5dqrTHcAah/G++cf81Fe5Xcc+sAqSuYnI/rbZJzHHce8t74zxshOEfFjDBfTeMLuxh6TNVkykxP2dCnLtLFzT0Yz0FEB+V8rnunEPo8hUs3JFfN+RAlqiSMs+6gv9YIkuWrCw49CG1Y/lzb3bhYA0gBQg5cQj7WLOCYq2NmRdzDLiU5IYkkqfgqiIp5a45FGH1Q+Nixtju0oV113NaG6d169Z0/Nhx6tC+vc3FjHbQLCvBmmLmYraGxfjnuXSHfjVSYT/+04x9D6r4X+xbx62FunChvCBVPqFEAkUUo4hl3EZJeK3wfMFz5+kMN0LF9SDb5LrBhhDSpPEV4pPFihVjMVkfNlawyeZDQKS2fPnywq7XXyxb/vEnH9usaxZEx4BLF7Qj4fvo03FeDmR73Q2NGjXWhmS7YGzho4VIQwe6IVvf+DrE9fLy2gTcGJk6dZpuMX/FegHQV4/0t6TNBDLdzZs1J6kWqRVERnKwxt33e/dpjNSFixYZq5hpBxhwKcn9z7MI65QO5uCSYmg1uROg41ysWFFtyLnBc4SKn8xozPao/osAKyslS0RZkzl67Bi9917faIsZzw7FEJjnOXz4kFVUYMHD1JEJcceASxf0LTa34ymAITqQb+4CldyGoX1oFakaXjDy5+vr667puG2c/Pn1ZoD27tlrVTPLbRP6Px/IpSQ37Gd5CqB2WI0tb6iLypVzadw4ityGMj6MK0BfuXnzZmJYMIPeZqN5MPRnDwayIUGoAQL2s3mhdWzXGwA98PZsmRJG6GDuB9dybEaWlnF/sIdtC4azWh1UJQG7du0iNgcs4lATbNeuvWBQoT/oj+N6bcnSxWxgYreoE5N/bKdWVw14jy10ZkuhUHOEWyEVyvMzT50yVcsCX8SW2x5YRm3JRgxrszYf7Jdjp3/8+Imw4QaDF8tDQ9noQIQ6pNahEunSpStJm2lsdpetmIaKDaFly5YU1LGTMLAIqynTWL/eCFBbxdiNGjUi2BXDcQ/qrrDYsm7tWmEk0W03Lq60yz1o8CDW+Y5uR9tdefxiutQWsrSnnL9APmF/WT7X0GFDxLh58uTW5cP+tmxjK4QNZ9nP8uXLLWl8U1vmzQvW8mSZGrLlTwt77bDaNxv519qiH/90fhZpz1vtQ43zOxHN3rSt+ebLn0/rH30wWW1hW2hW52KrD9jAVse3FWe9Yqv9shEFC2yH22qHfNgOt2cHnFVrtfZr166xpEzlYwkLC9Py0Afschuf4Y0qb1hYX1xXzzgP2O8uXqJYtLbGvuKTdotdbqO1R+OXzdXp6tWr8TVKB1cPI0zWqNQ97H8BoLwPi5gSYC4JBhHsAbw9SPDnXQaWQLp16yazrIbwkLFu7TdWTfrAHpsEcNrnzgkWO73MsxaCmbdixcoYHVmw6x0+HGUc0McnBdt82yjMBlnr29l5sHyzmPXsM0dSNegfVmBgogh+xyTA59iIDz5g6yfWGW04Jknw4bM83Bi1aNFcZlkNy5YtR5s3bRamhmUFGEX46aef2SBghCEE5Bct+jptWL/RadZH5VjWQpeeoY+xmxeQPZ6EGTO+YJO31V06hcYKd/vEiZPCfYwccB3boZYA22GqoXyZr4bPnkUtQLhcCerYURRv/fZbNg8UKKy29OjRg3bs2Kk2Y/tqlWno0GG6PCSev4jqD3ay5REAUnSw9QXx3HfeeYctiv6ga1u7Vi3q27evLs9Wonfv3nzECNeK06dPJxbZ93u/50XRwqHVzalTp1IrvscexP7AVNi1a7fIRxn++vV/Ty2mmjVr0uSPJmvXgzBkAfNP7NWEcubKIcIhbPoI+RKwSAe9P0gmtVA6KUAG3OH069dfK4O9Mczlxs0oM76wYAJTRalTvybq3blzVzgngGnhmm/WEGNPnDhR6wOmqoawLTiXgytJbpAQbAPLLjliJE9ckQa51a1bV5eQPPziCFczct4TJozXjVOwUAHd88Otij3Savv27br66Hccu2oxtgFJyNJnurosXmqBix61LvuS0tVBf4OHDNbVQf3UaV6LRorzmdXi5582Wl21fxkH2YvxJR7UEKRy9+7dLKleS2m3rzJlS+vahywMsVkffV2+fFlX3+geR86tY1AHXT28D/jdZDlCtj+nq4P5szMBm8cHkN/yGdnXmE2SWv2NcBzJniObblx1DvGJu4XkxtcIlho9DSC3YPQtjI3AQdbamdCwYSOdZNQ3BjNHN27c0JGkdeq8pXnIsDYPdadA+YEDP9HkKZOjVeW3iXe0QcIrgyyE0AbueVVQdyfkwxzyLHb9YgQw8XDddPfuPa0IbmSkfXEt00aEz528QwWwtcxT0WowL0EYTTx86AiTn1FXe9EqxiIDeM+dO5fWAmSutEqqZUZGIBOAWwcJeB/glkiFl5EGEGUeKCX2y6W5GZL5CGEwv1OnTlpWMFsfhYlmawA3OxJwHGnevIVMuiR0KcmNGcOUq3qecMlTxLBT+JDCOdaZoHK3L126LLxgGPtfy5xOCVh0tWvXkcloofHFWmTHvjOsYs7+cpauj0rMvVbBaMp44cIQtVgXh5XOeYr9axRK/1q6ijYS8ABSoWJ5CmTOsLqAZPX8+fOxhdSdwjOkzItrWIedD6ig2u1W82UcH3QVatSoqSajXbXBdY+tW5pKFStppDY6kTcHug4jE0ydsMujZ1pRXpZXcCUkdWXn6BveAlavWS1kfF09lqP+oRiwcuUKR9ViXI57ZZxzJZw7f45qWflg/GWwBIo7a9UnlWyPEDuvCkbPG2oZ4ocO6YU0YKPcHuCqyx4cNvSX10F/1vqC7XD84Wqs33v9hFtbWS9VqpQEh24lShSPkcVP2c4Ywh2vCtI9jpqnxo3lqhNB1DPKLByw4pFE9mdUOoKDvH8G2xaiUm2V52JroK4Ely9oTB7OxdrznafKCXblQ9nqm91tOlWeGvfK0o0Nxqxfr574szW+zAelgLtLa3eTxhfr77+juK+yvRrCaZwK8MFsDxy5Y7l2/Zquedp4CMPsZ59W+Kv7Vl0+8swXniDRORb16DFjmBnXSzdWbBLpmPGmgq3dVNbB0UcFeTcv84x4Vxlgso4M4ZpJBXgRiSmkZU+ergSXk9yYPIzzwWC+JwFXGTC670xQye3Y9AvO6JvsHsYaGHdoa3XUPGN9ax8JtX5s46Bq4gtbv91KzBTTdVPTQPLqCmOQUPUE8NsajxbGLuAySCV+jHgz1sfxwxYkZyEWFdBvTP8ePLivNnV63C07NGY9esxovrKpp9vRnP40djoMYcUIFrKwUyN2RZA7Vs/j9+7dF87kbPUCY+0wNi8Bst140R2BI3cxOXPm1HXhyHiAI8dtObLn0Pf36KEuHdcEnhXXP9mzZxNdwAgCcAj57rgAnhMeHQHQvYaqrpFaUfuFbL9KIRq18Yw7tNrWGFedHqCsUqWKVplnxnbuSLttQWOX/mLmFzRwwAB3PJduDHBune0HCvfJ4JZKYOkrdqk6UiajhVh4p9lPkwSQ61hc0r2MzDeGudn38smTJ43ZWrpIkde1OCJnz57RpY0JKJHYe/Gh060CvGY4C+7evaMtaCwu2Jyzt6DtLTLwK8A9lwBPH/aeS/XjjDaQkdCButp1BdETV9h7hwroG77IEgK4heSWD/rRR5PYLchlmXRbOGToYJ3zO2cM3KRxU1030iG5LlNJwBXKMXZYJsHf30/Imsu0rbBGQICtIpH/Tq93dOXfs8tZeyA9N1qrgw9Mjx49dUX7vrffn66ynQRcx6gfH8iiG6kJo7plOjsqsEZ5886dO9sZnXTO4VFxJ8vZxxX27t2jaxrIctwJBdy6oMGQCQrqqJPccTUi4ICMZXKdOgx2FvXaBGKGcPPqCNYbbJypGlqyrXFX6tq1m+YHS9aR4bvv9mZlgKh7dZD99owHoB08N8InkzWABBUkmiSARFbdysp8NQQHF/OA5JQ9mD79M0qRIrlWZdu2bVpcRmBzTBXXLM0mrGwdOZYuXcK7exTDEIw3aNhZg9q1alPVqlW0IkgvLlac8aHAiHetspUIjm4//LBfK6lZswZTngO1tCcjbl3QeNAjR48QSyq55ZlBDfQf0M/pY9XiFwScWgk4HzpisqCuUegEwhHGF8nYT9KkSWjbtu8IGkmQxUZ9kMUQeZzGIpMqwLoHSy2pWdHiOCbs3rWH2rRuw1xnPz5/ehOczs1gmXHYA1Nh8uSPHB4JyvD1EeZx4fxF+oLFbDt26MiLpyoLfeRmt7qlxTj7vt/HghxBWtdYtFOnTdHSMgLGlXQQh7xMrAU2e/aXhCumQoUKCb/asu6jR49o2rSo58c5ekXoymjMxnr16lMIe9NUYeKkCdEoNuPvoNa3Fv9w9Cjdx2f8+PG0kuXfId8NzS8J4BPAyeKIESMFPmS+q0K3naHVB4AQAJhEg9mjhasA5+bGTRq5xHZVE4OxAke7onxGeECErfD8LGAByJgxg5ClxtWOBOOL9eDBQ1bH8yM4DMAfJJggE24EyHrPZB6FI5D9wU81wFZ/q1ev0Tlpt9Uv1BUBEJjp0qWL+LNVV+YPGDjAJl8AgjRwvSqhXdu2bHSwrUjCEkrfvn1kkTBPVIEXSz3mZwAgQ75+/XpxrMM1FfgWuXPn4pIoWLVqNc2YMSMqI44xKN1Ablz9qEKqDn/geMPcFBw0qnyWcJbGO8Kqma4Et+/Q8mHGMNf7o8mThWaMzDOGV69eE9pGffr0ISyi9h06iB8bL6+qDGBsd/bsOWrQ8G2dkoSxTlzTIAHr81dfAhbEDrZiGVNYv2G9rmrTJvqzuK6QE/Cl/BubwJVgbTFj8bVt20ZWsRuyTDu7W43iXFvrbzH75e7S1f6ZVA4CMUiVTJb51kIcCVq2akULFkR8TKzVAeP02rXr1orIJ4WPLh/UTOvWrdi0U4guP2/ePBQQUF23mPG+TP/sM/ZzHUUpqI2MH1K1zFZ89uxZwqsp7KepAP4aPi7qYkY5Pj6uBo/s0PKhWJFBMCc+mvQRkyoRkj/Xr9+g3Xt208KFITrVQ9kG4fTPpgtVtFb8cjRr2kwotENQAFzO0BWhNIVln+3dI6p9xTael30UH/jpgNbs9OnTdjm1WsXICCTVVCklnMftwZUrl9loXjmCoYImTZtqaoIQp93DzJl5wcH07bZv7XWhK4NvZfT3AasSguTPkCG9KMe5EqaPv2QfYEaGk64DQ2LkyBH0JTsC7Ny5ixATxXUUrpBwXsZCv3vvLh06eJDgvB4O7x0dCWC/HOKj48aOIxxtcuXKJa6lQHGdOxed44775z59ejNZHcJ33d35KvFNDUe4nwZHehvjJ3heMJ0/f94w+6gkbhKwUUgwXk3JfGMIOXE8W1BQJ8FXKV6suDjKoN69+/eE3/CzZ86yeOhm+u6774zNnZ52m39oRzPHuQNc1rgapMcX1nj+dDRmQiwPXR6q89RZpmwZ4XBdzjU5W1LFRyCmZnA3bdwsdivZHup96jkVeIfUmpHDLOvHNUS/0jl6XPtAO3DHsWhxvo4p4HlA7uKc/V94J2Ly3NI/tEd3aHWi8f3x/19+OOxwjnY5Fa+O4sB7fHFvbQxn9akaaLA2jrU8SMsZr8Ss1fsv5nnsDP1fRKb5TCYGPI0Bc0F7+hcwxzcx4EQMmAvaicg0uzIx4GkMmAva07+AOb6JASdiAEyxl440cJw4ntmVAwzATUzq1FFilPaUFxx0JYqPsScL9Y7VVdd5MZmLWcd1GIDEnxd5hSe1kOVe6tSpowR4XTem2XMMMIC7eWfCByOGO7M7s68EigFew5jZb1jW5/LmyStkehPoXM1pmRgwMWAHA1CMibSicoI3au+tECCHS1ATTAyYGEh8GKjF8vQ4VvHfam8W1QvjyK9t2rTVRNYS3yOZMzYx8P+JgdxssALGMngNX2NtvCXebJnxb7JQbxayt8ADgh9r9phgYsDEQMLHAMwq9erZi7y9vMP5r2eNGjX+Yb2QCGAjAO8zg2wai+x5QcEBliocmceRbc3QxICJAfdhAPLtMOjQiD2eJk2SNJx3516BgYFChU1b0JgOa440CX8ZPoujWSCLy65G6E92MxpuifJb5L5pmyOZGDAxoGKAF6/wMQ6NPyigMFzik3MPdnm7U9bTLWhksqcLn6fPnnakl9SEk8W4QUbeuZPIBmZoYsDEgMcw8ILX46+8Hg9zuIYNPoay2vELdTb/A7h/2y8EQZJ9AAAAAElFTkSuQmCC" alt="CN iOS download button"></a></div><footer class=""><div class="_3fFTo _15_Nm"><div class="_1IBgH"><a href="/discover/" target="_blank" rel="noopener"><img src="https://cf.chownowcdn.com/marketplace-react-prod/static/media/cn-logo-footer.2297988a.svg" alt="ChowNow logo"></a></div><div class="_3hM1C"><a href="https://get.chownow.com/" target="_blank" rel="noopener"><h5>About ChowNow</h5></a><a href="https://get.chownow.com/terms-of-service" target="_blank" rel="noopener"><h5>Terms of Use</h5></a><a href="https://get.chownow.com/privacy-policy" target="_blank" rel="noopener"><h5>Privacy Policy</h5></a></div><ol class="_2vI3K"><li class="_2Ygxm"><a href="https://instagram.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M14.194 12.184c-1.15 0-2.082.914-2.082 2.043 0 1.128.932 2.043 2.082 2.043s2.082-.915 2.082-2.043c0-1.129-.932-2.043-2.082-2.043zm4.001 1.256h-.911c.086.287.133.588.133.902 0 1.745-1.443 3.161-3.223 3.161-1.78 0-3.223-1.416-3.223-3.162 0-.313.048-.614.133-.901h-.951v4.436c0 .23.185.416.412.416h7.218a.414.414 0 0 0 .412-.416V13.44zm-1.642-3.274a.472.472 0 0 0-.467.473v1.132c0 .26.21.472.467.472h1.171a.471.471 0 0 0 .467-.473v-1.13c0-.26-.21-.475-.467-.475h-1.171zM10.33 9h7.706c.732 0 1.33.606 1.33 1.348v7.804c0 .742-.598 1.348-1.33 1.348H10.33A1.343 1.343 0 0 1 9 18.152v-7.804C9 9.606 9.599 9 10.331 9z"></path>
    </g>
</svg>
</span></a></li><li class="_2Ygxm"><a href="https://twitter.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M19.17 11.024a4.367 4.367 0 0 1-1.037 1.135v.283a6.46 6.46 0 0 1-.982 3.435 6.406 6.406 0 0 1-1.195 1.425c-.462.411-1.018.74-1.665.987a5.81 5.81 0 0 1-2.09.37c-1.256 0-2.322-.296-3.201-.889.164.025.33.038.494.038.903 0 1.766-.346 2.59-1.036a1.952 1.952 0 0 1-1.207-.439 2.152 2.152 0 0 1-.735-1.078 2.06 2.06 0 0 0 .94-.037 2 2 0 0 1-1.193-.753 2.184 2.184 0 0 1-.477-1.394v-.024c.298.172.612.263.942.271-.62-.436-.93-1.04-.93-1.813 0-.362.093-.716.282-1.06a5.913 5.913 0 0 0 1.901 1.585c.741.39 1.54.61 2.395.659a2.316 2.316 0 0 1-.046-.506c0-.6.202-1.114.605-1.541A1.957 1.957 0 0 1 16.04 10c.596 0 1.106.231 1.53.691a4.153 4.153 0 0 0 1.318-.53 2.063 2.063 0 0 1-.918 1.209c.401-.05.8-.165 1.201-.346"></path>
    </g>
</svg>
</span></a></li><li class="_2Ygxm"><a href="https://facebook.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <path fill="#172534" d="M13.03 19.333v-4.984h-1.342v-1.813h1.343V10.95c0-.704.225-1.297.677-1.774.452-.479 1.12-.718 2.007-.718.223 0 .447.01.67.024.225.019.391.034.498.051l.174.026-.074 1.712h-1.156c-.315 0-.525.075-.628.226-.103.151-.155.378-.155.68v1.36h2.013l-.136 1.812h-1.877v4.984H13.03z"></path>
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
    </g>
</svg>
</span></a></li></ol></div></footer></div></div></div> -->
    <script type="text/javascript" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/vendor.92aa7268.js"></script>
    <script type="text/javascript" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/main.922ccaeb.js"></script>
    <iframe height="0" width="0" style="display: none; visibility: hidden;" src="//8918213.fls.doubleclick.net/activityi;src=8918213;type=chawess1;cat=webcnpvs;ord=258979505290;gtm=2wg3i1;auiddc=1079867989.1553668463;~oref=https%3A%2F%2Feat.chownow.com%2Fdiscover%2F?"></iframe>
    <iframe src="https://pay.google.com/gp/p/ui/payframe?origin=https%3A%2F%2Feat.chownow.com&amp;mid=" height="0" width="0" allowpaymentrequest="true" style="display: none; visibility: hidden;"></iframe>
    <script type="text/javascript" id="">
        ! function(b, e, f, g, a, c, d) {
            b.fbq || (a = b.fbq = function() {
                a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments)
            }, b._fbq || (b._fbq = a), a.push = a, a.loaded = !0, a.version = "2.0", a.queue = [], c = e.createElement(f), c.async = !0, c.src = g, d = e.getElementsByTagName(f)[0], d.parentNode.insertBefore(c, d))
        }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
        fbq("init", "2235850063405947");
        fbq("track", "PageView");
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2235850063405947&amp;ev=PageView&amp;noscript=1"></noscript>
    <script src="https://cdn.siftscience.com/s.js"></script>
</body>

</html>

<head>
    <style type="text/css">
        .gm-control-active>img {
            box-sizing: content-box;
            display: none;
            left: 50%;
            pointer-events: none;
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%)
        }
        
        .gm-control-active>img:nth-child(1) {
            display: block
        }
        
        .gm-control-active:hover>img:nth-child(1),
        .gm-control-active:active>img:nth-child(1) {
            display: none
        }
        
        .gm-control-active:hover>img:nth-child(2),
        .gm-control-active:active>img:nth-child(3) {
            display: block
        }
    </style>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Google+Sans">
    <style type="text/css">
        .gm-ui-hover-effect {
            opacity: .6
        }
        
        .gm-ui-hover-effect:hover {
            opacity: 1
        }
    </style>
    <style type="text/css">
        .gm-style .gm-style-cc span,
        .gm-style .gm-style-cc a,
        .gm-style .gm-style-mtc div {
            font-size: 10px;
            box-sizing: border-box
        }
    </style>
    <style type="text/css">
        @media print {
            .gm-style .gmnoprint,
            .gmnoprint {
                display: none
            }
        }
        
        @media screen {
            .gm-style .gmnoscreen,
            .gmnoscreen {
                display: none
            }
        }
    </style>
    <style type="text/css">
        .gm-style-pbc {
            transition: opacity ease-in-out;
            background-color: rgba(0, 0, 0, 0.45);
            text-align: center
        }
        
        .gm-style-pbt {
            font-size: 22px;
            color: white;
            font-family: Roboto, Arial, sans-serif;
            position: relative;
            margin: 0;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%)
        }
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="apple-itunes-app" content="app-id=1210943577">
    <link rel="shortcut icon" type="image/png" href="https://cf.chownowcdn.com/marketplace-react-prod/cn-favicon.png">
    <link rel="stylesheet" href="https://cf.chownowcdn.com/marketplace-react-prod/leitura.css">
    <title>Search and Order from Restaurants Near You - ChowNow</title>
    <script type="text/javascript" async="" src="https://cdn.amplitude.com/libs/amplitude-4.2.1-min.gz.js"></script>
    <script type="text/javascript" async="" src="//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script src="https://jssdkcdns.mparticle.com/js/v2/b8d12eac313e7346815ffa7251890c8f/mparticle.js" async=""></script>
    <script src="https://connect.facebook.net/signals/config/127575507831621?v=2.8.45&amp;r=stable" async=""></script>
    <script src="https://connect.facebook.net/signals/config/2235850063405947?v=2.8.45&amp;r=stable" async=""></script>
    <script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/gtm/js?id=GTM-PCJXRV5&amp;cid=1417183059.1553583506"></script>
    <script src="https://maps.googleapis.com/maps/api/js?client=gme-chownowinc&amp;libraries=places&amp;callback=initMap&amp;channel=discover-web" async=""></script>
    <script async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-PWPXQFW"></script>
    <script>
        window.dataLayer = []
    </script>
    <script async="" src="https://pay.google.com/gp/p/js/pay.js"></script>
    <script type="text/javascript">
        window.cn = {
            appVersion: "1.7.11",
            isMparticleReady: !1
        }
    </script>
    <script>
        ! function(e, t, a, n, g) {
            e[n] = e[n] || [], e[n].push({
                "gtm.start": (new Date).getTime(),
                event: "gtm.js"
            });
            var m = t.getElementsByTagName(a)[0],
                r = t.createElement(a);
            r.async = !0, r.src = "https://www.googletagmanager.com/gtm.js?id=GTM-PWPXQFW", m.parentNode.insertBefore(r, m)
        }(window, document, "script", "dataLayer")
    </script>
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/vendor.c1f28a76.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/assets/cf.chownowcdn.com/marketplace-react-prod/static/css/main.cf5db557.css" rel="stylesheet">
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/0.e4bdc38e.chunk.js"></script>
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/3.b47ed560.chunk.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/common.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/util.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/controls.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/places_impl.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/geocoder.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/usage.js"></script>
    <script type="text/javascript" charset="utf-8" async="" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/1.355c2953.chunk.js"></script>
    <style id="detectElementResize" type="text/css">
        @keyframes resizeanim {
            from {
                opacity: 0;
            }
            to {
                opacity: 0;
            }
        }
        
        .resize-triggers {
            animation: 1ms resizeanim;
            visibility: hidden;
            opacity: 0;
        }
        
        .resize-triggers,
        .resize-triggers > div,
        .contract-trigger:before {
            content: " ";
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            overflow: hidden;
            z-index: -1;
        }
        
        .resize-triggers > div {
            background: #eee;
            overflow: auto;
        }
        
        .contract-trigger:before {
            width: 200%;
            height: 200%;
        }
    </style>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/map.js"></script>
    <style type="text/css">
        .gm-style {
            font: 400 11px Roboto, Arial, sans-serif;
            text-decoration: none;
        }
        
        .gm-style img {
            max-width: none;
        }
    </style>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/onion.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/stats.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/35/10a/marker.js"></script>
</head>

<body style="overflow: visible;">
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PWPXQFW" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <script type="text/javascript">
        ! function() {
            function n() {
                var n = document.createElement("script");
                n.src = "https://cdn.siftscience.com/s.js", document.body.appendChild(n)
            }
            window.attachEvent ? window.attachEvent("onload", n) : window.addEventListener("load", n, !1)
        }()
    </script>
    <div id="root">
        <div class="_3D-MR">
            <div>
                <nav class="_279YF Q4N6P">
                    <div class="_1ejiX">
                        <div class=""><a class="_1_jiM" href="/discover/"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
</svg>
</span></a>
                            <div>
                                <div class="bm-overlay _39lkJ" style="position: fixed; z-index: 1000; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.3); opacity: 0; transform: translate3d(100%, 0px, 0px); transition: opacity 0.3s ease 0s, transform 0s ease 0.3s;"></div>
                                <div id="" class="bm-menu-wrap _2EsCV _3kSno" style="position: fixed; right: inherit; z-index: 1100; width: 300px; height: 100%; transform: translate3d(-100%, 0px, 0px); transition: all 0.5s ease 0s;">
                                    <div class="bm-menu _13dWY" style="height: 100%; box-sizing: border-box; overflow: auto;">
                                        <nav class="bm-item-list _2p5QV" style="height: 100%;">
                                            <div class="e7rlY" style="display: block; outline: none;">
                                                <header class="_3Y-p3"><span class="isvg loaded _2gHpi"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
</svg>
</span></header>
                                                <div class="csPk3">
                                                    <ul class="_3FgVj">
                                                        <li class="_3gq9n"><a class="_2kuAl" href="/discover/">Home</a></li>
                                                        <li class="_3gq9n"><a class="_2kuAl" href="<?php echo site_url('UserController/Register');?>">Sign Up</a></li>
                                                        <li class="_3gq9n"><a class="_2kuAl" href="<?php echo site_url('UserController/UserLogin');?>">Log In</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <footer class="_34O-K">
                                                <div class="_3fFTo _15_Nm">
                                                    <div class="i4GhA _3R0zp"></div>
                                                    <div class="_3hM1C"><a href="https://get.chownow.com/" target="_blank" rel="noopener"><h5>About ChowNow</h5></a><a href="https://get.chownow.com/terms-of-service" target="_blank" rel="noopener"><h5>Terms of Use</h5></a><a href="https://get.chownow.com/privacy-policy" target="_blank" rel="noopener"><h5>Privacy Policy</h5></a></div>
                                                    <ol class="_2vI3K">
                                                        <li class="_2Ygxm"><a href="https://instagram.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M14.194 12.184c-1.15 0-2.082.914-2.082 2.043 0 1.128.932 2.043 2.082 2.043s2.082-.915 2.082-2.043c0-1.129-.932-2.043-2.082-2.043zm4.001 1.256h-.911c.086.287.133.588.133.902 0 1.745-1.443 3.161-3.223 3.161-1.78 0-3.223-1.416-3.223-3.162 0-.313.048-.614.133-.901h-.951v4.436c0 .23.185.416.412.416h7.218a.414.414 0 0 0 .412-.416V13.44zm-1.642-3.274a.472.472 0 0 0-.467.473v1.132c0 .26.21.472.467.472h1.171a.471.471 0 0 0 .467-.473v-1.13c0-.26-.21-.475-.467-.475h-1.171zM10.33 9h7.706c.732 0 1.33.606 1.33 1.348v7.804c0 .742-.598 1.348-1.33 1.348H10.33A1.343 1.343 0 0 1 9 18.152v-7.804C9 9.606 9.599 9 10.331 9z"></path>
    </g>
</svg>
</span></a></li>
                                                        <li class="_2Ygxm"><a href="https://twitter.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M19.17 11.024a4.367 4.367 0 0 1-1.037 1.135v.283a6.46 6.46 0 0 1-.982 3.435 6.406 6.406 0 0 1-1.195 1.425c-.462.411-1.018.74-1.665.987a5.81 5.81 0 0 1-2.09.37c-1.256 0-2.322-.296-3.201-.889.164.025.33.038.494.038.903 0 1.766-.346 2.59-1.036a1.952 1.952 0 0 1-1.207-.439 2.152 2.152 0 0 1-.735-1.078 2.06 2.06 0 0 0 .94-.037 2 2 0 0 1-1.193-.753 2.184 2.184 0 0 1-.477-1.394v-.024c.298.172.612.263.942.271-.62-.436-.93-1.04-.93-1.813 0-.362.093-.716.282-1.06a5.913 5.913 0 0 0 1.901 1.585c.741.39 1.54.61 2.395.659a2.316 2.316 0 0 1-.046-.506c0-.6.202-1.114.605-1.541A1.957 1.957 0 0 1 16.04 10c.596 0 1.106.231 1.53.691a4.153 4.153 0 0 0 1.318-.53 2.063 2.063 0 0 1-.918 1.209c.401-.05.8-.165 1.201-.346"></path>
    </g>
</svg>
</span></a></li>
                                                        <li class="_2Ygxm"><a href="https://facebook.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <path fill="#172534" d="M13.03 19.333v-4.984h-1.342v-1.813h1.343V10.95c0-.704.225-1.297.677-1.774.452-.479 1.12-.718 2.007-.718.223 0 .447.01.67.024.225.019.391.034.498.051l.174.026-.074 1.712h-1.156c-.315 0-.525.075-.628.226-.103.151-.155.378-.155.68v1.36h2.013l-.136 1.812h-1.877v4.984H13.03z"></path>
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
    </g>
</svg>
</span></a></li>
                                                    </ol>
                                                </div>
                                            </footer>
                                        </nav>
                                    </div>
                                    <div>
                                        <div class="bm-cross-button" style="position: absolute; width: 24px; height: 24px; right: 8px; top: 8px;"><span style="position: absolute; top: 6px; right: 14px;"><span class="bm-cross" style="position: absolute; width: 3px; height: 14px; transform: rotate(45deg);"></span><span class="bm-cross" style="position: absolute; width: 3px; height: 14px; transform: rotate(-45deg);"></span></span>
                                            <button style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; margin: 0px; padding: 0px; border: none; text-indent: -9999px; background: transparent; outline: none; cursor: pointer;">Close Menu</button>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="bm-burger-button _3-Pa0" style="z-index: 1000;"><span class="isvg loaded bm-icon" style="width: 100%; height: 100%;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12">
    <g fill="#0B2135" fill-rule="nonzero">
        <path d="M.686 6.5C.307 6.5 0 6.164 0 5.75S.307 5 .686 5h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686zM.686 1.5C.307 1.5 0 1.164 0 .75S.307 0 .686 0h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686zM.686 11.5c-.379 0-.686-.336-.686-.75S.307 10 .686 10h14.628c.379 0 .686.336.686.75s-.307.75-.686.75H.686z"></path>
    </g>
</svg>
</span>
                                        <button style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; margin: 0px; padding: 0px; border: none; opacity: 0; font-size: 8px; cursor: pointer;">Open Menu</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="FUzDZ">
                            <div class="geosuggest _2mRdX">
                                <div class="geosuggest__input-wrapper">
                                    <input class="geosuggest__input _3VqJs hdyK6" type="text" autocomplete="nope" placeholder="City or Address" value="Gulshan-e-Iqbal, Bl-6,Aladin Park, karachi, Pakistan, Block 10-A Gulshan-e-Iqbal, Karachi, Karachi City, Sindh, Pakistan">
                                </div>
                                <div class="geosuggest__suggests-wrapper">
                                    <ul class="geosuggest__suggests _1j2-_ geosuggest__suggests--hidden _321SV"></ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="">
                            <ul class="_7BFWB">
                                <li>
                                    <h5><a class="_3pRye">Sign Up</a></h5></li>
                                <li>
                                    <h5><a class="_3pRye">Log In</a></h5></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="_1yCYr">
                    <div>
                        <div class="_1Wbti"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="130" height="32" viewBox="0 0 130 32">
    <g fill="#FFF" fill-rule="evenodd">
        <path d="M22.478 19.672a.194.194 0 0 1-.274 0l-2.818-3.182a.494.494 0 0 0-.698.697l2.843 3.156a.351.351 0 1 1-.498.498l-3.162-2.838a.492.492 0 1 0-.698.697l3.187 2.813a.193.193 0 0 1-.206.318s-2.208-.822-3.323-1.936c-.689-.687-1.031-1.512-1.045-2.29l-.004.004c-.005-.775.1-1.285-.564-1.964l-.846-.78-.89.82c-.666.85-.511 1.42-.515 2.115l-.004-.004c-.015.824-.378 1.699-1.107 2.427-1.363 1.36-3.882 2.1-4.98 1.003-1.099-1.096-.36-3.612 1.003-4.973.729-.728 1.605-1.09 2.43-1.106l-.004-.004c.692-.004 1.249.136 2.061-.548l6.17-6.679a1.15 1.15 0 0 1 1.66-.036 1.145 1.145 0 0 1-.036 1.656l-4.57 4.207.743.803c.676.655 1.187.551 1.96.556l-.003.003c.779.015 1.605.357 2.294 1.044 1.12 1.118 1.937 3.313 1.937 3.313a.193.193 0 0 1-.043.21zM8.548 7.88a1.15 1.15 0 0 1 1.659.036l3.022 3.27-1.311 1.42-3.334-3.07a1.146 1.146 0 0 1-.036-1.656zm20.124 6.426C28.672 6.409 22.26.008 14.351.008 6.44.008.029 6.41.029 14.306c0 .198.005.396.013.593-.013.632.053 2.052.713 3.911a14.272 14.272 0 0 0 2.78 4.867c1.952 2.429 4.984 5.046 9.685 7.454a2.483 2.483 0 0 0 2.26 0c4.702-2.408 7.734-5.025 9.687-7.454a14.275 14.275 0 0 0 2.779-4.867c.66-1.86.726-3.279.713-3.911.008-.197.013-.395.013-.593zM104.626 17.57c0 1.646 1.254 2.986 2.823 2.986s2.845-1.34 2.845-2.986c0-1.645-1.276-2.961-2.845-2.961-1.569 0-2.823 1.316-2.823 2.961zm8.602 0c0 3.241-2.598 5.888-5.779 5.888s-5.778-2.647-5.778-5.887c0-3.24 2.597-5.888 5.778-5.888 3.181 0 5.779 2.648 5.779 5.888zM55.357 11.79a4.225 4.225 0 0 0-2.84 1.032l-.113-4.336c0-.254-.242-.514-.586-.466l-2.326.352v14.927h3.041v-6.536c0-.95.634-1.823 1.564-2.022 1.277-.273 2.434.729 2.434 1.963v6.595h2.997v-7.106c0-2.34-1.828-4.364-4.171-4.402M85.282 12.163l-2.343 6.253-1.988-6.224a.422.422 0 0 0-.399-.294h-2.671l.33.92-1.811 5.598-2.365-6.254a.422.422 0 0 0-.395-.273h-2.885l4.48 11.41h1.714a.422.422 0 0 0 .398-.28l2.321-6.483 2.302 6.482c.06.168.219.28.398.28h1.713l4.48-11.409h-2.884a.422.422 0 0 0-.395.274M63.157 17.57c0 1.646 1.255 2.986 2.824 2.986 1.568 0 2.845-1.34 2.845-2.986 0-1.645-1.277-2.961-2.845-2.961-1.57 0-2.824 1.316-2.824 2.961zm8.602 0c0 3.241-2.597 5.888-5.778 5.888-3.182 0-5.779-2.647-5.779-5.887 0-3.24 2.597-5.888 5.779-5.888 3.18 0 5.778 2.648 5.778 5.888zM126.691 12.163l-2.343 6.253-1.987-6.224a.422.422 0 0 0-.399-.294h-2.672l.33.92-1.81 5.598-2.366-6.254a.421.421 0 0 0-.395-.273h-2.885l4.481 11.41h1.714a.422.422 0 0 0 .398-.28l2.322-6.483 2.3 6.482c.06.168.22.28.398.28h1.714l4.48-11.409h-2.884a.421.421 0 0 0-.396.274M43.144 23.458c-4.107 0-7.448-3.403-7.448-7.587 0-4.183 3.332-7.586 7.427-7.586 2.092 0 3.963.893 5.562 2.655L47.257 12.7a.542.542 0 0 1-.778.073c-.948-.82-2.128-1.526-3.697-1.4-1.988.159-3.678 1.721-4.007 3.725-.465 2.83 1.675 5.288 4.369 5.288 1.2 0 2.363-.468 3.335-1.333a.54.54 0 0 1 .79.09l1.419 1.883c-1.376 1.525-3.441 2.433-5.544 2.433M89.095 23.299V7.953h2.259c.179 0 .347.087.45.233l6.215 9.225V7.953h2.985V23.3h-2.198a.552.552 0 0 1-.45-.233L92.09 13.78V23.3h-2.996"></path>
    </g>
</svg>
</span></div>
                        <div class="_3eFiO _23Txc">
                            <ul class="_7BFWB">
                                <li>
                                    <h5><a class="_3pRye">Sign Up</a></h5></li>
                                <li>
                                    <h5><a class="_3pRye">Log In</a></h5></li>
                            </ul>
                        </div>
                    </div>
                    <div class="_1zBBv">
                        <h1 class="_2SF-u">Hungry? Find the food you're looking for.</h1>
                        <h2 class="_3YGFz">Your city's best eats, ready to be ordered online.</h2>
                        <div class="_2Q2fa">
                            <div class="FUzDZ">
                                <div class="geosuggest _2mRdX">
                                    <div class="geosuggest__input-wrapper">
                                        <input class="geosuggest__input _3VqJs l81ey" type="text" autocomplete="nope" placeholder="City or Address" value="">
                                    </div>
                                    <div class="geosuggest__suggests-wrapper">
                                        <ul class="geosuggest__suggests _1j2-_ geosuggest__suggests--hidden _321SV"></ul>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo site_url('UserController/viewRestaurantsPage');?>"><button class="_2jjjt _2oxVn _2xk2l _2uOCG">Search</button></a>
                            
                        </div>
                    </div>
                </div>
                <div class="_2GFuf _15_Nm">
                    <p class="izuoC">Order <strong>pickup</strong> or <strong>delivery</strong> from the best restaurants in your city.</p>
                    <!-- <div class="Ocoal">
                        <div class="_3jW__ _2YVVH">
                            <h2 class="_30Zd8">Los Angeles, CA</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Sunny Side Up</h5></div>
                        </div>
                        <div class="_3jW__ _2gkDy">
                            <h2 class="_30Zd8">Chicago, IL</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Windy City Eats</h5></div>
                        </div>
                        <div class="_3jW__ _3g9Bg">
                            <h2 class="_30Zd8">New York City, NY</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Nosh that never sleeps</h5></div>
                        </div>
                        <div class="_3jW__ _3g6Rj">
                            <h2 class="_30Zd8">Seattle, WA</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Fresh Catches Daily</h5></div>
                        </div>
                        <div class="_3jW__ _2N9N9">
                            <h2 class="_30Zd8">San Francisco, CA</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Best of the bay</h5></div>
                        </div>
                        <div class="_3jW__ _2cwPE">
                            <h2 class="_30Zd8">Denver, CO</h2>
                            <div class="_2ZFjK">
                                <h5 class="_1DPcw">Mile High Cravings</h5></div>
                        </div>
                    </div> -->
                    <div class="Ocoal">
                        <?php
                            /*foreach($cities as $key=>$val){
                                ?>
                                <div class="_3jW__ _2YVVH">
                                    
                                <h2 class="_30Zd8"><a href="<?php echo site_url(); ?>/UserController/getRestaurant/<?php echo $val['city_id']; ?>"><?php echo $val['name'];?></a></h2>
                                <div class="_2ZFjK">
                                <h5 class="_1DPcw">Sunny Side Up</h5></div>
                            </div>
                                <?php
                            }*/
                        ?>
                        <?php
                            foreach($cities as $key=>$val){
                                ?>
                        <div class="" style="width:300px;height: 300px;">
                            
                            <h2 class="_30Zd8">
<a href="<?php echo site_url(); ?>/UserController/getRestaurant/<?php echo $val['city_idd']; ?>"><?php echo $val['city_name'];?><img width="290px" height="290px" src="<?php echo base_url();?>admin/assets/uploads/<?php echo $val['city_image'];?>"></a>
                            </h2>

                        
                        </div>
                      <?php
                            }
                        ?>
                        
                    </div>
                </div>
                <div class="_3rDWn">
                    <div class="i4GhA"></div>
                    <h2 class="_1-_0E">New customers await.</h2>
                    <p class="_31mCS"><strong>Own a restaurant?</strong> Help hungry customers discover you through ChowNow.</p>
                    <a href="https://get.chownow.com/demo/?utm_source=discover_homepage&amp;utm_medium=banner&amp;utm_campaign=restaurant_learn_more%2Fdemo&amp;utm_content=button" target="_blank" rel="noopener">
                        <button class="_2jjjt _2tWsz _2xk2l _2uOCG">Learn More</button>
                    </a>
                </div>
                <div class="_1SJY6">
                    <h2 class="_2Bcv-">Get the ChowNow app.</h2>
                    <p class="DZKHZ">It's the easiest way to order the food you want, when you want it, wherever you are.</p>
                    <a href="https://app.appsflyer.com/id1210943577?pid=DiscoverWeb&amp;c=home_bottombanner" target="_blank" rel="noopener"><img class="tbTHA" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPQAAABICAYAAADBJ9jwAAAAAXNSR0IArs4c6QAAIXdJREFUeAHtXQd8T9cXPwlaQonE3nvV3tQIRVGb2MSmRY2aRW012moVJWhjh1i1q3ZVtbX33rR2B1o0fv/zvcl9ue/lNzJ+I+n/nc8nuXu883v33XPPPcOLDLBhwwafZ8+etQ5/GV7fy8urMFkoA1fxNlQzkyYGTAy4GwNe9C+vxzsWL8sxb/LelDt37tVly5Z9oU7DS02sXLmyKXnRLIvFkvnJkyd08dJF+vOPP+nly5dqNTNuYsDEgAcwkDRpUvL19aV8+fLRq6++ihlc8vby7hkYGLhDTkdb0CvCVgzyIq+pT58+9Vq+bBnt27+PLC8tsp4ZmhgwMZBAMJAsWTKqU6cONWnSlJIlTRZu8ba806pFq3mYnljQYWFhzSxkWXXx4kWvWbNm0aNHDxPI1M1pmBgwMWALA1mzZqW+fd+jTBkzhXOdBi1bttzqffDgQR9ezDOxM5uL2RbqzHwTAwkPA7du3aI5c+YQ87uS8Ozm7tq1K7n31atXA3FmXrZsqbkzJ7zfzJyRiQG7GLh69Qpt2ryJeWWWHHcf3O3gHR4eXhcMsB/2/2C3oVloYsDEQMLEwI7t24k3ZaKX1NybT9EFLl2+ZDLAEuZvZc7KxIBDDPzxxx909+5dXspeRb35X/o///zTYSOzgokBEwMJFwORazgTBEZAdifcmZozMzFgYsAhBiArwufoJKYEmENUmRVMDCQeDCT6BV2ieAkaN248rV27jiBJY0LMMODv708lS5SkjBkyxqyBE2th7FIlS+H+1Im9uq6rXLlyifn6+Pi4bhAn9ZxoVwAW8qefTqeKFStoqHCniCqkdfq914/8/PzJz9+PkiRJQtevX6fr167R5i2b6d69e9q8EmIEUkYzPv+cP4bjaMrUKW6dYqOGjWjmzJk0cdIkmjRpolvHjstgE8ZPoKZNm1JAjRr0yy8/x6ULt7VJlAt68KDBNGrUh7yIogiMR49+d6vMeYoUKWjs2LEUHv6ScMH/999/U7OmzSh58lfpyZOnNGv2LF4sYyOuE9z2c5oDxQcDGTJkoKxZstKRo0fi041H20atCI9OI+aDT5w4icaMGaNbzGh94KcDMe/EiTXPnz9PhYsUotJlSlG69P7UsFFDun37Ng0ZPJjw4TEhcWCgXLnydPnSFerWvXvimLCNWSaqHbp58+bUv18/q4+yaeNGq/nuzMTl/s6dO6lBw7fpyOGjNGLESFq7bi1duHBBN438+fNT2TJlKWWqVHT8+DH6+Wc9GRcQEEA+Pinpu++20YsXEdpxBQoUYC2b/Nz/Dvrnn39Ef6w+R4ULFxF93Lx5k1KnTk1VqlSls2fP0K+//koNGjSgdOnS0w/79tHxE8d1c7CXQD+VK1WmPHnz0pUrV2g/Cx3hrtMIxYsVp5IlS9JrXP/SxYu0jedr7diDMzOeydc3Lf0Uhw8vNIveeOMNKliwkPhY/vjjfnHvqs5H4mfPnt2UNm1aqlevPr14/lxIUTk6/kB7qXq1auTFmg3Zs2Wn+vXfpjt37tChQwfVIUQ8L+OkerXq9PjJY1q/fr32W6gVQb1Vq1qNChQsQBfOX6A9e/cICk6t47I4q0zefLfPuxaflCkS9F/6DOks9+/f5zXzMtofX6pb0vr5unX+mTJnFPM4ffq01XHnz58nynv16qkr/3T6pxa+JrT8+++/FtY7F3U2bdpoyZwlk1Zv1apVIr9W7Te1vC1bt4i8wJaBWt7iJYtFXoUK5UUeQuAnOHiu5eTJkyKONMYzzqPve31F+dixY7T+8A68VbeO5fbtW6KMJQhFePvX25a69d7S1RswcIAoe/jwoYWPGyJ+8OAvFt+0aXT18Ay8OEQ55oLn3r17t0hPmDhBV9faO1iufFnLmTNnRH05H/64WDp0bK9rO378OFFn2PChFtZL0MZ78OCB5fWiRXR1jePw0UirL98vFqfU2qxZs1qUf/7555bnz59rdU+cOBHtvStWvKgF7wTq8cfQwh84y+Ejhy25cufU+jOO74z0OH7+FStXWBINyd2tazfyZ+aTNRg5cgTx4rBW5LG802fOiLFff/11bQ6dgjrRgP79xU6WNVsW4kVMi5cs4R2hPo0bO06rt3XrFhF/o/IbIsQXP6B6AO/W/1LdunW1ejV417t27TqdOHlC5D17HoGD7kw2YicvXKQwdQzqKM7xkydPoVdeeUVray2CnW3pkmWUIoUP1ahZg/gjSs2aNSO/tH60eNESoYsr221hxl/5CuUpW/aslCNndgoNXUFlypShTp06yypCZ3fB/K/Ejok5ZcqciTp07EAVKkQxMrXKViK4tcC4efLkoZatWon5VKlalfijQPPnLRD5spn8/T8cNZp69Owunn3evHnMtExLY8dE4VbWV8OZs2ZS23btRFZY2CrKxxRUz549tCps6EPEmzRpQo0aN6SSpUoy1fIjFS36OnXl91KFkK9D+D31pxIlixN/SET9UkzFjB49Rq3msniiWdD4Qa3BmjVracnSJdaKPJonSWVv7ygUDxgwkElSC/Xp04f++usvQa69//5Ajj+mzp27MEMtuZjzt9u+FfUqM5kJCAioIa7klrICTd233hJ5IP2gPrdhw3qRxj855s2bt2j4B8MF13316tW0j0nuNGlSE9rYg6COQeKj+cUXM7RjAOaylPGbLp0/BQa21JqDo3/q1Cl67bXXKE/uPHTmzGlRVrx4ca0OSNccObLT8tDltGz5MvHM33yzjubMnaPVsRdp0KAhk9kFKHRFKDEVI6oeOXKYpk//lD9Oyahb16jz7ot/X4jyxYsX0Zo1a8Szjxw1UuSVKlXK3jD0+PFjun8/4lbiydMnfFy5TUx5aG14SxbxkaNG0N69e8URamrkzYDad1X+2JQuXZoW8Ryu8W0HAEew69dvUJPGTUTa1f+i3jZXjxSP/rFz4JrKCKtWraZOnYOM2QkinS9vPjEPJhdFiHMgdhqcdfHCSIBiDBYGOPY4ywGYTOTrkV+oYoWKfK7zEjs4XuQtW7ZQlixZqFjRYlSdd2zAemVBiwz+h5dJvoTIA5MOAC6uPShcpIgo/tlwNSPP+IUKFtSa4zf5asHXdO3qdTpw4IC4dUChv18UFVWAdzrAj/v3i1D+u2jgKch8Y1ikcGGR9YuBxyDnhzOqEa6w9pEELFR8LB09t6zvKMTClHDr9i0RVfsuVChivn379KW7d+5pf/jw+vqmYb6I6++xk8oJJuQQSIukesQ0Hz58xAynD8SXMCHOG6Tt22+/LaZ2/EQEOSznqV61ybxkySJ+Bj77ySwC2V2BSdrC/FK/xdYplsKKzL7vxTVZterVCTvh/fsP6Mcff9TayIi6mJH30hI7E1Js1kZ2JULcuQOe8tWchFVhq4ntWdGQoUNoBe+gGTNmpMOHDstiEeJuHqBSKSIdmS8KY/DP21Bfzufvp1Hzkd1Ee3YWiZTzkHWcEUrmH+tCaN1JwaaVYSujfcRQSf19tUZOjiSKBc0MBtq+Y4fgbILzy4YM3cc1jCXC8fLiPJw3bx5at24dMaNI9IAzHluEIXC4sVNfvnxZ5KdLl47PYsXETsK66dpo2I1Hjx5Nbdu2E6T1Rubi//7778wl/omqVqkiON4QYJEvltYwHpFTp06K1lWZ47t9x3atJ5D8gBORnHJIeEGgBzv33EjyGR8eI5y/cF5k1az5JoUsDNGKwRmPCZxkygUAjjEzGbUmxvloBfGIyOOKH1MecQV57IBuxMJFC+PaTbzaeXRB42WGCGB+vpLJmSOHWLCX+EXfvXuXeHnlkzG3kBo3biSTIsRXF1cZb75Zi/IzqZqMd8WnLNABVdBdu3aKnQvME1dDypQp+eWuSKlSpuJrioLUtk0bwrnqypWr1LtPb93wOHfNnz+fSdWvqHuP7oKRN2vmbGYevULMpdUtTjC6ILDShc/WCOUVymZWZh88eIg4u476cJSu//gmQkJCmGk3kPr07kNHjx4lXAG1bNlKMMbOnj1HOI8DcF7FsRIfIlxdgQKYwkw3gLob48OL8zwYaxcuXqCNnK5StQq14j4BckcTCSv/cG4+deq0aA99/TDe+QICAggkLaiTucFzrbSKW9aNGzdFw6r88WjM592TjP9Lly7FqrM9e/aIoxJ4ETjmrF69SjwjGKPHjx9nPkPE8StWncayskcWdNGiRZkx1Ff8sGBuGAHc3B3MpV3CHOCNGzdozB7UgwBAUFCQYDKkTetrbCrSQ4cM4XvTP2nBVwvo44+nWb1DtdowDplg+uzYvkNriR9y2PBhFBwcHI3zDuZQ9uzZxf300SNHRRswyaZOm0YzmBFlhK1btzIXtSstZ4aSBOzKEyZMENJo4GQ7E6CC1yKwBS0MWUhLFi/WusZ5vlPnTkzuh4s8nPE/+fQTGvT++xrJ//nnM/gYUIJS8odNAqiSdu3bUejy5TRs6FDxB4m+nr16iv6TvxrBBJT1jSHGa9O2tZjPp598QvgDXLhwkZmInZz6u4KvsXJlGH/AAmnZ0qUEDnn/Af2NU7KbBrnfvkN7mvPlXPpg+HDxJxuMHDnSLQvaC/fQu/fuzhry9ddybJeFYPB8+OFoIUUV00F+//0PAhME5oSxE2bLljWmTUW9X3/7jRdFF95t9sSqnaPKeBaQmalYOAS7NIQXQDKDEeMI0qdPrzH5IPAB5XRr4McMpsyZM4sdGuS2BHzxIWoqyXaZj7MlBCzAaMNcJEQwZXxFHsoAYGqBwQYBCr7fl1VFCB4Adt9s2bLx4jnPgipndUw2WRnMudx8fACpjt2sIFMoIF2N8wJ+ypUrJygQfBxQB3Uf8C77253fZHc2Q1BjRViABoIuV5laO3X6lLi6UhvgqihTpkz0G//e+OBIkEeBmO6OlStXpjSp0whBHFBGAOAhTZo04rmAdwBwhOMTfm/J0RYFkf9y5cpFBQswPpiaAW6s1VHrxzc+bNhwgVO3LWhcbyxatJjq1K4d37nHuv3z5y8oqFMQS/Z8E+u2ZgMTA4kBA3JB69mZLpz5vOB5HlnMeCSQ9QvmLxA7qgsf0ezaxIDHMeCWBd2bmSwNGzb06MPO/nI2nTt3zqNzMAc3MeBqDLicKZYpU2aCPqkn4f1Bg9h+8ZeenII5tokBt2DA5Tt0z549BcnrlqexMggU6c3FbAUxZtZ/EgMuXdAQd8Q9qqcA1xtSntdTczDHNTHgTgy4dEFXqlRJCPW784HUsSZMHK+7w1bLzLiJgf8iBlx6hi5dqrTHcAah/G++cf81Fe5Xcc+sAqSuYnI/rbZJzHHce8t74zxshOEfFjDBfTeMLuxh6TNVkykxP2dCnLtLFzT0Yz0FEB+V8rnunEPo8hUs3JFfN+RAlqiSMs+6gv9YIkuWrCw49CG1Y/lzb3bhYA0gBQg5cQj7WLOCYq2NmRdzDLiU5IYkkqfgqiIp5a45FGH1Q+Nixtju0oV113NaG6d169Z0/Nhx6tC+vc3FjHbQLCvBmmLmYraGxfjnuXSHfjVSYT/+04x9D6r4X+xbx62FunChvCBVPqFEAkUUo4hl3EZJeK3wfMFz5+kMN0LF9SDb5LrBhhDSpPEV4pPFihVjMVkfNlawyeZDQKS2fPnywq7XXyxb/vEnH9usaxZEx4BLF7Qj4fvo03FeDmR73Q2NGjXWhmS7YGzho4VIQwe6IVvf+DrE9fLy2gTcGJk6dZpuMX/FegHQV4/0t6TNBDLdzZs1J6kWqRVERnKwxt33e/dpjNSFixYZq5hpBxhwKcn9z7MI65QO5uCSYmg1uROg41ysWFFtyLnBc4SKn8xozPao/osAKyslS0RZkzl67Bi9917faIsZzw7FEJjnOXz4kFVUYMHD1JEJcceASxf0LTa34ymAITqQb+4CldyGoX1oFakaXjDy5+vr667puG2c/Pn1ZoD27tlrVTPLbRP6Px/IpSQ37Gd5CqB2WI0tb6iLypVzadw4ityGMj6MK0BfuXnzZmJYMIPeZqN5MPRnDwayIUGoAQL2s3mhdWzXGwA98PZsmRJG6GDuB9dybEaWlnF/sIdtC4azWh1UJQG7du0iNgcs4lATbNeuvWBQoT/oj+N6bcnSxWxgYreoE5N/bKdWVw14jy10ZkuhUHOEWyEVyvMzT50yVcsCX8SW2x5YRm3JRgxrszYf7Jdjp3/8+Imw4QaDF8tDQ9noQIQ6pNahEunSpStJm2lsdpetmIaKDaFly5YU1LGTMLAIqynTWL/eCFBbxdiNGjUi2BXDcQ/qrrDYsm7tWmEk0W03Lq60yz1o8CDW+Y5uR9tdefxiutQWsrSnnL9APmF/WT7X0GFDxLh58uTW5cP+tmxjK4QNZ9nP8uXLLWl8U1vmzQvW8mSZGrLlTwt77bDaNxv519qiH/90fhZpz1vtQ43zOxHN3rSt+ebLn0/rH30wWW1hW2hW52KrD9jAVse3FWe9Yqv9shEFC2yH22qHfNgOt2cHnFVrtfZr166xpEzlYwkLC9Py0Afschuf4Y0qb1hYX1xXzzgP2O8uXqJYtLbGvuKTdotdbqO1R+OXzdXp6tWr8TVKB1cPI0zWqNQ97H8BoLwPi5gSYC4JBhHsAbw9SPDnXQaWQLp16yazrIbwkLFu7TdWTfrAHpsEcNrnzgkWO73MsxaCmbdixcoYHVmw6x0+HGUc0McnBdt82yjMBlnr29l5sHyzmPXsM0dSNegfVmBgogh+xyTA59iIDz5g6yfWGW04Jknw4bM83Bi1aNFcZlkNy5YtR5s3bRamhmUFGEX46aef2SBghCEE5Bct+jptWL/RadZH5VjWQpeeoY+xmxeQPZ6EGTO+YJO31V06hcYKd/vEiZPCfYwccB3boZYA22GqoXyZr4bPnkUtQLhcCerYURRv/fZbNg8UKKy29OjRg3bs2Kk2Y/tqlWno0GG6PCSev4jqD3ay5REAUnSw9QXx3HfeeYctiv6ga1u7Vi3q27evLs9Wonfv3nzECNeK06dPJxbZ93u/50XRwqHVzalTp1IrvscexP7AVNi1a7fIRxn++vV/Ty2mmjVr0uSPJmvXgzBkAfNP7NWEcubKIcIhbPoI+RKwSAe9P0gmtVA6KUAG3OH069dfK4O9Mczlxs0oM76wYAJTRalTvybq3blzVzgngGnhmm/WEGNPnDhR6wOmqoawLTiXgytJbpAQbAPLLjliJE9ckQa51a1bV5eQPPziCFczct4TJozXjVOwUAHd88Otij3Savv27br66Hccu2oxtgFJyNJnurosXmqBix61LvuS0tVBf4OHDNbVQf3UaV6LRorzmdXi5582Wl21fxkH2YvxJR7UEKRy9+7dLKleS2m3rzJlS+vahywMsVkffV2+fFlX3+geR86tY1AHXT28D/jdZDlCtj+nq4P5szMBm8cHkN/yGdnXmE2SWv2NcBzJniObblx1DvGJu4XkxtcIlho9DSC3YPQtjI3AQdbamdCwYSOdZNQ3BjNHN27c0JGkdeq8pXnIsDYPdadA+YEDP9HkKZOjVeW3iXe0QcIrgyyE0AbueVVQdyfkwxzyLHb9YgQw8XDddPfuPa0IbmSkfXEt00aEz528QwWwtcxT0WowL0EYTTx86AiTn1FXe9EqxiIDeM+dO5fWAmSutEqqZUZGIBOAWwcJeB/glkiFl5EGEGUeKCX2y6W5GZL5CGEwv1OnTlpWMFsfhYlmawA3OxJwHGnevIVMuiR0KcmNGcOUq3qecMlTxLBT+JDCOdaZoHK3L126LLxgGPtfy5xOCVh0tWvXkcloofHFWmTHvjOsYs7+cpauj0rMvVbBaMp44cIQtVgXh5XOeYr9axRK/1q6ijYS8ABSoWJ5CmTOsLqAZPX8+fOxhdSdwjOkzItrWIedD6ig2u1W82UcH3QVatSoqSajXbXBdY+tW5pKFStppDY6kTcHug4jE0ydsMujZ1pRXpZXcCUkdWXn6BveAlavWS1kfF09lqP+oRiwcuUKR9ViXI57ZZxzJZw7f45qWflg/GWwBIo7a9UnlWyPEDuvCkbPG2oZ4ocO6YU0YKPcHuCqyx4cNvSX10F/1vqC7XD84Wqs33v9hFtbWS9VqpQEh24lShSPkcVP2c4Ywh2vCtI9jpqnxo3lqhNB1DPKLByw4pFE9mdUOoKDvH8G2xaiUm2V52JroK4Ely9oTB7OxdrznafKCXblQ9nqm91tOlWeGvfK0o0Nxqxfr574szW+zAelgLtLa3eTxhfr77+juK+yvRrCaZwK8MFsDxy5Y7l2/Zquedp4CMPsZ59W+Kv7Vl0+8swXniDRORb16DFjmBnXSzdWbBLpmPGmgq3dVNbB0UcFeTcv84x4Vxlgso4M4ZpJBXgRiSmkZU+ergSXk9yYPIzzwWC+JwFXGTC670xQye3Y9AvO6JvsHsYaGHdoa3XUPGN9ax8JtX5s46Bq4gtbv91KzBTTdVPTQPLqCmOQUPUE8NsajxbGLuAySCV+jHgz1sfxwxYkZyEWFdBvTP8ePLivNnV63C07NGY9esxovrKpp9vRnP40djoMYcUIFrKwUyN2RZA7Vs/j9+7dF87kbPUCY+0wNi8Bst140R2BI3cxOXPm1HXhyHiAI8dtObLn0Pf36KEuHdcEnhXXP9mzZxNdwAgCcAj57rgAnhMeHQHQvYaqrpFaUfuFbL9KIRq18Yw7tNrWGFedHqCsUqWKVplnxnbuSLttQWOX/mLmFzRwwAB3PJduDHBune0HCvfJ4JZKYOkrdqk6UiajhVh4p9lPkwSQ61hc0r2MzDeGudn38smTJ43ZWrpIkde1OCJnz57RpY0JKJHYe/Gh060CvGY4C+7evaMtaCwu2Jyzt6DtLTLwK8A9lwBPH/aeS/XjjDaQkdCButp1BdETV9h7hwroG77IEgK4heSWD/rRR5PYLchlmXRbOGToYJ3zO2cM3KRxU1030iG5LlNJwBXKMXZYJsHf30/Imsu0rbBGQICtIpH/Tq93dOXfs8tZeyA9N1qrgw9Mjx49dUX7vrffn66ynQRcx6gfH8iiG6kJo7plOjsqsEZ5886dO9sZnXTO4VFxJ8vZxxX27t2jaxrIctwJBdy6oMGQCQrqqJPccTUi4ICMZXKdOgx2FvXaBGKGcPPqCNYbbJypGlqyrXFX6tq1m+YHS9aR4bvv9mZlgKh7dZD99owHoB08N8InkzWABBUkmiSARFbdysp8NQQHF/OA5JQ9mD79M0qRIrlWZdu2bVpcRmBzTBXXLM0mrGwdOZYuXcK7exTDEIw3aNhZg9q1alPVqlW0IkgvLlac8aHAiHetspUIjm4//LBfK6lZswZTngO1tCcjbl3QeNAjR48QSyq55ZlBDfQf0M/pY9XiFwScWgk4HzpisqCuUegEwhHGF8nYT9KkSWjbtu8IGkmQxUZ9kMUQeZzGIpMqwLoHSy2pWdHiOCbs3rWH2rRuw1xnPz5/ehOczs1gmXHYA1Nh8uSPHB4JyvD1EeZx4fxF+oLFbDt26MiLpyoLfeRmt7qlxTj7vt/HghxBWtdYtFOnTdHSMgLGlXQQh7xMrAU2e/aXhCumQoUKCb/asu6jR49o2rSo58c5ekXoymjMxnr16lMIe9NUYeKkCdEoNuPvoNa3Fv9w9Cjdx2f8+PG0kuXfId8NzS8J4BPAyeKIESMFPmS+q0K3naHVB4AQAJhEg9mjhasA5+bGTRq5xHZVE4OxAke7onxGeECErfD8LGAByJgxg5ClxtWOBOOL9eDBQ1bH8yM4DMAfJJggE24EyHrPZB6FI5D9wU81wFZ/q1ev0Tlpt9Uv1BUBEJjp0qWL+LNVV+YPGDjAJl8AgjRwvSqhXdu2bHSwrUjCEkrfvn1kkTBPVIEXSz3mZwAgQ75+/XpxrMM1FfgWuXPn4pIoWLVqNc2YMSMqI44xKN1Ablz9qEKqDn/geMPcFBw0qnyWcJbGO8Kqma4Et+/Q8mHGMNf7o8mThWaMzDOGV69eE9pGffr0ISyi9h06iB8bL6+qDGBsd/bsOWrQ8G2dkoSxTlzTIAHr81dfAhbEDrZiGVNYv2G9rmrTJvqzuK6QE/Cl/BubwJVgbTFj8bVt20ZWsRuyTDu7W43iXFvrbzH75e7S1f6ZVA4CMUiVTJb51kIcCVq2akULFkR8TKzVAeP02rXr1orIJ4WPLh/UTOvWrdi0U4guP2/ePBQQUF23mPG+TP/sM/ZzHUUpqI2MH1K1zFZ89uxZwqsp7KepAP4aPi7qYkY5Pj6uBo/s0PKhWJFBMCc+mvQRkyoRkj/Xr9+g3Xt208KFITrVQ9kG4fTPpgtVtFb8cjRr2kwotENQAFzO0BWhNIVln+3dI6p9xTael30UH/jpgNbs9OnTdjm1WsXICCTVVCklnMftwZUrl9loXjmCoYImTZtqaoIQp93DzJl5wcH07bZv7XWhK4NvZfT3AasSguTPkCG9KMe5EqaPv2QfYEaGk64DQ2LkyBH0JTsC7Ny5ixATxXUUrpBwXsZCv3vvLh06eJDgvB4O7x0dCWC/HOKj48aOIxxtcuXKJa6lQHGdOxed44775z59ejNZHcJ33d35KvFNDUe4nwZHehvjJ3heMJ0/f94w+6gkbhKwUUgwXk3JfGMIOXE8W1BQJ8FXKV6suDjKoN69+/eE3/CzZ86yeOhm+u6774zNnZ52m39oRzPHuQNc1rgapMcX1nj+dDRmQiwPXR6q89RZpmwZ4XBdzjU5W1LFRyCmZnA3bdwsdivZHup96jkVeIfUmpHDLOvHNUS/0jl6XPtAO3DHsWhxvo4p4HlA7uKc/V94J2Ly3NI/tEd3aHWi8f3x/19+OOxwjnY5Fa+O4sB7fHFvbQxn9akaaLA2jrU8SMsZr8Ss1fsv5nnsDP1fRKb5TCYGPI0Bc0F7+hcwxzcx4EQMmAvaicg0uzIx4GkMmAva07+AOb6JASdiAEyxl440cJw4ntmVAwzATUzq1FFilPaUFxx0JYqPsScL9Y7VVdd5MZmLWcd1GIDEnxd5hSe1kOVe6tSpowR4XTem2XMMMIC7eWfCByOGO7M7s68EigFew5jZb1jW5/LmyStkehPoXM1pmRgwMWAHA1CMibSicoI3au+tECCHS1ATTAyYGEh8GKjF8vQ4VvHfam8W1QvjyK9t2rTVRNYS3yOZMzYx8P+JgdxssALGMngNX2NtvCXebJnxb7JQbxayt8ADgh9r9phgYsDEQMLHAMwq9erZi7y9vMP5r2eNGjX+Yb2QCGAjAO8zg2wai+x5QcEBliocmceRbc3QxICJAfdhAPLtMOjQiD2eJk2SNJx3516BgYFChU1b0JgOa440CX8ZPoujWSCLy65G6E92MxpuifJb5L5pmyOZGDAxoGKAF6/wMQ6NPyigMFzik3MPdnm7U9bTLWhksqcLn6fPnnakl9SEk8W4QUbeuZPIBmZoYsDEgMcw8ILX46+8Hg9zuIYNPoay2vELdTb/A7h/2y8EQZJ9AAAAAElFTkSuQmCC" alt="CN iOS download button"></a>
                </div>
                <footer class="">
                    <div class="_3fFTo _15_Nm">
                        <div class="_1IBgH">
                            <a href="/discover/" target="_blank" rel="noopener"><img src="https://cf.chownowcdn.com/marketplace-react-prod/static/media/cn-logo-footer.2297988a.svg" alt="ChowNow logo"></a>
                        </div>
                        <div class="_3hM1C"><a href="https://get.chownow.com/" target="_blank" rel="noopener"><h5>About ChowNow</h5></a><a href="https://get.chownow.com/terms-of-service" target="_blank" rel="noopener"><h5>Terms of Use</h5></a><a href="https://get.chownow.com/privacy-policy" target="_blank" rel="noopener"><h5>Privacy Policy</h5></a></div>
                        <ol class="_2vI3K">
                            <li class="_2Ygxm"><a href="https://instagram.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M14.194 12.184c-1.15 0-2.082.914-2.082 2.043 0 1.128.932 2.043 2.082 2.043s2.082-.915 2.082-2.043c0-1.129-.932-2.043-2.082-2.043zm4.001 1.256h-.911c.086.287.133.588.133.902 0 1.745-1.443 3.161-3.223 3.161-1.78 0-3.223-1.416-3.223-3.162 0-.313.048-.614.133-.901h-.951v4.436c0 .23.185.416.412.416h7.218a.414.414 0 0 0 .412-.416V13.44zm-1.642-3.274a.472.472 0 0 0-.467.473v1.132c0 .26.21.472.467.472h1.171a.471.471 0 0 0 .467-.473v-1.13c0-.26-.21-.475-.467-.475h-1.171zM10.33 9h7.706c.732 0 1.33.606 1.33 1.348v7.804c0 .742-.598 1.348-1.33 1.348H10.33A1.343 1.343 0 0 1 9 18.152v-7.804C9 9.606 9.599 9 10.331 9z"></path>
    </g>
</svg>
</span></a></li>
                            <li class="_2Ygxm"><a href="https://twitter.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
        <path fill="#172534" d="M19.17 11.024a4.367 4.367 0 0 1-1.037 1.135v.283a6.46 6.46 0 0 1-.982 3.435 6.406 6.406 0 0 1-1.195 1.425c-.462.411-1.018.74-1.665.987a5.81 5.81 0 0 1-2.09.37c-1.256 0-2.322-.296-3.201-.889.164.025.33.038.494.038.903 0 1.766-.346 2.59-1.036a1.952 1.952 0 0 1-1.207-.439 2.152 2.152 0 0 1-.735-1.078 2.06 2.06 0 0 0 .94-.037 2 2 0 0 1-1.193-.753 2.184 2.184 0 0 1-.477-1.394v-.024c.298.172.612.263.942.271-.62-.436-.93-1.04-.93-1.813 0-.362.093-.716.282-1.06a5.913 5.913 0 0 0 1.901 1.585c.741.39 1.54.61 2.395.659a2.316 2.316 0 0 1-.046-.506c0-.6.202-1.114.605-1.541A1.957 1.957 0 0 1 16.04 10c.596 0 1.106.231 1.53.691a4.153 4.153 0 0 0 1.318-.53 2.063 2.063 0 0 1-.918 1.209c.401-.05.8-.165 1.201-.346"></path>
    </g>
</svg>
</span></a></li>
                            <li class="_2Ygxm"><a href="https://facebook.com/ChowNow/" target="_blank" rel="noopener"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g fill="none" fill-rule="evenodd" transform="translate(1 1)">
        <path fill="#172534" d="M13.03 19.333v-4.984h-1.342v-1.813h1.343V10.95c0-.704.225-1.297.677-1.774.452-.479 1.12-.718 2.007-.718.223 0 .447.01.67.024.225.019.391.034.498.051l.174.026-.074 1.712h-1.156c-.315 0-.525.075-.628.226-.103.151-.155.378-.155.68v1.36h2.013l-.136 1.812h-1.877v4.984H13.03z"></path>
        <circle cx="14" cy="14" r="14" stroke="#172534" stroke-width="2"></circle>
    </g>
</svg>
</span></a></li>
                        </ol>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/vendor.92aa7268.js"></script>
    <script type="text/javascript" src="https://cf.chownowcdn.com/marketplace-react-prod/static/js/main.922ccaeb.js"></script>
    <iframe height="0" width="0" style="display: none; visibility: hidden;" src="//8918213.fls.doubleclick.net/activityi;src=8918213;type=chawess1;cat=webcnpvs;ord=258979505290;gtm=2wg3i1;auiddc=1079867989.1553668463;~oref=https%3A%2F%2Feat.chownow.com%2Fdiscover%2F?"></iframe>
    <iframe src="https://pay.google.com/gp/p/ui/payframe?origin=https%3A%2F%2Feat.chownow.com&amp;mid=" height="0" width="0" allowpaymentrequest="true" style="display: none; visibility: hidden;"></iframe>
    <script type="text/javascript" id="">
        ! function(b, e, f, g, a, c, d) {
            b.fbq || (a = b.fbq = function() {
                a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments)
            }, b._fbq || (b._fbq = a), a.push = a, a.loaded = !0, a.version = "2.0", a.queue = [], c = e.createElement(f), c.async = !0, c.src = g, d = e.getElementsByTagName(f)[0], d.parentNode.insertBefore(c, d))
        }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
        fbq("init", "2235850063405947");
        fbq("track", "PageView");
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2235850063405947&amp;ev=PageView&amp;noscript=1"></noscript>
    <script src="https://cdn.siftscience.com/s.js"></script>

</body>