<head>
    <link href="//fonts.googleapis.com/css?family=Open+Sans:600,300,400,700|Open+Sans+Condensed:300,700" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/cf.chownowcdn.com/d079bc02779e805afb86a68539a4ceb9/static/cn-admin-base.css">
    <style type="text/css">
        body {
            background: #ecf0f1;
        }
        body #content-header {
            display: none;
        }
        .btn-login {
            background-color: #007170;
            margin-top: 20px;
        }
        .btn-login:hover {
            background-color: #1abc9c;
        }
        .forgot-password {
            float: right;
        }
        .forgot-password a {
            cursor: pointer;
        }
        .instructions {
            margin-bottom: 5px;
        }
        .instructions #close {
            float: right;
            cursor: pointer;
            visibility: hidden;
        }
        .instructions ol li {
            margin-left: 20px;
            list-style: decimal;
        }
        .page-header {
            text-align: center;
        }
        .login-block {
            padding: 15px 40px;
        }
        .login-block input {
            width: 100%;
        }
        .login-block .line {
            margin-bottom: 0;
        }
        .login-block p {
            margin-top: 10px;
            line-height: 20px;
        }
    </style>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/cf.chownowcdn.com/dashboard-web/assets/dashboard-web-92a84f132645b0f925e693048bbf598c.css">
        <script type="text/javascript" src="<?php echo base_url();?>assets/cloudfront.loggly.com/js/loggly.tracker-2.1.min.js" async=""></script>
</head>
<form  method="POST" action="<?php echo site_url('UserController/registerdb');?>" class="block well login-block" >
        <div class="page-header">
            <h4>Register here</h4>
            <div class="line clearfix">
            <a href="<?php echo site_url('UserController/UserLogin');?>">
                
                Login
            </a>
        </div>
        </div>
        <div class="error response-message" style="display: none"></div>
        <div class="line">
            <label for="">First Name</label>
            <input type="text" id="fname" name="fname" value="">
            <?php echo form_error('fname', '<div class="error" style="color:red;">', '</div>'); ?>

        </div>
        <div class="line">
            <label for="">Last Name</label>
            <input type="text" id="lname" name="lname" value="">
            <?php echo form_error('lname', '<div class="error"  style="color:red;">', '</div>'); ?>
        </div>
        <div class="line">
            <label for="">Fone Number</label>
            <input type="text" id="fnumber" name="fnumber" value="">
            <?php echo form_error('fnumber', '<div class="error"  style="color:red;">', '</div>'); ?>
        </div>
        <div class="line">
            <label for="">Email Address</label>
            <input type="text"  name="email" value="">
            <?php echo form_error('email', '<div class="error"  style="color:red;">', '</div>'); ?>
        </div>
        <div class="line">
            <label for="">Password</label><span class="forgot-password"></span>
            <input type="password" autocomplete="off"  name="password" value="">
            <?php echo form_error('password', '<div class="error"  style="color:red;">', '</div>'); ?>
        </div>
        <div class="line clearfix">
            <input type="submit" class="btn btn-login" value="Register">
        </div> 
</form>


        
        
        


