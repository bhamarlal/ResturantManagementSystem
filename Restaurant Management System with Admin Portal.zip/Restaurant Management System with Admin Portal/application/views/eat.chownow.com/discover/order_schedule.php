
<head>
    <meta charset="utf-8">
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Search and Order from Restaurants Near You - ChowNow</title>
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/vendor.c1f28a76.css" rel="stylesheet">
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/main.cf5db557.css" rel="stylesheet">

</head>
<div style="height: 130px; left: 0px; position: absolute; top: 0px; width: 100%;">

    <nav class="_279YF">
        <div class="_1ejiX">
<div class="">
<a class="_1_jiM" href="/discover/">
    <span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
        </svg>
</span>
</a>
                
</div>
            <div class="FUzDZ">
                <div class="geosuggest _2mRdX">
                    <div class="geosuggest__input-wrapper">
                        <input class="geosuggest__input _3VqJs hdyK6" type="text" autocomplete="nope" placeholder="City or Address" value="New York, NY, USA">
                    </div>
                    
                </div>
            </div>
        </div>
        <div>
            <div class="">
                <ul class="_7BFWB">
                    <!-- <li>
                        <h5><a class="_3pRye">Sign Up</a></h5></li>
                    <li>
                        <h5><a class="_3pRye">Log In</a></h5></li> -->
                        <li class="_3gq9n"><a class="_2kuAl" href="<?php echo site_url('UserController/Register');?>">Sign Up</a></li>
                                                        <li class="_3gq9n"><a class="_2kuAl" href="<?php echo site_url('UserController/UserLogin');?>">Log In</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <?php foreach($restaurant as $key=>$val){
    ?>
    <div class="_2km-B"><h1 class="_994Ga"><?php echo $val['name'];?></h1><ul class="_16yYm"><li><?php echo $val['description'];?></li></ul></div>
    <div class="_30aCR"><div class="_3jf5g"><h3 class="_3Ko5_">Order for</h3><div class="i4GhA"></div><h5 class="f1u85"><input type="radio" id="pickup" name="fulfillmentType" value="pickup" checked=""><label for="pickup">Pickup</label><span class="I_zOt">/</span><input type="radio" id="delivery" name="fulfillmentType" value="delivery"><label for="delivery">Delivery</label><div class="EfzFF">
    <button class="_2jjjt _3pseA _1snNl _4Gfmk _2x5M6 _2uOCG"><span class="_1AMXe"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <g fill="#0B2135" fill-rule="nonzero">
        <path d="M.562 6.464v-1.5H15.16v1.5z"></path>
        <path d="M1.86 3.036v11.071h12.003V3.036H1.86zm-.737-1.5H14.6c.407 0 .736.336.736.75v12.571c0 .414-.33.75-.736.75H1.123a.744.744 0 0 1-.737-.75V2.286c0-.414.33-.75.737-.75z"></path>
        <path d="M3.685.9c0-.414.33-.75.737-.75s.737.336.737.75v2.6c0 .414-.33.75-.737.75a.744.744 0 0 1-.737-.75V.9zM10.564.9c0-.414.33-.75.737-.75s.737.336.737.75v2.6c0 .414-.33.75-.737.75a.744.744 0 0 1-.737-.75V.9zM3.44 9.75A.744.744 0 0 1 2.701 9c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75h-.983zM7.37 9.75A.744.744 0 0 1 6.633 9c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75H7.37zM11.3 9.75a.744.744 0 0 1-.736-.75c0-.414.33-.75.737-.75h.982c.407 0 .737.336.737.75s-.33.75-.737.75h-.982zM3.44 12.75a.744.744 0 0 1-.738-.75c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75h-.983zM7.37 12.75a.744.744 0 0 1-.737-.75c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75H7.37z"></path>
    </g>
</svg>
</span>

<div class="TKuVS"><button class="Q1Fza _1H2KH"><span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <g fill="#0B2135" fill-rule="nonzero">
        <path d="M.562 6.464v-1.5H15.16v1.5z"></path>
        <path d="M1.86 3.036v11.071h12.003V3.036H1.86zm-.737-1.5H14.6c.407 0 .736.336.736.75v12.571c0 .414-.33.75-.736.75H1.123a.744.744 0 0 1-.737-.75V2.286c0-.414.33-.75.737-.75z"></path>
        <path d="M3.685.9c0-.414.33-.75.737-.75s.737.336.737.75v2.6c0 .414-.33.75-.737.75a.744.744 0 0 1-.737-.75V.9zM10.564.9c0-.414.33-.75.737-.75s.737.336.737.75v2.6c0 .414-.33.75-.737.75a.744.744 0 0 1-.737-.75V.9zM3.44 9.75A.744.744 0 0 1 2.701 9c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75h-.983zM7.37 9.75A.744.744 0 0 1 6.633 9c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75H7.37zM11.3 9.75a.744.744 0 0 1-.736-.75c0-.414.33-.75.737-.75h.982c.407 0 .737.336.737.75s-.33.75-.737.75h-.982zM3.44 12.75a.744.744 0 0 1-.738-.75c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75h-.983zM7.37 12.75a.744.744 0 0 1-.737-.75c0-.414.33-.75.737-.75h.983c.407 0 .737.336.737.75s-.33.75-.737.75H7.37z"></path>
    </g>
</svg>
</span><span class="_1H2KH">Schedule Order</span><span class="isvg loaded _1irKm"><svg width="14" height="14" viewBox="0 0 12 11" xmlns="http://www.w3.org/2000/svg">
    <path d="M1.374 6.138L5.25 9l5.25-7.625" stroke-width="2" stroke="#FFF" fill="none" fill-rule="evenodd"></path>
</svg>
</span></button><form class="_15Bfv" action="<?php echo site_url(); ?>/UserController/scheduletime/<?php echo $val['id'];?>" method="post"><select class="LWuKC _3QAo8 _191Bg" name="selectedDateOption"><?php
    $nextDay = 86400;
    for($i=0;$i<=6;$i++){
        if($i !== 0){
            
            ?>
            <option><?php echo $tomorrow = date("l, F jS", time() + $nextDay); ?></option>
            <?php
            $nextDay = $nextDay+86400;
        }
        else {
            ?>
                <option><?php echo $tomorrow = date("l, F jS", time()); ?></option>
            <?php
            
        }
    }
    ?></select><div class="DGzWN">Date cannot be blank</div><select class="LWuKC _3QAo8 _191Bg" name="selectedTimeOption"><option value="" disabled="">Select Time</option><option>9:15 - 9:30 AM</option><option>9:30 - 9:45 AM</option><option>9:45 - 10:00 AM</option><option>10:00 - 10:15 AM</option><option >10:15 - 10:30 AM</option><option>10:30 - 10:45 AM</option><option>10:45 - 11:00 AM</option><option>11:00 - 11:15 AM</option><option>11:15 - 11:30 AM</option><option >11:30 - 11:45 AM</option><option>11:45 - 12:00 PM</option><option>12:00 - 12:15 PM</option><option>12:15 - 12:30 PM</option><option>12:30 - 12:45 PM</option><option >12:45 - 1:00 PM</option><option>1:00 - 1:15 PM</option><option>1:15 - 1:30 PM</option><option>1:30 - 1:45 PM</option><option>1:45 - 2:00 PM</option><option>2:00 - 2:15 PM</option><option>2:15 - 2:30 PM</option><option>2:30 - 2:45 PM</option><option>2:45 - 3:00 PM</option><option>3:00 - 3:15 PM</option><option>3:15 - 3:30 PM</option><option>3:30 - 3:45 PM</option><option>3:45 - 4:00 PM</option><option>4:00 - 4:15 PM</option><option>4:15 - 4:30 PM</option><option>4:30 - 4:45 PM</option><option>4:45 - 5:00 PM</option><option>5:00 - 5:15 PM</option><option>5:15 - 5:30 PM</option><option>5:30 - 5:45 PM</option><option>5:45 - 6:00 PM</option><option >6:00 - 6:15 PM</option><option>6:15 - 6:30 PM</option><option>6:30 - 6:45 PM</option><option>6:45 - 7:00 PM</option><option>7:00 - 7:15 PM</option><option>7:15 - 7:30 PM</option></select><div class="DGzWN">Time cannot be blank</div><button class="_2jjjt _9D67c _2x5M6 _1G0tP _2uOCG">Start Order</button></form></div>

</div>
</div>
    <?php
    }?>










































