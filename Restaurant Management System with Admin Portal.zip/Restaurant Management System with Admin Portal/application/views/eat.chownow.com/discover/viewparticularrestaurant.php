
<?php
/*$data=array_merge($restaurant,$menu_cat);
foreach($data as $val){
    
    
}
die;*/
?>
<head>
    <meta charset="utf-8">
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Search and Order from Restaurants Near You - ChowNow</title>
    <link href="https://cf.chownowcdn.com/marketplace-react-prod/static/css/vendor.c1f28a76.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/assets/cf.chownowcdn.com/marketplace-react-prod/static/css/main.cf5db557.css" rel="stylesheet">
</head>
<div style="height: 130px; left: 0px; position: absolute; top: 0px; width: 100%;">

    <nav class="_279YF">
        <div class="_1ejiX">
<div class="">
<a class="_1_jiM" href="/discover/">
    <span class="isvg loaded"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="41" viewBox="0 0 37 41">
    <path fill="#FD4F57" fill-rule="evenodd" d="M28.926 26.114c-.098.1-.257.1-.355 0l-3.655-4.227a.63.63 0 0 0-.906 0 .665.665 0 0 0 0 .925l3.688 4.195a.475.475 0 0 1 0 .661.45.45 0 0 1-.647 0l-4.1-3.771a.63.63 0 0 0-.907 0 .665.665 0 0 0 0 .926l4.134 3.738c.099.1.099.263 0 .364a.247.247 0 0 1-.267.058s-2.863-1.092-4.31-2.572c-.893-.913-1.337-2.01-1.355-3.043l-.005.005c-.006-1.03.13-1.707-.732-2.609l-1.097-1.036-1.153 1.088c-.865 1.13-.664 1.888-.67 2.811l-.005-.005c-.019 1.095-.49 2.257-1.436 3.224-1.768 1.808-5.035 2.79-6.46 1.333-1.424-1.456-.466-4.8 1.302-6.608.946-.967 2.082-1.449 3.153-1.469l-.006-.005c.898-.005 1.62.18 2.673-.729l8.004-8.874a1.468 1.468 0 0 1 2.151-.048c.6.614.579 1.614-.046 2.2l-5.926 5.59.962 1.067c.878.871 1.54.733 2.543.739l-.004.005c1.01.018 2.082.473 2.975 1.386 1.453 1.486 2.513 4.403 2.513 4.403a.261.261 0 0 1-.056.278m-17.524-15.65c.553-.638 1.455-.615 1.984.05L17 15.037 15.432 17l-3.987-4.245c-.576-.61-.595-1.652-.043-2.29M37 18.671C37 8.36 28.717 0 18.5 0S0 8.36 0 18.672c0 .26.007.517.017.775-.017.826.068 2.68.92 5.107a18.691 18.691 0 0 0 3.591 6.356c2.523 3.173 6.44 6.59 12.512 9.735a3.176 3.176 0 0 0 2.92 0c6.073-3.144 9.99-6.562 12.512-9.735a18.692 18.692 0 0 0 3.59-6.355c.853-2.428.938-4.283.921-5.108.01-.258.017-.516.017-.775"></path>
        </svg>
</span>
</a>
                
</div>
            <div class="FUzDZ">
                <div class="geosuggest _2mRdX">
                    <div class="geosuggest__input-wrapper">
                        <input class="geosuggest__input _3VqJs hdyK6" type="text" autocomplete="nope" placeholder="City or Address" value="New York, NY, USA">
                    </div>
                    
                </div>
            </div>
        </div>
        <div>
            <div class="">
                <ul class="_7BFWB">
                    <li>
                        <h5><a class="_3pRye">Sign Up</a></h5></li>
                    <li>
                        <h5><a class="_3pRye">Log In</a></h5></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="_1asKa">
        <div style="margin-top:-60px;">
        <form action="" autocomplete="off" class="_3pb5d"><span class="isvg loaded _2QxvD"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <g fill="none" fill-rule="evenodd" stroke="#0B2135" stroke-width="1.5" transform="translate(1 1)">
        <circle cx="7.694" cy="7.694" r="7.694"></circle>
        <path stroke-linecap="round" d="M18.026 18.026l-4.894-4.894"></path>
    </g>
</svg>
</span>
        
        
        	
        	<div class="_1lc3I">
        		<a href="<?php echo site_url('UserController/searchmenu');?>">
            		<input type="text" name="search" readonly="" class="_3jMSe _3QAo8 _2oh-A" placeholder="Search" value="">
            	</a>
        </div>
        
        <button class="_2jjjt ZE704 SbhZ_ _2uOCG" type="button"><span class="isvg loaded _1HctD"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">

</svg>
</span>Filters</button>
    </form>
</div>

    <div class="_1nA0v">
        <div class="_3B8NU">
            <div class="_1MpIv kayL9">
                <input class="_1-bKv" type="checkbox" value="true">
                <div class="_2K-r9"><span class="isvg loaded _3d9a2"><svg width="14" height="14" viewBox="0 0 12 11" xmlns="http://www.w3.org/2000/svg">
    <path d="M1.374 6.138L5.25 9l5.25-7.625" stroke-width="2" stroke="#FFF" fill="none" fill-rule="evenodd"></path>
</svg>
</span></div>
                <label>Open Now</label>
            </div>
            <div class="_1MpIv kayL9">
                <input class="_1-bKv" type="checkbox" value="false">
                <div class="_2K-r9"><span class="isvg loaded _3d9a2"><svg width="14" height="14" viewBox="0 0 12 11" xmlns="http://www.w3.org/2000/svg">
    <path d="M1.374 6.138L5.25 9l5.25-7.625" stroke-width="2" stroke="#FFF" fill="none" fill-rule="evenodd"></path>
</svg>
</span></div>
                <label>Delivery</label>
            </div>
        </div>
        <h6 class="yF-WX">21 results</h6></div>

        <?php
            
            
            foreach($restaurant as $key=>$val){

                ?>
                
                <div style="height: 130px; left: 0px;  top: 0px; width: 100%;">
                    <div class="_1y1_S _12X9a">
                    <a href="<?php echo site_url(); ?>/UserController/getmenu/<?php echo $menu_cat['0']['id']; ?>">
                        <div class="ODUu0">
                            <h4 class="_1z4pL"><?php echo $val['name'];?></h4>
                                <ul class="_2dR8f _16yYm">
                                    <li><?php echo $val['description'];?></li>
                                </ul>
                            <div class="_37zvf">
                                <h6 class="_9ZsQk"><?php echo $val['time'];?></h6>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>
            </a>
                <?php
                break;
            }

        ?>
        
        
    
    <!-- </div> -->
    

</div>
<div class="_2Ke_7">
    






<div class="mapouter" style="float:right;margin-top:-70px;"><div class="gmap_canvas" style="position: fixed;"><iframe width="870" height="700" id="gmap_canvas" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Werbung: <a href="https://www.jetzt-drucken-lassen.de">jetzt-drucken-lassen.de</a></div><style>.mapouter{position:relative;text-align:right;height:700px;width:870px;}.gmap_canvas {overflow:hidden;background:none!important;height:700px;width:870px;}</style></div>
</div>





