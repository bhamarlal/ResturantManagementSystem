



    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Dashboard 1</h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>
                <!-- /# row -->
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="card-header">
                                    <h4>Booking Form</h4>
                                    <div class="booking-system-item">
                                        <form>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Full Name">
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Last Name">
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="E-mail">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control calendar" placeholder="Date" id="text-calendar">
                                                        <span class="ti-calendar form-control-feedback booking-system-feedback"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Time">
                                                        <span class="ti-time form-control-feedback booking-system-feedback"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Phone">
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <button type="button" class="btn btn-primary btn-rounded  m-l-5">Submit</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->

                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="card-header">
                                    <h4>Customer Booking Table</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/8.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Natalie Portman <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/2.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Jennifer Lawrence <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/3.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Margot Robbie <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/4.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Scarlett Johansson <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/5.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Emma Stone <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/6.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Eva Green <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/7.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Keira Knightley <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/8.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Alexandra Daddario <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo base_url();?>admin/assets/assets/images/bookingSystem/2.png" alt="" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading">Natalie Portman <span>5 min ago</span> </h4>
                                                    <p>New Food Menu was awesome</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# main content -->
                </div>
                <!-- /# container-fluid -->
            </div>
            <!-- /# main -->
        </div>
    </div>
    <!-- /# content wrap -->