

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Favourite Menu List</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li><a href="#">Components </a></li>
                                    <li class="active">Favourite Menu</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->






                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                                <div class="card alert">
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="favourite-menu-details">
                                        <table class="table">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <div class="favourite-menu-img">
                                                        <img src="<?php echo base_url();?>admin/assets/assets/images/product_1/download.jpg" alt=""/>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-des">
                                                        <div class="product_name">
                                                            <h4>Maxican Hot Pizza</h4>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="favourite-menu-button">
                                                        <div class="prdt_add_to_curt">
                                                            <button type="button" class="btn btn-success btn-lg btn-rounded m-b-10 m-l-5">$29</button>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
                </div><!-- /# main content -->





            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->
