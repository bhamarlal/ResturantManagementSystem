<div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1></h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Add Menu Category</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="card-header">
                                    <h4>Add Menu Category</h4>
                                    <?php
                                    if($this->session->flashdata('msg')){
                                        if($this->session->flashdata('msg')=='Menu Category added Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                                    <div class="card-header-right-icon">
                                        <ul>
                                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                            <li class="doc-link"><a href="#"><i class="ti-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body">

									<div class="menu-upload-form">
										<form class="form-horizontal" method="post" action="<?php echo site_url('admin/Welcome/edit_menu_category_db');?>">
                                            <?php foreach($menuCategory as $val){
                                                ?>
                                                <div class="form-group">
                                                <label class="col-sm-2 control-label">Menu Category Name</label>
                                                <div class="col-sm-10">
                                                <input type="text" name="menuCategoryName" class="form-control" value="<?php echo $val['name'];?>">
                                            </div>
                                        </div>
                                        <input type="hidden" name="menuid" value="<?php echo $val['id'];?>">
                                                <?php
                                            }?>
                                        
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit"class="btn btn-lg btn-primary">Upload</button>
                                            </div>
                                        </div>

                                    </form>
									</div>
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
				</div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->