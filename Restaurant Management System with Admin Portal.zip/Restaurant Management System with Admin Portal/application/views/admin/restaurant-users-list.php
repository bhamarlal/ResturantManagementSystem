
	
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Dashboard 1</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <?php
                                    if($this->session->flashdata('msg')){
                                        if($this->session->flashdata('msg')=='User Delete Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="order-list-item">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Fone Vumber</th>
                                            <th>Email</th>
                                            <th>Action</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach($users as $key=>$val){
                                                ?>
                                                <tr>
                                                <td><?php echo $val['fname'];?></td>
                                                <td><?php echo $val['lname'];?></td>
                                                <td><?php echo $val['phone_number'];?></td>
                                                <td><?php echo $val['email'];?></td>
                                                <td><div class="prdt_add_to_cart">
                                            <button type="button" class="btn btn-primary btn-rounded  m-l-5"><a href="<?php echo site_url(); ?>/admin/Welcome/deleteUser/<?php echo $val['id']; ?>">Delete</a></button>
                                        </div></td>
                                                
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        

                                        
                                        </tbody>
                                    </table>
                                    <div class="pagination-container clearfix">
                                    <div class="pull-right">
                                    <?= $this->pagination->create_links(); ?>
                                    </div>
                                </div>
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
                </div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->