
	
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Dashboard 1</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="order-list-item">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Order Date</th>
                                            <th>Order Schedule</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count='';
                                            foreach($orderdetail as $key=>$val){
                                                 $count++;
                                                if($count>1){
                                                    break;
                                                }
                                                   
                                                    
                                                ?>
                                                <tr>
                                                <td><?php echo $val['orderdate'];?></td>
                                                <td><?php echo $val['schedule'];?></td>
                                                
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        

                                        
                                        </tbody>
                                    </table>
                                    
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
                </div>
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="order-list-item">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Menu Name</th>
                                            <th>Description</th>
                                            <th>Image</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Total Price</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            
                                            foreach($orderdetail as $key=>$val){  
                                                ?>
                                                <tr>
                                                <td><?php echo $val['menu_name'];?></td>
                                                <td><?php echo $val['menu_description'];?></td>
                                                <td><img src="<?php echo base_url();?>admin/assets/uploads/<?php echo $val['menu_image'];?>" style="width:50px;height: 50px;" alt=""/></td>
                                                <td><?php echo $val['quantity'];?></td>
                                                <td><?php echo $val['menu_price'];?></td>
                                                <td><?php echo $val['menu_price']*$val['quantity'];?></td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        

                                        
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div><!-- /# card -->
                        </div><!-- /# column -->
                    </div><!-- /# row -->
                </div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->