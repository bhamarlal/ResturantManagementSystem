
	
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Dashboard 1</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <?php
                                    if($this->session->flashdata('msg')){
                                        if($this->session->flashdata('msg')=='Restaurant Delete Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                                    <?php
                                    if($this->session->flashdata('emsg')){
                                        if($this->session->flashdata('emsg')=='Restaurant Updated Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('emsg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('emsg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="order-list-item">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>City</th>
                                            <th>Image</th>
                                            <th>Timing</th>
                                            <th>Action</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach($restaurant as $key=>$val){
                                                ?>
                                                <tr>
                                                <td><?php echo $val['name'];?></td>
                                                <td><?php echo $val['description'];?></td>
                                                <td><?php echo $val['city_name'];?></td>
                                                <td><img src="<?php echo base_url();?>admin/assets/uploads/<?php echo $val['city_image'];?>" style="width:50px;height: 50px;" alt=""/></td>
                                                <td><?php echo $val['time'];?></td>
                                                <td><div class="prdt_add_to_cart">
                                            <button type="button" class="btn btn-primary btn-rounded  m-l-5">
                                                <a href="<?php echo site_url(); ?>/admin/Welcome/editRestaurant/<?php echo $val['id']; ?>">Edit</a>
                                            </button>
                                            <button type="button" class="btn btn-primary btn-rounded  m-l-5"><a href="<?php echo site_url(); ?>/admin/Welcome/deleteRestaurant/<?php echo $val['id']; ?>">Delete</a></button>
                                        </div></td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        

                                        
                                        </tbody>
                                    </table>
                                    
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
                </div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->