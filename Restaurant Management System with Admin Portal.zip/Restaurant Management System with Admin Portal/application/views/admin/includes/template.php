<?php
$this->load->view("admin/includes/header");
$this->load->view($page);
$this->load->view("admin/includes/footer");

