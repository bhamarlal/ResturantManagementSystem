
	
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/jquery.min.js"></script><!-- jquery vendor -->
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/jquery.nanoscroller.min.js"></script><!-- nano scroller -->    
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/sidebar.js"></script><!-- sidebar -->
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/bootstrap.min.js"></script><!-- bootstrap -->
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/mmc-common.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/mmc-chat.js"></script>
	<!--  Chart js -->
	<script src="<?php echo base_url();?>admin/assets/assets/js/lib/chart-js/Chart.bundle.js"></script>
	<script src="<?php echo base_url();?>admin/assets/assets/js/lib/chart-js/chartjs-init.js"></script>
	<!-- // Chart js -->
	
	<!--  Datamap -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/datamap/d3.min.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/datamap/topojson.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/datamap/datamaps.world.min.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/datamap/datamap-init.js"></script>
	<!-- // Datamap -->-->
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/weather/jquery.simpleWeather.min.js"></script>	
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/weather/weather-init.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/scripts.js"></script>
    <script src="<?php echo base_url();?>admin/assets/assets/js/custom.js"></script><!-- scripit init-->
</body>


<!-- Mirrored from zebratheme.com/html/fooadmin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Mar 2019 12:30:52 GMT -->
</html>