
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1></h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Add Restaurant</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="card-header">
                                    <h4>Add Restaurant</h4>
                                    <?php
                                    if($this->session->flashdata('msg')){
                                        if($this->session->flashdata('msg')=='Restaurant Updated Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                                    
									<div class="card-header-right-icon">
                                        <ul>
                                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                            <li class="doc-link"><a href="#"><i class="ti-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="card-body">
									<div class="menu-upload-form">
										<form class="form-horizontal" method="post" action="<?php echo site_url('admin/Welcome/editRestaurantDb');?>" enctype="multipart/form-data">
                                            <?php 
                                                foreach($restaurant as $key=>$val){
                                                    ?>
                                                    <div class="form-group">
                                            <label class="col-sm-2 control-label">Restaurant Name</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="restaurantName" class="form-control" value="<?php echo $val['name'];?>">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Restaurant Description</label>
                                            <div class="col-sm-10">
                                                <textarea class="form-control" rows="3" name="restaurantDescription"><?php echo $val['description'];?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Restaurant Time</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="restaurantTime" class="form-control" value="<?php echo $val['time'];?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">City Image</label>
                                            <div class="col-sm-10">
                                                <div class="form-control file-input dark-browse-input-box">
                                                    <input class="file-name input-flat"  type="file" name="cityImage" readonly="readonly" placeholder="Browse Files">
                                                </div>
                                                <span><?php echo $val['city_image'];?></span>
                                            </div>
                                        </div>
                                        <input type="hidden" name="rid" value="<?php echo $val['id'];?>">

                                                    <?php
                                                }
                                            ?>
                                        

                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit"class="btn btn-lg btn-primary">Upload</button>
                                            </div>
                                        </div>

                                    </form>
									</div>
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
				</div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->
