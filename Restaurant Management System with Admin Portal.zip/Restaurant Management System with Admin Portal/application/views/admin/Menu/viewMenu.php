
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Products-1</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li><a href="#">Components </a></li>
                                    <li class="active">Products-1</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <?php
                                    if($this->session->flashdata('msg')){
                                        if($this->session->flashdata('msg')=='Menu Delete Successfully'){
                                        ?>

                                        <div class="alert alert-success">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="alert alert-danger">
                                        
                                        <?php
                                            echo $this->session->flashdata('msg');
                                        ?>
                                        </div>
                                        <?php
                                    }
                                    }
                                    
                                    ?>
                    <div class="row">
                        <?php
                            foreach($menu as $key=>$val){
                                ?>
                                <div class="col-lg-3">
                            <div class="card alert">
                                <div class="products_1 text-center">
                                    <div class="pr_img_price">
                                        <div class="product_img">
                                            <img src="<?php echo base_url();?>admin/assets/uploads/<?php echo $val['menu_image'];?>" style="width: 100px;height: 100px;" alt=""/>
                                        </div>
                                        <div class="product_price">
                                            <div class="prd_prc_box">
                                                <div class="product_price">
                                                    <p><?php echo $val['menu_price'];?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="product_details">
                                        <div class="product_name">
                                            <h4><?php echo $val['menu_name'];?></h4>
                                        </div>
                                        <div class="product_des">
                                            <p><?php echo $val['menu_description'];?></p>
                                        </div>
                                        <div class="prdt_add_to_cart">
                                            <button type="button" class="btn btn-primary btn-rounded  m-l-5">
                                                <a href="<?php echo site_url(); ?>/admin/MenuController/editMenu/<?php echo $val['id']; ?>">Edit</a>
                                            </button>
                                            <button type="button" class="btn btn-primary btn-rounded  m-l-5"><a href="<?php echo site_url(); ?>/admin/MenuController/deleteMenu/<?php echo $val['id']; ?>">Delete</a></button>
                                        </div>
                                    </div>

                                </div>
                            </div><!-- /# card -->
                        </div><!-- /# column -->
                                <?php

                            }
                        ?>
                        
                        
                        
                                <div class="pagination-container clearfix">
                                    <div class="pull-right">
                                    <?= $this->pagination->create_links(); ?>
                                    </div>
                                </div>
                        
					</div><!-- /# row -->
                </div><!-- /# main content -->

            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->
