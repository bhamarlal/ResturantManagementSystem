
	
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Dashboard 1</h1>
                            </div>
                        </div>
                    </div><!-- /# column -->
                    <div class="col-lg-4 p-0">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Blank</li>
                                </ol>
                            </div>
                        </div>
                    </div><!-- /# column -->
                </div><!-- /# row -->
                <div class="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="order-list-item">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Customer</th>
                                            <th>Order ID</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>View Detail</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach($orders as $key=>$val){
                                                ?>
                                                <tr>
                                                <td><?php echo $val['fname'];?></td>
                                                <td>#<?php echo $val['orderid'];?></td>
                                                <td><?php echo $val['totalamount'];?></td>
                                                <td><button type="button" class="btn btn-success btn-rounded"><?php echo $val['payment_status'];?></button></td>
                                                <td><a href="<?php echo site_url('admin/Welcome/getorderdetail').'/'.$val['orderid'];?>"><div class="btn btn-success btn-rounded">View</div></a></td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        

                                        
                                        </tbody>
                                    </table>
                                    <div class="pagination-container clearfix">
                                    <div class="pull-right">
                                    <?= $this->pagination->create_links(); ?>
                                    </div>
                                </div>
                                </div>
							</div><!-- /# card -->
						</div><!-- /# column -->
					</div><!-- /# row -->
                </div><!-- /# main content -->
            </div><!-- /# container-fluid -->
        </div><!-- /# main -->
    </div><!-- /# content wrap -->