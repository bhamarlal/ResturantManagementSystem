

<div class="swipe"></div>

<div class="site">

    <div class="header">
                <div class="header__menu">
                            <div class="h1_logo"><a href="<?php echo site_url('Welcome/index') ?>"><span>ChowNow</span></a></div>
                        <a href="tel:18887072469" class="phone">888-707-2469</a><ul class="center_menu">
                                                    <li class="option how"><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                                            <li class="option testimonials"><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                                            <li class="option pricing"><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                    </ul><p><a href="#"><svg width="12" height="15" viewBox="0 0 12 15" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 12h-9c-.828 0-1.5.672-1.5 1.5S.672 15 1.5 15h9c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5m0-6h-9C.672 6 0 6.672 0 7.5 0 8.33.672 9 1.5 9h9c.828 0 1.5-.67 1.5-1.5 0-.828-.672-1.5-1.5-1.5m-9-3h9c.828 0 1.5-.672 1.5-1.5S11.328 0 10.5 0h-9C.672 0 0 .672 0 1.5S.672 3 1.5 3" fill="#FFF" fill-rule="evenodd"/></svg></a></p><ul>                        <li class="demo"><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>

            <div class="header__menu__fill"></div>
        </div>
    </div>

    <div class="main">

<div class="banner plus center image"
     style="background-image: url('<?php echo base_url();?>assets/wp-content/uploads/about.jpg')">
    <div class="container">
        <div class="banner__headline">
            <div class="common-table">
                <div class="common-cell">
                                            <h1 class="headline_header">
                            About Us                        </h1>
                    

                                            <h3><span>At ChowNow, our mission is to help local restaurants thrive.</span></h3>
                        
                </div>
            </div>
        </div>
    </div>
</div>

<div class="about">
  <div class="about__intro">
    <div class="container">
      <div class="about__intro__content">
      <p>We believe restaurants are at their best when they focus their efforts on the quality of their food and service. Whether it be in the kitchen preparing for dinner or at the front door greeting customers, these activities are what make a restaurant. Said another way, restaurants excel when they’re working offline.</p>
<p>At the same time, we live in a world that more than ever demands convenience, usually brought about by technology. Customers are asking for faster, easier ways to order their meals. Like most people they are busy checking emails, jumping in and out of apps, messaging friends and browsing websites. Said another way, customers live and work online.</p>
<p>ChowNow was created to bridge this disconnect. Our products help restaurants get online quickly and easily so they can maintain direct relationships with their customers. As the world evolves and new technology platforms emerge, we will be there to help our restaurant clients stay up to speed online. We cannot control the taste of their food or the friendliness of their staff, but we can arm them with the tools needed to compete in the tech-driven world we all live in.</p>
<h6>Chris Webb, CEO</h6>
      </div>
    </div>
  </div>
    <div class="anchors">
    <div class="anchors__scroll">
      <ul>
              <li class="in-the-news"><a href="#" data-anchor="in-the-news">In The News</a></li>
              <li class="announcements"><a href="#" data-anchor="announcements">Announcements</a></li>
              <li class="partners"><a href="#" data-anchor="partners">Partners</a></li>
            </ul>
    </div>
  </div>
  <div class="anchors__sections">
      <div class="about__section anchor" id="in-the-news">
      <div class="container">
        <div class="about__section__title">
          <h3>In The News</h3>
        </div>
                <div class="about__section__entries">
                  <dl class="x0">
                        <dd class="title"><a href="../blog/order-food-on-instagram-with-chownow.html">Introducing Instagram Ordering with ChowNow</a></dd>
                              <dd class="link"><a href="../blog/order-food-on-instagram-with-chownow.html">Read More</a></dd>
                          </dl>
                      <dl class="x1">
                        <dd class="logo"><img src="<?php echo base_url();?>assets/wp-content/uploads/TechCrunch-Logo.png" alt="" /></dd>
                            <dd class="title"><a href="https://techcrunch.com/2017/10/24/chownow-20-million-series-b-round/" target="_blank">ChowNow, a GrubHub competitor, raises $20 million Series B round</a></dd>
                              <dd class="link"><a href="https://techcrunch.com/2017/10/24/chownow-20-million-series-b-round/" target="_blank">Read More</a></dd>
                          </dl>
                      <dl class="x2">
                        <dd class="logo"><img src="<?php echo base_url();?>assets/wp-content/uploads/The-Verge-Logo.png" alt="" /></dd>
                            <dd class="title"><a href="https://www.theverge.com/2017/10/13/16468610/facebook-food-ordering-new-feature" target="_blank">Facebook now lets you order food without leaving Facebook</a></dd>
                              <dd class="link"><a href="https://www.theverge.com/2017/10/13/16468610/facebook-food-ordering-new-feature" target="_blank">Read More</a></dd>
                          </dl>
                      <dl class="x3">
                        <dd class="logo"><img src="<?php echo base_url();?>assets/wp-content/uploads/Entrepreneur-Logo-1.png" alt="" /></dd>
                            <dd class="title"><a href="https://www.entrepreneur.com/article/287827" target="_blank">8 Steps to Get Your Restaurant Game Cooking Online</a></dd>
                              <dd class="link"><a href="https://www.entrepreneur.com/article/287827" target="_blank">Read More</a></dd>
                          </dl>
                      </div>
                  </div>
      </div>
          <div class="about__section anchor" id="announcements">
      <div class="container">
        <div class="about__section__title">
          <h3>Announcements</h3>
        </div>
                <div class="about__section__entries">
                  <dl class="x0">
                      <dt>October 24th, 2017</dt>
                          <dd class="title"><a href="http://www.marketwired.com/press-release/chownow-raises-20-million-series-b-help-restaurants-regain-their-customers-from-online-2238233.htm" target="_blank">ChowNow Raises $20 Million Series B to Help Restaurants Regain Their Customers From Online Ordering Middlemen</a></dd>
                              <dd class="link"><a href="http://www.marketwired.com/press-release/chownow-raises-20-million-series-b-help-restaurants-regain-their-customers-from-online-2238233.htm" target="_blank">Read More</a></dd>
                          </dl>
                      <dl class="x1">
                      <dt>May 4th, 2017</dt>
                          <dd class="title"><a href="../blog/introducing-chownow-discover.html">Meet ChowNow Discover: New Customers Await</a></dd>
                              <dd class="link"><a href="../blog/introducing-chownow-discover.html">Read More</a></dd>
                          </dl>
                      <dl class="x2">
                      <dt>October 18th, 2016</dt>
                          <dd class="title"><a href="../blog/announcing-squarespace-partnership.html">ChowNow x Squarespace: Partnering to Turn Your Restaurant&#8217;s Website into a Digital Revenue Stream</a></dd>
                              <dd class="link"><a href="../blog/announcing-squarespace-partnership.html">Read More</a></dd>
                          </dl>
                      <dl class="x3">
                      <dt>October 14th, 2015</dt>
                          <dd class="title"><a href="../media/CN_PressRelease_151004.pdf" target="_blank">Uber and ChowNow Partner to Give Thousands of Restaurants Access to On-Demand Delivery</a></dd>
                            <dd class="excerpt">Uber and ChowNow are proud to announce a new partnership that brings a faster-than-ever delivery option to thousands of restaurants that use ChowNow for their online and mobile ordering.</dd>
                              <dd class="link"><a href="../media/CN_PressRelease_151004.pdf" target="_blank">Read More</a></dd>
                          </dl>
                      </div>
                  </div>
      </div>
          <div class="about__section anchor" id="partners">
      <div class="container">
        <div class="about__section__title">
          <h3>Partners</h3>
        </div>
                <div class="about__section__partners">

          <ul class="common-logos">
            <li><img class="cn-google-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/google-logo.svg" alt="Google Logo" /></li>
            <li><img class="cn-godaddy-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/godaddy-logo.svg" alt="GoDaddy Logo" /></li>
            <li><img class="cn-yelp-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/yelp-logo.svg" alt="Yelp Logo" /></li>
            <li><img class="cn-squarespace-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/squarespace-logo.svg" alt="Squarespace Logo" /></li>
            <li><img class="cn-usf-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/usf-logo.svg" alt="USF Logo" /></li>
            <li><img class="cn-facebook-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/facebook-logo.svg" alt="Facebook Logo" /></li>
            <li><img class="cn-apple-logo" src="<?php echo base_url();?>assets/wp-content/themes/chownow4/assets/page-about/apple-logo.svg" alt="Apple Logo" /></li>
          </ul>

        </div>
                </div>
      </div>
          </div>
        <div class="about__bumper">
      <div class="container">
        <dl>
          <dt>For Media Inquiries <a href="mailto:press@chownow.com">Press@chownow.com</a></dt>
        </dl>
    </div>
  </div>
</div>

</div>

