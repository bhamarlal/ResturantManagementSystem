

<div class="swipe"></div>

<div class="site">

    <div class="header">
                <div class="header__menu">
                            <div class="h1_logo"><a href="<?php echo site_url('Welcome/index') ?>"><span>ChowNow</span></a></div>
                        <a href="tel:18887072469" class="phone">888-707-2469</a><ul class="center_menu">
                                                    <li class="option how"><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                                            <li class="option testimonials"><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                                            <li class="option pricing"><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                    </ul><p><a href="#"><svg width="12" height="15" viewBox="0 0 12 15" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 12h-9c-.828 0-1.5.672-1.5 1.5S.672 15 1.5 15h9c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5m0-6h-9C.672 6 0 6.672 0 7.5 0 8.33.672 9 1.5 9h9c.828 0 1.5-.67 1.5-1.5 0-.828-.672-1.5-1.5-1.5m-9-3h9c.828 0 1.5-.672 1.5-1.5S11.328 0 10.5 0h-9C.672 0 0 .672 0 1.5S.672 3 1.5 3" fill="#FFF" fill-rule="evenodd"/></svg></a></p><ul>                        <li class="demo"><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>

            <div class="header__menu__fill"></div>
        </div>
    </div>

    <div class="main">

<div class="gcdc-landing-page">

  
  <div class="page-header">
                  <div class="heroshot" style="background-image: linear-gradient(rgba(0,35,61,0.7), rgba(0,35,61,0.7)), url('<?php echo base_url();?>assets/wp-content/uploads/opt-3U9B3308.jpg');">
          
        <div class="container">
          <div class="padded-content page__content common-content">
                          <h1>Why Customer Data Is Critical to Your Restaurant's Success</h1>
                                                  <div class="anchors">
                    <a class="common-button pill slim red wide gcdc-header demo-btn" href="#" data-anchor="form"></a>
              </div>
                      </div><!-- end .padded-content page__content common-content -->
        </div><!-- end .container -->
      </div><!-- end .solid-bg or .hero-shot -->
  </div><!-- end .page-header -->

  
  <div class="page">
    <div class="container container-gray">
    <div class="anchors__sections">
       
      <div class="padded-content page__content common-content ">

        <div class="content-left">
                      <p>With 74% of consumers now ordering food through a website or mobile app, restaurants are seeing some clear benefits: more patrons, larger ticket sizes, and increased order volume.</p>
<p>But there’s a lesser-known advantage that savvy restaurateurs are leveraging: the customer data that online ordering can provide.</p>
<p>Download this ebook to discover:</p>
<ul>
<li>What exactly restaurant customer data is.</li>
<li>How customer data helps you acquire new customers, increase ticket sizes, and strengthen loyalty.</li>
<li>Practical applications of your customer insights, including menu design and email marketing.</li>
<li>How to access this valuable information.</li>
</ul>
                            </div><!-- end .content-left -->
        
        <div class="anchor" id="form">
        <div class="content-right">
                      <div id="form-anchor">
              <div class="gate-0f7abea4-faec-4aa2-a367-34d82240278a"></div>            </div>
                  </div><!-- end .content-right -->
        </div><!-- end .features anchor -->

      </div>
          </div><!-- end .anchors__sections -->
    </div><!-- end .container .container-gray -->
  </div><!-- end .page -->

</div><!-- end .gcdc-landing-page -->
</div>

