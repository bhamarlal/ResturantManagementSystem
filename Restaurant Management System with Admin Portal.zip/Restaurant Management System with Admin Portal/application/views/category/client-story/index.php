

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>September 6th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></dd>
                    <dd><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></dd>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/backToSchool');?>">Back to School: In the Kitchen with 3 Restaurant Chefs</a></h3>
                </div>
                <div class="blog__post__content">
<p>What skill do you want to learn from a restaurant chef? If you could go to your favorite restaurant and ask the chef to teach you how to make one&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/backToSchool');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 6th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/onlineFoodDelevery');?>">How Seamlessly Online Food Delivery Platforms Are Taking Restaurants’ Orders</a></h3>
                </div>
                <div class="blog__post__content">
<p>Article written by Grant Turck, digital marketing strategist and restaurant advisor. Originally published December 2015. Is your restaurant monitoring its SEO strategy when it comes to online food delivery ordering? If&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/onlineFoodDelevery');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>April 27th, 2016</dt>
                    <dd><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/onlineOrderCaseStudy');?>">[Case Study] How Two Boots Doubled Revenue and Scaled Brand Online</a></h3>
                </div>
                <div class="blog__post__content">
<p>Two Boots owner Leon Hartman harnessed the power of the extensive customer data he gathered through ChowNow&#8217;s online ordering platform to present the restaurant&#8217;s impressive growth to outside investors. With ChowNow as an essential&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/onlineOrderCaseStudy');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>December 30th, 2014</dt>
                    <dd><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/chownowClientStory');?>">ChowNow Client Story: XOCO</a></h3>
                </div>
                <div class="blog__post__content">
<p>&nbsp; Arthur Mullen, Manager at Rick Bayless’ Mexican street food restaurant XOCO, uses ChowNow to process high to-go order volumes at his bustling downtown Chicago location. And you could say&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/chownowClientStory');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>
