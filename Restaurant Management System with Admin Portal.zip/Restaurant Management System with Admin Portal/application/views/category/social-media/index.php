

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 3rd, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/instagramGuide');?>">Restaurant Guide: How To Maximize Your Success On Instagram</a></h3>
                </div>
                <div class="blog__post__content">
<p>At well over 500 million active users and rolling out new features on the reg (business analytics, Instagram Stories, live video, and Start Order), Instagram’s audience eclipses that of Twitter,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/instagramGuide');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>May 8th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>">Introducing Instagram Ordering with ChowNow</a></h3>
                </div>
                <div class="blog__post__content">
<p>Instagram has surpassed 500 million daily active users worldwide, who spend more than 32 minutes a day scrolling, liking, and posting visual content. As consumers spend more time on social&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>March 2nd, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/springMarketnigPromotion');?>">5 Fresh Marketing Promotions for Your Restaurant to Try This Spring</a></h3>
                </div>
                <div class="blog__post__content">
<p>Springtime means the promise of something new. New beginnings, new growth, new energy — and if you can be productive during the Spring months, that feeling of success can carry&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/springMarketnigPromotion');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>October 30th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/ultimateSnapChat');?>">The Ultimate Guide: 7 Tips to Kick Your Snapchat Strategy Up a Notch</a></h3>
                </div>
                <div class="blog__post__content">
<p>Overwhelmed with all the latest Snapchat features? Snapchat has changed quite a bit over the past few years, and continues to advance with new tools to connect you with your&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/ultimateSnapChat');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

