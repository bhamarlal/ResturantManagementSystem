

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>May 8th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>">Introducing Instagram Ordering with ChowNow</a></h3>
                </div>
                <div class="blog__post__content">
<p>Instagram has surpassed 500 million daily active users worldwide, who spend more than 32 minutes a day scrolling, liking, and posting visual content. As consumers spend more time on social&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>October 24th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></dd>
                  </dl>
                  <h3 class="link"><a href="#">ChowNow, a GrubHub competitor, raises $20 million Series B round</a></h3>
                </div>
                <div class="blog__post__content">
                </div>
                <div class="blog__post__link"><a href="#" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>October 13th, 2017</dt>
                    <dd><a href="#">In The News</a></dd>
                  </dl>
                  <h3 class="link"><a href="#">Facebook now lets you order food without leaving Facebook</a></h3>
                </div>
                <div class="blog__post__content">
                </div>
                <div class="blog__post__link"><a href="#" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>January 17th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></dd>
                  </dl>
                  <h3 class="link"><a href="#">8 Steps to Get Your Restaurant Game Cooking Online</a></h3>
                </div>
                <div class="blog__post__content">
                </div>
                <div class="blog__post__link"><a href="#" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="#" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

