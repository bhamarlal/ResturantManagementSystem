

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>January 4th, 2019</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/appleDeveloperProgram') ?>">Tutorial: How to Enroll Your Restaurant in ChowNow&#8217;s Apple Developer Program (Canadian Version)</a></h3>
                </div>
                <div class="blog__post__content">
<p>Eager to establish a stronger connection with your customers and increase repeat orders? Get your very own branded mobile app to put your menu in their hands, wherever they are.&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/appleDeveloperProgram') ?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 11th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/howToWinBackCustomerProfit') ?>">5 Ways to Win Back Your Restaurant&#8217;s Customers from Grubhub</a></h3>
                </div>
                <div class="blog__post__content">
<p>Similar to many other third party online ordering portals, Grubhub, Eat24 and UberEATS take hefty commissions from each and every order a restaurant receives through their platforms. Not to mention,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/howToWinBackCustomerProfit') ?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 10th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/runingRestaurantMarketing') ?>">The Do’s and Don’ts of Running Restaurant Promotions</a></h3>
                </div>
                <div class="blog__post__content">
<p>We know that saving money is the #1 concern for restaurant owners &amp; managers everywhere. It’s easy to shy away from the idea of selling your food for a smaller&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/runingRestaurantMarketing') ?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 9th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/appleDeveloperProgram') ?>">Tutorial: How to Enroll in ChowNow&#8217;s Apple Developer Program</a></h3>
                </div>
                <div class="blog__post__content">
<p>Eager to establish a stronger connection with your customers and increase repeat orders? Get your very own branded mobile app to put your menu in their hands, wherever they are.&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/appleDeveloperProgram') ?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

