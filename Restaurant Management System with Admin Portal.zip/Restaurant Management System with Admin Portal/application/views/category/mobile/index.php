

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>August 15th, 2016</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/mobileBlog') ?>">Mobile</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/createGoogleBusiness');?>">How to Cash in on Mobile Searches with ChowNow &#038; Google Search</a></h3>
                </div>
                <div class="blog__post__content">
<p>We learned at Connect Mobile Innovation Summit that mobile searches related to restaurants have a 90% conversion rate. Meaning, when someone is looking for you, they’re ready to be your&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/createGoogleBusiness');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 6th, 2016</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/mobileBlog') ?>">Mobile</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/promoteOnlineOrder');?>">4 Ways to Promote Your Digital Dining</a></h3>
                </div>
                <div class="blog__post__content">
<p>Everyone is online these days – and so is your business. With the online ordering revolution under way, it’s only a matter of time before your customers want to enjoy&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/promoteOnlineOrder');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>August 11th, 2015</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/mobileBlog') ?>">Mobile</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/howToConvertOnlineeSearch');?>">Tips To Convert Customers That Discover You Online</a></h3>
                </div>
                <div class="blog__post__content">
<p>70% of consumers use smartphones or tablets today, according to the National Restaurant Association’s Restaurant Industry 2015: Technology Trends report. With a mobile device within arm’s reach, everyone’s a bona&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/howToConvertOnlineeSearch');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>August 7th, 2015</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/mobileBlog') ?>">Mobile</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/launchYourRestaurant');?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="">Launch Your Restaurant Carryout and Delivery Business</a></h3>
                </div>
                <div class="blog__post__content">
<p> &#8212; Mike Ganino |  Mike is a restaurant veteran having served  as COO at Protein Bar and in key roles at Yum! Brands, Lettuce Entertain You, and Potbelly Sandwich Shop. An in-demand speaker and trainer on restaurant&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/launchYourRestaurant');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

