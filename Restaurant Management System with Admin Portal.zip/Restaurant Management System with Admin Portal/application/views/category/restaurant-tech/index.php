

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>February 19th, 2019</dt>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/marketplacesEating');?>">How Marketplaces Are Eating Away at Your Restaurant&#8217;s Bottom Line</a></h3>
                </div>
                <div class="blog__post__content">
<p>On their surface, third-party marketplace online ordering services like Postmates, Grubhub, and Uber Eats may seem like a smart choice for your restaurant. After all, it pays to have online&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/marketplacesEating');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 10th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/runingRestaurantMarketing');?>">The Do’s and Don’ts of Running Restaurant Promotions</a></h3>
                </div>
                <div class="blog__post__content">
<p>We know that saving money is the #1 concern for restaurant owners &amp; managers everywhere. It’s easy to shy away from the idea of selling your food for a smaller&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/runingRestaurantMarketing');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 12th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/increaseEngagementOnline');?>">Increase Engagement Online with Restaurant Messaging Tools</a></h3>
                </div>
                <div class="blog__post__content">
<p>The way that people communicate with each other has changed dramatically over the last decade, with a recent report showing that the average American spends 26 minutes each day texting&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/increaseEngagementOnline');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 3rd, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/instagramGuide');?>">Restaurant Guide: How To Maximize Your Success On Instagram</a></h3>
                </div>
                <div class="blog__post__content">
<p>At well over 500 million active users and rolling out new features on the reg (business analytics, Instagram Stories, live video, and Start Order), Instagram’s audience eclipses that of Twitter,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/instagramGuide');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

