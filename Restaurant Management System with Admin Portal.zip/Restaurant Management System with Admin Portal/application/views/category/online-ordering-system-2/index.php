

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>February 19th, 2019</dt>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/marketplacesEating');?>">How Marketplaces Are Eating Away at Your Restaurant&#8217;s Bottom Line</a></h3>
                </div>
                <div class="blog__post__content">
<p>On their surface, third-party marketplace online ordering services like Postmates, Grubhub, and Uber Eats may seem like a smart choice for your restaurant. After all, it pays to have online&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/marketplacesEating');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 11th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/howToWinBackCustomerProfit');?>">5 Ways to Win Back Your Restaurant&#8217;s Customers from Grubhub</a></h3>
                </div>
                <div class="blog__post__content">
<p>Similar to many other third party online ordering portals, Grubhub, Eat24 and UberEATS take hefty commissions from each and every order a restaurant receives through their platforms. Not to mention,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/howToWinBackCustomerProfit');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>May 8th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>">Introducing Instagram Ordering with ChowNow</a></h3>
                </div>
                <div class="blog__post__content">
<p>Instagram has surpassed 500 million daily active users worldwide, who spend more than 32 minutes a day scrolling, liking, and posting visual content. As consumers spend more time on social&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/introducingInstagramOrder');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>May 4th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/restaurantKillingDelivery');?>">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a></h3>
                </div>
                <div class="blog__post__content">
<p>Running a restaurant is tough. It requires long hours and margins are thin, but you do it because you love it. You do it because you have a special experience&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/restaurantKillingDelivery');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

