

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>July 10th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/runingRestaurantMarketing');?>">The Do’s and Don’ts of Running Restaurant Promotions</a></h3>
                </div>
                <div class="blog__post__content">
<p>We know that saving money is the #1 concern for restaurant owners &amp; managers everywhere. It’s easy to shy away from the idea of selling your food for a smaller&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/runingRestaurantMarketing');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 6th, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/howToCreateSecreteMenu');?>">How to Create a Secret Menu in 5 Easy Steps</a></h3>
                </div>
                <div class="blog__post__content">
<p>There’s something about the thrill of “secret menus” at restaurants that people just can’t seem to resist. From In-N-Out’s animal-style everything, to Starbucks’ Fruity Pebbles Frappuccino — secret menus create&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/howToCreateSecreteMenu');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 3rd, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></dd>
                    <dd><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/instagramGuide');?>">Restaurant Guide: How To Maximize Your Success On Instagram</a></h3>
                </div>
                <div class="blog__post__content">
<p>At well over 500 million active users and rolling out new features on the reg (business analytics, Instagram Stories, live video, and Start Order), Instagram’s audience eclipses that of Twitter,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/instagramGuide');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>May 2nd, 2018</dt>
                    <dd><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></dd>
                    <dd><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/restaurantNeedsAdvantage');?>">Why Your Restaurant Needs to Take Advantage of Customer Data</a></h3>
                </div>
                <div class="blog__post__content">
<p>It&#8217;s undeniable that online ordering is revolutionizing the restaurant industry, with 60% of consumers ordering delivery or takeout at least once a week. And while the sheer convenience of online&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/restaurantNeedsAdvantage');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

