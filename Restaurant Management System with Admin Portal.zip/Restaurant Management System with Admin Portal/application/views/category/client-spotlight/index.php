

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>October 31st, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/restaurantCafe');?>">Behind The Counter: How Cafe Gratitude Gives Thanks Year Round</a></h3>
                </div>
                <div class="blog__post__content">
<p>For most, Thanksgiving is a time best spent with family and friends around the dinner table, enjoying heaping mounds of turkey and stuffing and of course &#8212; giving thanks. It’s&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/restaurantCafe');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>October 6th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/celebratingDayofDead');?>">Celebrating Day of the Dead at L.A. Restaurant Toca Madera</a></h3>
                </div>
                <div class="blog__post__content">
<p>Day of the Dead, or Dia de los Muertos, is a three-day long celebration of life and death where families commemorate their deceased loved ones. The tradition originates in Mexico,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/celebratingDayofDead');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>September 6th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></dd>
                    <dd><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></dd>
                    <dd><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/backToSchool');?>">Back to School: In the Kitchen with 3 Restaurant Chefs</a></h3>
                </div>
                <div class="blog__post__content">
<p>What skill do you want to learn from a restaurant chef? If you could go to your favorite restaurant and ask the chef to teach you how to make one&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/backToSchool');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>August 7th, 2017</dt>
                    <dd><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></dd>
                  </dl>
                  <h3><a href="<?php echo site_url('UserController/sevenBestSeasonalFood');?>">Seven In-Season Foods and Where to Eat Them in Los Angeles</a></h3>
                </div>
                <div class="blog__post__content">
<p>Some argue that Los Angeles lacks seasons. Some say that’s not true… we just skip the crummy ones. However, there’s a special place in L.A. that’s always seasonal — with&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="<?php echo site_url('UserController/sevenBestSeasonalFood');?>" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

