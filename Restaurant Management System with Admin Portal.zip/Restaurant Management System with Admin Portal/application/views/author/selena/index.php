

    <div class="main">

        <div class="banner blog center">
          <div class="container">
            <div class="banner__headline">
              <div class="common-table">
                <div class="common-cell">
                  <h1 class="headline_header">The ChowNow Blog</h1>
                  <h3>Your source for the latest in restaurant marketing, tech, and takeout.</h3>
                  <div class="banner__headline__categories">
                    <p><span class="selected"><a href="../../blog.html">Everything</a></span><span><a href="../../category/client-spotlight/index.html">Client Spotlight</a></span><span><a href="../../category/client-story/index.html">Client Story</a></span><span><a href="../../category/how-to/index.html">How to</a></span><span><a href="../../category/in-the-news/index.html">In The News</a></span><span><a href="../../category/marketing/index.html">Marketing</a></span><span><a href="../../category/mobile/index.html">Mobile</a></span><span><a href="../../category/online-ordering-system-2/index.html">Online Ordering System</a></span><span><a href="../../category/restaurant-tech/index.html">Restaurant Tech</a></span><span><a href="../../category/social-media/index.html">Social Media</a></span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="blog infinite">
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 6th, 2018</dt>
                    <dd><a href="../../category/how-to/index.html">How to</a></dd>
                    <dd><a href="../../category/marketing/index.html">Marketing</a></dd>
                  </dl>
                  <h3><a href="../../blog/how-to-create-a-secret-menu.html">How to Create a Secret Menu in 5 Easy Steps</a></h3>
                </div>
                <div class="blog__post__content">
<p>There’s something about the thrill of “secret menus” at restaurants that people just can’t seem to resist. From In-N-Out’s animal-style everything, to Starbucks’ Fruity Pebbles Frappuccino — secret menus create&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="../../blog/how-to-create-a-secret-menu.html" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>June 3rd, 2018</dt>
                    <dd><a href="../../category/marketing/index.html">Marketing</a></dd>
                    <dd><a href="../../category/restaurant-tech/index.html">Restaurant Tech</a></dd>
                    <dd><a href="../../category/social-media/index.html">Social Media</a></dd>
                  </dl>
                  <h3><a href="../../blog/instagram-guide-for-restaurants.html">Restaurant Guide: How To Maximize Your Success On Instagram</a></h3>
                </div>
                <div class="blog__post__content">
<p>At well over 500 million active users and rolling out new features on the reg (business analytics, Instagram Stories, live video, and Start Order), Instagram’s audience eclipses that of Twitter,&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="../../blog/instagram-guide-for-restaurants.html" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post even">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>April 1st, 2018</dt>
                    <dd><a href="../../category/how-to/index.html">How to</a></dd>
                    <dd><a href="../../category/marketing/index.html">Marketing</a></dd>
                    <dd><a href="../../category/restaurant-tech/index.html">Restaurant Tech</a></dd>
                  </dl>
                  <h3><a href="../../blog/restaurant-email-marketing-tips.html">Restaurant Guide: Email Marketing Made Easy</a></h3>
                </div>
                <div class="blog__post__content">
<p>Digital communication is constantly evolving, and it&#8217;s more important than ever to stay on top of your competition. While staying on trend with new marketing channels is important, one classic&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="../../blog/restaurant-email-marketing-tips.html" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__post odd">
            <div class="container">
              <div class="blog__post__wrap">
                <div class="blog__post__title">
                  <dl>
                    <dt>March 2nd, 2018</dt>
                    <dd><a href="../../category/marketing/index.html">Marketing</a></dd>
                    <dd><a href="../../category/social-media/index.html">Social Media</a></dd>
                  </dl>
                  <h3><a href="../../blog/spring-marketing-promotions-for-your-restaurant.html">5 Fresh Marketing Promotions for Your Restaurant to Try This Spring</a></h3>
                </div>
                <div class="blog__post__content">
<p>Springtime means the promise of something new. New beginnings, new growth, new energy — and if you can be productive during the Spring months, that feeling of success can carry&hellip;</p>
                </div>
                <div class="blog__post__link"><a href="../../blog/spring-marketing-promotions-for-your-restaurant.html" class="common-button pill red slim">Read More</a></div>
              </div>
            </div>
          </div>
          <div class="blog__pagination infinite">
            <ul>
              <li><a href="page/2/index.html" >Next</a></li>
            <ul>
          </div>
        </div>
</div>

