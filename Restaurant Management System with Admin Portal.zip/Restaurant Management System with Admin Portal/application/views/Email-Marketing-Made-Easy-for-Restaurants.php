

<div class="swipe"></div>

<div class="site">

    <div class="header">
                <div class="header__menu">
                            <div class="h1_logo"><a href="<?php echo site_url('Welcome/index') ?>"><span>ChowNow</span></a></div>
                        <a href="tel:18887072469" class="phone">888-707-2469</a><ul class="center_menu">
                                                    <li class="option how"><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                                            <li class="option testimonials"><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                                            <li class="option pricing"><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                    </ul><p><a href="#"><svg width="12" height="15" viewBox="0 0 12 15" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 12h-9c-.828 0-1.5.672-1.5 1.5S.672 15 1.5 15h9c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5m0-6h-9C.672 6 0 6.672 0 7.5 0 8.33.672 9 1.5 9h9c.828 0 1.5-.67 1.5-1.5 0-.828-.672-1.5-1.5-1.5m-9-3h9c.828 0 1.5-.672 1.5-1.5S11.328 0 10.5 0h-9C.672 0 0 .672 0 1.5S.672 3 1.5 3" fill="#FFF" fill-rule="evenodd"/></svg></a></p><ul>                        <li class="demo"><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>

            <div class="header__menu__fill"></div>
        </div>
    </div>

    <div class="main">

<div class="gcdc-landing-page">

  
  <div class="page-header">
                  <div class="heroshot" style="background-image: linear-gradient(rgba(0,35,61,0.7), rgba(0,35,61,0.7)), url('<?php echo base_url();?>assets/wp-content/uploads/gfs.jpg');">
          
        <div class="container">
          <div class="padded-content page__content common-content">
                          <h1>Email Marketing Made Easy for Restaurants</h1>
                                                  <div class="anchors">
                    <a class="common-button pill slim red wide gcdc-header demo-btn" href="#" data-anchor="form"></a>
              </div>
                      </div><!-- end .padded-content page__content common-content -->
        </div><!-- end .container -->
      </div><!-- end .solid-bg or .hero-shot -->
  </div><!-- end .page-header -->

  
  <div class="page">
    <div class="container container-gray">
    <div class="anchors__sections">
       
      <div class="padded-content page__content common-content ">

        <div class="content-left">
                      <p>Email marketing presents a huge opportunity for restaurants to increase sales. With an average ROI of $44 for every $1 spent, can your restaurant really afford to miss out?</p>
<p>If you&#8217;re armed with a database of your customers&#8217; email addresses, you&#8217;ll be able to improve awareness, deliver promotions, and keep customers ordering again and again.</p>
<p>Download our guide now to:</p>
<ul>
<li>Grow your email list and connect with more customers.</li>
<li>Choose the right technology to simplify your life.</li>
<li>Create compelling content that drives sales.</li>
</ul>
                            </div><!-- end .content-left -->
        
        <div class="anchor" id="form">
        <div class="content-right">
                      <div id="form-anchor">
              <div class="gate-a99a6f00-0047-4950-b16d-dfc5f26a1030"></div>            </div>
                  </div><!-- end .content-right -->
        </div><!-- end .features anchor -->

      </div>
          </div><!-- end .anchors__sections -->
    </div><!-- end .container .container-gray -->
  </div><!-- end .page -->

</div><!-- end .gcdc-landing-page -->
</div>

