<!DOCTYPE html>
<html>

<!-- Mirrored from admin.chownow.com/admin/login by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Mar 2019 07:53:33 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>
            ChowNow
    </title>

    <script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={xpid:"UAEDWFVWGwEDXVFSBQM="};window.NREUM||(NREUM={}),__nr_require=function(t,e,n){function r(n){if(!e[n]){var o=e[n]={exports:{}};t[n][0].call(o.exports,function(e){var o=t[n][1][e];return r(o||e)},o,o.exports)}return e[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(t,e,n){function r(t){try{c.console&&console.log(t)}catch(e){}}var o,i=t("ee"),a=t(13),c={};try{o=localStorage.getItem("__nr_flags").split(","),console&&"function"==typeof console.log&&(c.console=!0,o.indexOf("dev")!==-1&&(c.dev=!0),o.indexOf("nr_dev")!==-1&&(c.nrDev=!0))}catch(s){}c.nrDev&&i.on("internal-error",function(t){r(t.stack)}),c.dev&&i.on("fn-err",function(t,e,n){r(n.stack)}),c.dev&&(r("NR AGENT IN DEVELOPMENT MODE"),r("flags: "+a(c,function(t,e){return t}).join(", ")))},{}],2:[function(t,e,n){function r(t,e,n,r,c){try{p?p-=1:o(c||new UncaughtException(t,e,n),!0)}catch(f){try{i("ierr",[f,s.now(),!0])}catch(d){}}return"function"==typeof u&&u.apply(this,a(arguments))}function UncaughtException(t,e,n){this.message=t||"Uncaught error with no additional information",this.sourceURL=e,this.line=n}function o(t,e){var n=e?null:s.now();i("err",[t,n])}var i=t("handle"),a=t(14),c=t("ee"),s=t("loader"),f=t("gos"),u=window.onerror,d=!1,l="nr@seenError",p=0;s.features.err=!0,t(1),window.onerror=r;try{throw new Error}catch(h){"stack"in h&&(t(5),t(4),"addEventListener"in window&&t(3),s.xhrWrappable&&t(6),d=!0)}c.on("fn-start",function(t,e,n){d&&(p+=1)}),c.on("fn-err",function(t,e,n){d&&!n[l]&&(f(n,l,function(){return!0}),this.thrown=!0,o(n))}),c.on("fn-end",function(){d&&!this.thrown&&p>0&&(p-=1)}),c.on("internal-error",function(t){i("ierr",[t,s.now(),!0])})},{}],3:[function(t,e,n){function r(t){for(var e=t;e&&!e.hasOwnProperty(u);)e=Object.getPrototypeOf(e);e&&o(e)}function o(t){c.inPlace(t,[u,d],"-",i)}function i(t,e){return t[1]}var a=t("ee").get("events"),c=t(16)(a,!0),s=t("gos"),f=XMLHttpRequest,u="addEventListener",d="removeEventListener";e.exports=a,"getPrototypeOf"in Object?(r(document),r(window),r(f.prototype)):f.prototype.hasOwnProperty(u)&&(o(window),o(f.prototype)),a.on(u+"-start",function(t,e){var n=t[1],r=s(n,"nr@wrapped",function(){function t(){if("function"==typeof n.handleEvent)return n.handleEvent.apply(n,arguments)}var e={object:t,"function":n}[typeof n];return e?c(e,"fn-",null,e.name||"anonymous"):n});this.wrapped=t[1]=r}),a.on(d+"-start",function(t){t[1]=this.wrapped||t[1]})},{}],4:[function(t,e,n){var r=t("ee").get("raf"),o=t(16)(r),i="equestAnimationFrame";e.exports=r,o.inPlace(window,["r"+i,"mozR"+i,"webkitR"+i,"msR"+i],"raf-"),r.on("raf-start",function(t){t[0]=o(t[0],"fn-")})},{}],5:[function(t,e,n){function r(t,e,n){t[0]=a(t[0],"fn-",null,n)}function o(t,e,n){this.method=n,this.timerDuration=isNaN(t[1])?0:+t[1],t[0]=a(t[0],"fn-",this,n)}var i=t("ee").get("timer"),a=t(16)(i),c="setTimeout",s="setInterval",f="clearTimeout",u="-start",d="-";e.exports=i,a.inPlace(window,[c,"setImmediate"],c+d),a.inPlace(window,[s],s+d),a.inPlace(window,[f,"clearImmediate"],f+d),i.on(s+u,r),i.on(c+u,o)},{}],6:[function(t,e,n){function r(t,e){d.inPlace(e,["onreadystatechange"],"fn-",c)}function o(){var t=this,e=u.context(t);t.readyState>3&&!e.resolved&&(e.resolved=!0,u.emit("xhr-resolved",[],t)),d.inPlace(t,w,"fn-",c)}function i(t){g.push(t),h&&(b?b.then(a):v?v(a):(E=-E,O.data=E))}function a(){for(var t=0;t<g.length;t++)r([],g[t]);g.length&&(g=[])}function c(t,e){return e}function s(t,e){for(var n in t)e[n]=t[n];return e}t(3);var f=t("ee"),u=f.get("xhr"),d=t(16)(u),l=NREUM.o,p=l.XHR,h=l.MO,m=l.PR,v=l.SI,y="readystatechange",w=["onload","onerror","onabort","onloadstart","onloadend","onprogress","ontimeout"],g=[];e.exports=u;var x=window.XMLHttpRequest=function(t){var e=new p(t);try{u.emit("new-xhr",[e],e),e.addEventListener(y,o,!1)}catch(n){try{u.emit("internal-error",[n])}catch(r){}}return e};if(s(p,x),x.prototype=p.prototype,d.inPlace(x.prototype,["open","send"],"-xhr-",c),u.on("send-xhr-start",function(t,e){r(t,e),i(e)}),u.on("open-xhr-start",r),h){var b=m&&m.resolve();if(!v&&!m){var E=1,O=document.createTextNode(E);new h(a).observe(O,{characterData:!0})}}else f.on("fn-end",function(t){t[0]&&t[0].type===y||a()})},{}],7:[function(t,e,n){function r(t){var e=this.params,n=this.metrics;if(!this.ended){this.ended=!0;for(var r=0;r<d;r++)t.removeEventListener(u[r],this.listener,!1);if(!e.aborted){if(n.duration=a.now()-this.startTime,4===t.readyState){e.status=t.status;var i=o(t,this.lastSize);if(i&&(n.rxSize=i),this.sameOrigin){var s=t.getResponseHeader("X-NewRelic-App-Data");s&&(e.cat=s.split(", ").pop())}}else e.status=0;n.cbTime=this.cbTime,f.emit("xhr-done",[t],t),c("xhr",[e,n,this.startTime])}}}function o(t,e){var n=t.responseType;if("json"===n&&null!==e)return e;var r="arraybuffer"===n||"blob"===n||"json"===n?t.response:t.responseText;return h(r)}function i(t,e){var n=s(e),r=t.params;r.host=n.hostname+":"+n.port,r.pathname=n.pathname,t.sameOrigin=n.sameOrigin}var a=t("loader");if(a.xhrWrappable){var c=t("handle"),s=t(8),f=t("ee"),u=["load","error","abort","timeout"],d=u.length,l=t("id"),p=t(11),h=t(10),m=window.XMLHttpRequest;a.features.xhr=!0,t(6),f.on("new-xhr",function(t){var e=this;e.totalCbs=0,e.called=0,e.cbTime=0,e.end=r,e.ended=!1,e.xhrGuids={},e.lastSize=null,p&&(p>34||p<10)||window.opera||t.addEventListener("progress",function(t){e.lastSize=t.loaded},!1)}),f.on("open-xhr-start",function(t){this.params={method:t[0]},i(this,t[1]),this.metrics={}}),f.on("open-xhr-end",function(t,e){"loader_config"in NREUM&&"xpid"in NREUM.loader_config&&this.sameOrigin&&e.setRequestHeader("X-NewRelic-ID",NREUM.loader_config.xpid)}),f.on("send-xhr-start",function(t,e){var n=this.metrics,r=t[0],o=this;if(n&&r){var i=h(r);i&&(n.txSize=i)}this.startTime=a.now(),this.listener=function(t){try{"abort"===t.type&&(o.params.aborted=!0),("load"!==t.type||o.called===o.totalCbs&&(o.onloadCalled||"function"!=typeof e.onload))&&o.end(e)}catch(n){try{f.emit("internal-error",[n])}catch(r){}}};for(var c=0;c<d;c++)e.addEventListener(u[c],this.listener,!1)}),f.on("xhr-cb-time",function(t,e,n){this.cbTime+=t,e?this.onloadCalled=!0:this.called+=1,this.called!==this.totalCbs||!this.onloadCalled&&"function"==typeof n.onload||this.end(n)}),f.on("xhr-load-added",function(t,e){var n=""+l(t)+!!e;this.xhrGuids&&!this.xhrGuids[n]&&(this.xhrGuids[n]=!0,this.totalCbs+=1)}),f.on("xhr-load-removed",function(t,e){var n=""+l(t)+!!e;this.xhrGuids&&this.xhrGuids[n]&&(delete this.xhrGuids[n],this.totalCbs-=1)}),f.on("addEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&f.emit("xhr-load-added",[t[1],t[2]],e)}),f.on("removeEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&f.emit("xhr-load-removed",[t[1],t[2]],e)}),f.on("fn-start",function(t,e,n){e instanceof m&&("onload"===n&&(this.onload=!0),("load"===(t[0]&&t[0].type)||this.onload)&&(this.xhrCbStart=a.now()))}),f.on("fn-end",function(t,e){this.xhrCbStart&&f.emit("xhr-cb-time",[a.now()-this.xhrCbStart,this.onload,e],e)})}},{}],8:[function(t,e,n){e.exports=function(t){var e=document.createElement("a"),n=window.location,r={};e.href=t,r.port=e.port;var o=e.href.split("://");!r.port&&o[1]&&(r.port=o[1].split("https://admin.chownow.com/")[0].split("@").pop().split(":")[1]),r.port&&"0"!==r.port||(r.port="https"===o[0]?"443":"80"),r.hostname=e.hostname||n.hostname,r.pathname=e.pathname,r.protocol=o[0],"/"!==r.pathname.charAt(0)&&(r.pathname="/"+r.pathname);var i=!e.protocol||":"===e.protocol||e.protocol===n.protocol,a=e.hostname===document.domain&&e.port===n.port;return r.sameOrigin=i&&(!e.hostname||a),r}},{}],9:[function(t,e,n){function r(){}function o(t,e,n){return function(){return i(t,[f.now()].concat(c(arguments)),e?null:this,n),e?void 0:this}}var i=t("handle"),a=t(13),c=t(14),s=t("ee").get("tracer"),f=t("loader"),u=NREUM;"undefined"==typeof window.newrelic&&(newrelic=u);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",p=l+"ixn-";a(d,function(t,e){u[e]=o(l+e,!0,"api")}),u.addPageAction=o(l+"addPageAction",!0),u.setCurrentRouteName=o(l+"routeName",!0),e.exports=newrelic,u.interaction=function(){return(new r).get()};var h=r.prototype={createTracer:function(t,e){var n={},r=this,o="function"==typeof e;return i(p+"tracer",[f.now(),t,n],r),function(){if(s.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return e.apply(this,arguments)}catch(t){throw s.emit("fn-err",[arguments,this,t],n),t}finally{s.emit("fn-end",[f.now()],n)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(t,e){h[e]=o(p+e)}),newrelic.noticeError=function(t,e){"string"==typeof t&&(t=new Error(t)),i("err",[t,f.now(),!1,e])}},{}],10:[function(t,e,n){e.exports=function(t){if("string"==typeof t&&t.length)return t.length;if("object"==typeof t){if("undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer&&t.byteLength)return t.byteLength;if("undefined"!=typeof Blob&&t instanceof Blob&&t.size)return t.size;if(!("undefined"!=typeof FormData&&t instanceof FormData))try{return JSON.stringify(t).length}catch(e){return}}}},{}],11:[function(t,e,n){var r=0,o=navigator.userAgent.match(/Firefox[\/\s](\d+\.\d+)/);o&&(r=+o[1]),e.exports=r},{}],12:[function(t,e,n){function r(t,e){if(!o)return!1;if(t!==o)return!1;if(!e)return!0;if(!i)return!1;for(var n=i.split("."),r=e.split("."),a=0;a<r.length;a++)if(r[a]!==n[a])return!1;return!0}var o=null,i=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var c=navigator.userAgent,s=c.match(a);s&&c.indexOf("Chrome")===-1&&c.indexOf("Chromium")===-1&&(o="Safari",i=s[1])}e.exports={agent:o,version:i,match:r}},{}],13:[function(t,e,n){function r(t,e){var n=[],r="",i=0;for(r in t)o.call(t,r)&&(n[i]=e(r,t[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],14:[function(t,e,n){function r(t,e,n){e||(e=0),"undefined"==typeof n&&(n=t?t.length:0);for(var r=-1,o=n-e||0,i=Array(o<0?0:o);++r<o;)i[r]=t[e+r];return i}e.exports=r},{}],15:[function(t,e,n){e.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],16:[function(t,e,n){function r(t){return!(t&&t instanceof Function&&t.apply&&!t[a])}var o=t("ee"),i=t(14),a="nr@original",c=Object.prototype.hasOwnProperty,s=!1;e.exports=function(t,e){function n(t,e,n,o){function nrWrapper(){var r,a,c,s;try{a=this,r=i(arguments),c="function"==typeof n?n(r,a):n||{}}catch(f){l([f,"",[r,a,o],c])}u(e+"start",[r,a,o],c);try{return s=t.apply(a,r)}catch(d){throw u(e+"err",[r,a,d],c),d}finally{u(e+"end",[r,a,s],c)}}return r(t)?t:(e||(e=""),nrWrapper[a]=t,d(t,nrWrapper),nrWrapper)}function f(t,e,o,i){o||(o="");var a,c,s,f="-"===o.charAt(0);for(s=0;s<e.length;s++)c=e[s],a=t[c],r(a)||(t[c]=n(a,f?c+o:o,i,c))}function u(n,r,o){if(!s||e){var i=s;s=!0;try{t.emit(n,r,o,e)}catch(a){l([a,n,r,o])}s=i}}function d(t,e){if(Object.defineProperty&&Object.keys)try{var n=Object.keys(t);return n.forEach(function(n){Object.defineProperty(e,n,{get:function(){return t[n]},set:function(e){return t[n]=e,e}})}),e}catch(r){l([r])}for(var o in t)c.call(t,o)&&(e[o]=t[o]);return e}function l(e){try{t.emit("internal-error",e)}catch(n){}}return t||(t=o),n.inPlace=f,n.flag=a,n}},{}],ee:[function(t,e,n){function r(){}function o(t){function e(t){return t&&t instanceof r?t:t?s(t,c,i):i()}function n(n,r,o,i){if(!l.aborted||i){t&&t(n,r,o);for(var a=e(o),c=m(n),s=c.length,f=0;f<s;f++)c[f].apply(a,r);var d=u[g[n]];return d&&d.push([x,n,r,a]),a}}function p(t,e){w[t]=m(t).concat(e)}function h(t,e){var n=w[t];if(n)for(var r=0;r<n.length;r++)n[r]===e&&n.splice(r,1)}function m(t){return w[t]||[]}function v(t){return d[t]=d[t]||o(n)}function y(t,e){f(t,function(t,n){e=e||"feature",g[n]=e,e in u||(u[e]=[])})}var w={},g={},x={on:p,addEventListener:p,removeEventListener:h,emit:n,get:v,listeners:m,context:e,buffer:y,abort:a,aborted:!1};return x}function i(){return new r}function a(){(u.api||u.feature)&&(l.aborted=!0,u=l.backlog={})}var c="nr@context",s=t("gos"),f=t(13),u={},d={},l=e.exports=o();l.backlog=u},{}],gos:[function(t,e,n){function r(t,e,n){if(o.call(t,e))return t[e];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,e,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return t[e]=r,r}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],handle:[function(t,e,n){function r(t,e,n,r){o.buffer([t],r),o.emit(t,e,n)}var o=t("ee").get("handle");e.exports=r,r.ee=o},{}],id:[function(t,e,n){function r(t){var e=typeof t;return!t||"object"!==e&&"function"!==e?-1:t===window?0:a(t,i,function(){return o++})}var o=1,i="nr@id",a=t("gos");e.exports=r},{}],loader:[function(t,e,n){function r(){if(!E++){var t=b.info=NREUM.info,e=p.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(t&&t.licenseKey&&t.applicationID&&e))return u.abort();f(g,function(e,n){t[e]||(t[e]=n)}),s("mark",["onload",a()+b.offset],null,"api");var n=p.createElement("script");n.src="https://"+t.agent,e.parentNode.insertBefore(n,e)}}function o(){"complete"===p.readyState&&i()}function i(){s("mark",["domContent",a()+b.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(c=Math.max((new Date).getTime(),c))-b.offset}var c=(new Date).getTime(),s=t("handle"),f=t(13),u=t("ee"),d=t(12),l=window,p=l.document,h="addEventListener",m="attachEvent",v=l.XMLHttpRequest,y=v&&v.prototype;NREUM.o={ST:setTimeout,SI:l.setImmediate,CT:clearTimeout,XHR:v,REQ:l.Request,EV:l.Event,PR:l.Promise,MO:l.MutationObserver};var w=""+location,g={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1118.min.js"},x=v&&y&&y[h]&&!/CriOS/.test(navigator.userAgent),b=e.exports={offset:c,now:a,origin:w,features:{},xhrWrappable:x,userAgent:d};t(9),p[h]?(p[h]("DOMContentLoaded",i,!1),l[h]("load",r,!1)):(p[m]("onreadystatechange",o),l[m]("onload",r)),s("mark",["firstbyte",c],null,"api");var E=0,O=t(15)},{}]},{},["loader",2,7]);</script>

<!--[if gte IE 9]>
    <style type="text/css">
        .gradient {
            filter: none;
        }
    </style>
<![endif]-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600,300,400,700|Open+Sans+Condensed:300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css"/>
    <link rel="icon" type="image/x-icon" href="https://admin.chownow.com/favicon.ico">

            <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/cf.chownowcdn.com/d079bc02779e805afb86a68539a4ceb9/static/cn-admin-base.css">


    <style type="text/css">
        body {
            background: #ecf0f1;
        }
        body #content-header {
            display: none;
        }
        .btn-login {
            background-color: #007170;
            margin-top: 20px;
        }
        .btn-login:hover {
            background-color: #1abc9c;
        }
        .forgot-password {
            float: right;
        }
        .forgot-password a {
            cursor: pointer;
        }
        .instructions {
            margin-bottom: 5px;
        }
        .instructions #close {
            float: right;
            cursor: pointer;
            visibility: hidden;
        }
        .instructions ol li {
            margin-left: 20px;
            list-style: decimal;
        }
        .page-header {
            text-align: center;
        }
        .login-block {
            padding: 15px 40px;
        }
        .login-block input {
            width: 100%;
        }
        .login-block .line {
            margin-bottom: 0;
        }
        .login-block p {
            margin-top: 10px;
            line-height: 20px;
        }
    </style>
<meta name="dashboard-web/config/environment" content="%7B%22modulePrefix%22%3A%22dashboard-web%22%2C%22environment%22%3A%22production%22%2C%22locationType%22%3A%22none%22%2C%22EmberENV%22%3A%7B%22FEATURES%22%3A%7B%7D%7D%2C%22APP%22%3A%7B%22name%22%3A%22dashboard-web%22%2C%22version%22%3A%221.0.8+31ae0343%22%7D%2C%22BUILD%22%3A%7B%22emberCLIDeploy%22%3A%7B%22shouldActivate%22%3Afalse%7D%2C%22fingerprint%22%3A%7B%22enabled%22%3Atrue%2C%22extensions%22%3A%5B%22js%22%2C%22css%22%2C%22png%22%2C%22jpg%22%2C%22gif%22%2C%22map%22%2C%22eot%22%2C%22svg%22%2C%22ttf%22%2C%22woff%22%2C%22otf%22%5D%2C%22generateAssetMap%22%3Atrue%2C%22prepend%22%3A%22https%3A//cf.chownowcdn.com/dashboard-web/%22%7D%2C%22minifyCSS%22%3A%7B%22enabled%22%3Atrue%7D%2C%22minifyJS%22%3A%7B%22enabled%22%3Atrue%7D%2C%22sourcemaps%22%3A%7B%22enabled%22%3Afalse%7D%7D%2C%22podModulePrefix%22%3A%22dashboard-web/pods%22%2C%22something%22%3A%22test%22%2C%22exportApplicationGlobal%22%3Afalse%7D" />

    <!-- Commenting out vendor.css reference since currently not used and causes HTTP error due to
        failed decoding from trying to gzip encode and then decode an empty file... -JM -->
    <!-- <link rel="stylesheet" href="https://cf.chownowcdn.com/dashboard-web/assets/vendor-d41d8cd98f00b204e9800998ecf8427e.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/cf.chownowcdn.com/dashboard-web/assets/dashboard-web-92a84f132645b0f925e693048bbf598c.css">

    <!-- Loggly -->
    
        <script type="text/javascript" src="<?php echo base_url();?>assets/cloudfront.loggly.com/js/loggly.tracker-2.1.min.js" async></script>
        <script>
            // Setting Loggly key to global var to make it accessible to Logger service.
            window.CN_LOGGLY_KEY = 'cf3bb5f9-fc83-4bc8-b915-95b6571b2119';
        </script>
    

    <!-- Google Tag Manager -->
    <!-- Placed here because (1) we don't support noscript, so putting it at the top of the body tag per
        Google's docs isn't necessary and (2) we want to get all tags, so this library should load early. -->
        <script type="text/javascript">
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push(
            {'gtm.start': new Date().getTime(),event:'gtm.js'}
            );var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            '<?php echo base_url();?>assets/www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-NKSLT4');
        </script>
</head>
<body>
    

    <div id="header-wrapper" class='navbar navbar-inverse navbar-fixed-top'>
        <div id="header" class='navbar-inner'>
            <a class="brand" href="https://admin.chownow.com/admin"><img src="<?php echo base_url();?>assets/static/images/admin/header-logo.png"/></a>
        </div>
    </div>
    <div id="content-header">
            &nbsp;
    </div>
    <div id="content-wrapper">
        <div id="content-body">
            <div id="content" class="clearfix">
<div class="container">
    <div class="hero-unit">
        <h1>Welcome!</h1>
    </div>
    <form id="loginForm" method="POST" class="block well login-block">
        <div class="page-header">
            <h4>Log in to Dashboard</h4>
        </div>
        <div class="error response-message" style="display: none"></div>
        
        <div class="line">
            <label for="">Email Address</label>
            <input type="text" id="email" name="email" value>
        </div>
        
        <div class="line">
            <label for="">Password</label><span class="forgot-password"><a>Reset Password</a></span>
            <input type="password" autocomplete="off" id="password" name="password" value>
        </div>
        
        <div id="verifier" style="display:none">
            <div class="instructions">
                <div id="close"><i class="icon-remove icon-large"></i></div>
                <ol class="alert">
                    <li>Check your email for the verification code we sent.</li>
                    <li>Enter your new password above, and the verification code below.</li>
                    <li>Hit "Login" to change your password.</li>
                </ol>
            </div>
                
        
        <div class="line">
            <label>Verification:</label>
            <input id="verify" name="verify" type="text" value="" />
        </div>
    

        </div>
        <div class="line clearfix">
            <label></label>
            <input type="submit" class="btn btn-login" value="Log In">
            <p>
                By logging in you are agreeing to our
                <a href="https://www.chownow.com//registermyresto" target="_blank">Restaurant Agreement</a>
                and our <a href="https://www.chownow.com//privacy-policy" target="_blank">Privacy Policy</a>.
            </p>
        </div>
        <input type="hidden" name="xsrf_token"
                value="2f61646d696e2f6c6f67696e:99a1496636669737:1552550014:0f4dc51bb47c6b9fba91065004c7e74041e0d4c8"/>
        <input type="hidden" id="forgot" value="2f666f72676f74:d924a0a1808e8fe2:1552550014:f58c4c78256de721db3738668ac5ba89ba194119"/>
<div id="password-quality" style="display:none">
    <font style="font-size:120%;font-weight:bold">Choose a decent password:</font><br/>
    <p class="sep"></p>
    1. pick a word at least 6 letters long<br/>
    2. add a number to the middle somewhere<br/>
    3. nothing obvious ('passw0rd' and 'pa55word' are obvious)<br />
    Quality:<br />
    <div style="background: url('<?php echo base_url();?>assets/static/bg_strength_gradient.jpg');width:250px;height:16px;margin-top:3px;">
        <div class="pw-strength-meter" style="height:16px;float:right;background: rgba(32, 32, 32, .7);"></div>
        <div class="pw-strength-value" style="float:right;margin-right:2px;"></div>
    </div>
</div>    </form>
</div>
            </div>
        </div>
    </div>
    <div id="footer">
    </div>
    <div id="shared-tooltip">
        <div class="up-triangle-holder">
            <div class="up-triangle">
            </div>
        </div>
        <div id="shared-tooltip-holder">
            <a id="shared-tooltip-close" style="float:right;display:block;" href="#" onclick="return $('#shared-tooltip').hide() && false">Close</a><br/>
            <div id="shared-tooltip-content"></div>
            <div class="clear"></div>
        </div>
    </div>

    <!-- Older version of jQuery used in non-Ember pages. -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>

            <script type="text/javascript" crossorigin="anonymous" src="<?php echo base_url();?>assets/cf.chownowcdn.com/d079bc02779e805afb86a68539a4ceb9/static/cn-admin-base.js"></script>


    <script type="text/javascript">
        // browser warning
        if ($.browser.msie){
            var version = parseInt($.browser.version, 10);
            var ignore = /^\/admin\/(?:new_restaurant)|(?:tradeshow)|(?:nr\/.*)/.test(window.location.pathname);
            if (version < 8 && !ignore){
                $('#content-header').remove();
                $('#content').html(
                    '<div id="browser-warning">' +
                        'You are using a version of IE that is not supported.<br/>' +
                        'Please upgrade your browser ' +
                        'or consider switching to ' +
                        '<a href="https://www.google.com/chrome" target="_blank">Chrome</a> '+
                        'or <a href="http://getfirefox.com" target="_blank">Firefox</a>.' +
                    '</div>'
                );
            }
        }
        var _showChromeBanner = function() {
            var msg = ('<span>For the best ChowNow experience, we recommend using ' +
                '<a target="_blank" href="https://www.google.com/chrome" class="alert-link">' +
                'Google Chrome</a>.</span>')
            $('<span class="alert alert-warning alert-dismissible browser-warning" role="alert">' +
              '<button type="button" id="chrome" class="close" data-dismiss="alert">' +
              '<span aria-hidden="true">&times;</span></button>' + msg).insertAfter($('#header-nav'));
        }
        var currentSession = "None".replace(/-/g, '');
        if (!navigator.userAgent.match(/chrome/i)) {
            if ($.cookie('chromeAlertClosedSession') == null
                || $.cookie('chromeAlertClosedSession') != currentSession) {
                _showChromeBanner();
            }
        }
        $(document).ready(function() {
            $('#chrome').click(function() {
                $.cookie('chromeAlertClosedSession', currentSession, {path:'/admin'});
            });
        });

    </script>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','<?php echo base_url();?>assets/www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-73547165-1', 'auto');
      ga('send', 'pageview');
    </script>
    <script type="text/javascript">
        $('.forgot-password a').click(function(e){
            cn.forgot('')
        });
        cn.forgot_instructions();

        // gross
    </script>
        <script type="text/javascript">
        function simple_template(input, replacements) {
            var rep;
            for (var i=0; i<replacements.length; i++) {
                rep = replacements[i];
                input = input.replace(new RegExp('{\\s*' + rep[0] + '\\s*}', 'g'), rep[1]);
            }
            return input;
        }
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-30083104-1']);
        _gaq.push(['_setDomainName', 'facebook.chownow.com']);
        _gaq.push(['_trackPageview']);
        (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
        function _track(category, action, opt_label, opt_value, opt_noninteraction) {
            _gaq.push(['_trackEvent', category, action, opt_label, opt_value, opt_noninteraction]);
        }
        window.onerror = function(message, file, line) {
            var sFormattedMessage = '[' + file + ' (' + line + ')] ' + message;
            _track('Exceptions', 'Application', sFormattedMessage, null, true);
        }
    </script>
    

    <!-- Make Raven/Sentry key accessible to JS. -->
    
      <script type="text/javascript">
        window.sentryJSDashboardKey = 'https://5a4d4bf5dfca43f0b71972e7e55ea051@app.getsentry.com/84775';
      </script>
    

    <!-- Only load Ember on specific, whitelisted routes where Ember is used. -->
    <script type="text/javascript">
      (function() {
        var emberURLWhitelist = [
          'merchant-account',
          'onboarding-assets'
        ];

        for (var i = 0, len = emberURLWhitelist.length; i < len; i++) {
          if (window.location.href.indexOf(emberURLWhitelist[i]) > -1) {
            // Load vendor.js
            $.getScript('<?php echo base_url();?>assets/cf.chownowcdn.com/dashboard-web/assets/vendor-73a6769c68d6c8f4ed912bc25fde3d90.js', function() {
              // Set up Raven/Sentry, if key is available.
              if (window.sentryJSDashboardKey) {
                Raven
                  .config('https://5a4d4bf5dfca43f0b71972e7e55ea051@app.getsentry.com/84775')
                  .install();
              }

              // Set up jQuery no-conflict mode to have multiple jQuery versions on one page.
              Ember.imports.$ = $.noConflict(true);

              // Load old jQuery for non-Ember parts of the page.
              $.getScript('<?php echo base_url();?>assets/ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js');

              // Load app.js
              $.getScript('<?php echo base_url();?>assets/cf.chownowcdn.com/dashboard-web/assets/dashboard-web-75172c7e9284d76648c8b81973d1f67f.js', function() {
                // Create app.
                var App = require('dashboard-web/app').default;
                var env = require('dashboard-web/config/environment').default;

                App.create(env);
              });
            });
          }
        }
      })();
    </script>

    

    <script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","queueTime":0,"licenseKey":"e60df8cb0b","agent":"","transactionName":"Y1VQNxAFDxFZUhZbXlofdBYMBxULV19NRFhRR0FNAwAMC1YLDl1WXV4=","applicationID":"2390022","errorBeacon":"bam.nr-data.net","applicationTime":2}</script>
</body>

<!-- Mirrored from admin.chownow.com/admin/login by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Mar 2019 07:53:50 GMT -->
</html>