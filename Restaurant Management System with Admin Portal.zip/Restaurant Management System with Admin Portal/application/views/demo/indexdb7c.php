<!doctype html>
<html lang="en">

<!-- Mirrored from get.chownow.com/demo/?utm_source=chownow_blog&utm_medium=blog&utm_campaign=chownow_discover_FAQ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2019 04:29:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
            
    
    <meta charset="utf-8"/>
    <meta content="ie=edge" http-equiv="x-ua-compatible"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="W66cQp7gBOLbAnH38kA5qg4r8rEupJNKs1hMfFrqFyU" />
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width"/>
      
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/leitura.css"/>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/style082b.css?ver=1551900569"/>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/list-preserve.css"/>

    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/modernizr.js" type="text/javascript"></script> <!-- Modernizr Script -->
    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/live-chat.js" type="text/javascript"></script> <!-- Drift Script -->
    
    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
            n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
            document,'script','<?php echo base_url();?>assets/connect.facebook.net/en_US/fbevents.js');

        fbq('init', '327022734331437');
        fbq('track', "PageView");
        fbq('track', 'ViewContent');

    </script>
    <noscript>
      <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=327022734331437&amp;ev=PageView&amp;noscript=1"/>
    </noscript>
            <script>fbq('track', 'Lead');</script>
            <!-- End Facebook Pixel Code -->

    
<!-- This site is optimized with the Yoast SEO Premium plugin v9.7 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Free Demo - Try Restaurant Software and Apps from ChowNow</title>
<meta name="description" content="Try ChowNow’s online ordering system and other restaurant software, including mobile apps to empower your business and online food ordering."/>
<link rel="canonical" href="index.html" />
<link rel="publisher" href="https://plus.google.com/101895682576973656922"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Free Demo - Try Restaurant Software and Apps from ChowNow" />
<meta property="og:description" content="Try ChowNow’s online ordering system and other restaurant software, including mobile apps to empower your business and online food ordering." />
<meta property="og:url" content="https://get.chownow.com/demo/" />
<meta property="og:site_name" content="ChowNow" />
<meta property="article:publisher" content="https://www.facebook.com/ChowNow" />
<meta property="fb:app_id" content="107023862672798" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Try ChowNow’s online ordering system and other restaurant software, including mobile apps to empower your business and online food ordering." />
<meta name="twitter:title" content="Free Demo - Try Restaurant Software and Apps from ChowNow" />
<meta name="twitter:site" content="@ChowNow" />
<meta name="twitter:image" content="https://get.chownow.com/wp-content/uploads/CN_Logo2Color_Horizontal_small.png" />
<meta name="twitter:creator" content="@ChowNow" />
<script type='application/ld+json'>{"@context":"https://schema.org","@type":"Organization","url":"https://get.chownow.com/","sameAs":["https://www.facebook.com/ChowNow","https://instagram.com/chownow","https://www.linkedin.com/company/chownow","https://plus.google.com/101895682576973656922","https://www.youtube.com/channel/UCU5PE-NonMTV1WmfMoSBbXQ","https://twitter.com/ChowNow"],"@id":"https://get.chownow.com/#organization","name":"ChowNow","logo":"https://get.chownow.com/wp-content/uploads/CN_LogoPin_google_112x112.png"}</script>
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='http://s.w.org/' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/get.chownow.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='<?php echo base_url();?>assets/wp-includes/css/dist/block-library/style.minc721.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-lightbox-tosrus-css'  href='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/tosrus/css/jquery.tosrus.min.all3c94.css?ver=2.1.0' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/infinitescroll/infinite-scroll.pkgd.minc721.js?ver=5.1'></script>
<link rel='https://api.w.org/' href='<?php echo base_url();?>assets/wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo base_url();?>assets/xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo base_url();?>assets/wp-includes/wlwmanifest.xml" /> 
<link rel='shortlink' href='../index5388.html?p=6374' />
<link rel="alternate" type="application/json+oembed" href="<?php echo base_url();?>assets/wp-json/oembed/1.0/embedf268.json?url=https%3A%2F%2Fget.chownow.com%2Fdemo%2F" />
<link rel="alternate" type="text/xml+oembed" href="<?php echo base_url();?>assets/wp-json/oembed/1.0/embed2dd1?url=https%3A%2F%2Fget.chownow.com%2Fdemo%2F&amp;format=xml" />


<!-- Plugin: Open external links a new window. Plugin by Kristian Risager Larsen, http://kristianrisagerlarsen.dk . Download it at http://wordpress.org/extend/plugins/open-external-links-in-a-new-window/ -->
<script type="text/javascript">//<![CDATA[
	function external_links_in_new_windows_loop() {
		if (!document.links) {
			document.links = document.getElementsByTagName('a');
		}
		var change_link = false;
		var force = '';
		var ignore = '';

		for (var t=0; t<document.links.length; t++) {
			var all_links = document.links[t];
			change_link = false;
			
			if(document.links[t].hasAttribute('onClick') == false) {
				// forced if the address starts with http (or also https), but does not link to the current domain
				if(all_links.href.search(/^http/) != -1 && all_links.href.search('get.chownow.com') == -1) {
					// alert('Changeda '+all_links.href);
					change_link = true;
				}
					
				if(force != '' && all_links.href.search(force) != -1) {
					// forced
					// alert('force '+all_links.href);
					change_link = true;
				}
				
				if(ignore != '' && all_links.href.search(ignore) != -1) {
					// alert('ignore '+all_links.href);
					// ignored
					change_link = false;
				}

				if(change_link == true) {
					// alert('Changed '+all_links.href);
					document.links[t].setAttribute('onClick', 'javascript:window.open(\''+all_links.href+'\'); return false;');
					document.links[t].removeAttribute('target');
				}
			}
		}
	}
	
	// Load
	function external_links_in_new_windows_load(func)
	{	
		var oldonload = window.onload;
		if (typeof window.onload != 'function'){
			window.onload = func;
		} else {
			window.onload = function(){
				oldonload();
				func();
			}
		}
	}

	external_links_in_new_windows_load(external_links_in_new_windows_loop);
	//]]></script>

<script src="<?php echo base_url();?>assets/app-ab06.marketo.com/js/forms2/js/forms2.min.js"></script> <!--Marketo form js --><link rel="icon" href="../wp-content/uploads/CN_LogoPin_google_112x112-100x100.png" sizes="32x32" />
<link rel="icon" href="<?php echo base_url();?>assets/wp-content/uploads/CN_LogoPin_google_112x112.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="<?php echo base_url();?>assets/wp-content/uploads/CN_LogoPin_google_112x112.png" />
<meta name="msapplication-TileImage" content="https://get.chownow.com/wp-content/uploads/CN_LogoPin_google_112x112.png" />

    <!-- Marketo Munchkin -->
    <script type="text/javascript">
    (function() {
      var didInit = false;
      function initMunchkin() {
        if(didInit === false) {
          didInit = true;
          Munchkin.init('129-RCW-450');
        }
      }
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = '<?php echo base_url();?>assets/munchkin.marketo.net/munchkin.js';
      s.onreadystatechange = function() {
        if (this.readyState == 'complete' || this.readyState == 'loaded') {
          initMunchkin();
        }
      };
      s.onload = initMunchkin;
      document.getElementsByTagName('head')[0].appendChild(s);
    })();
    </script>

    <!-- Marketo Dynamic Content RTP tag --> 
    <script type='text/javascript'>
    (function(c,h,a,f,i,e){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
    c[a].a=i;c[a].e=e;var g=h.createElement("script");g.async=true;g.type="text/javascript";
    g.src=f+'?aid='+i;var b=h.getElementsByTagName("script")[0];b.parentNode.insertBefore(g,b);
    })(window,document,"rtp","<?php echo base_url();?>assets/sjrtp-cdn.marketo.com/rtp-api/v1/rtp.js","chownow");
    
    rtp('send','view');
    rtp('get', 'campaign',true);
    </script>
    <!-- End of Marketo Dynamic Content RTP tag -->

    <!-- Wistia Video Embed -->
    <script src="<?php echo base_url();?>assets/fast.wistia.net/assets/external/E-v1.js" async></script>

</head>

<body class="page demo">
<!-- Google Tag Manager -->
<script>
    var dataLayer = [];
</script>
<noscript>
    <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-TG6Q92"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<script>(function (w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(), event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            '<?php echo base_url();?>assets/www.googletagmanager.com/gtm5445.html?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-TG6Q92');</script>
<!-- End Google Tag Manager -->
    <div class="site">

      <div class="header">
        <div class="header__menu">
          <div class="container">
            <div class="h1_logo">
              <a href="../index.html">
                <span>ChowNow</span>
              </a>
            </div>
            <h2><span>Questions?</span> 1 (888) 707-2469</h2>
          </div>
          <div class="header__menu__solid"></div>
        </div>
      </div>

      <div class="main">

        <div class="banner mini center">
          <div class="container">
            <div class="banner__headline">
              <div class="common-table">
                <div class="common-cell">
                  <h1 class="headline_header">
                    Chat with a ChowNow Expert                  </h1>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="demo">
          <div class="container">
            <div class="demo__content common-content">
<p><span style="font-weight: 400;">ChowNow builds your restaurant its very own online ordering system. Take unlimited, commission-free orders through your website, Facebook, Instagram, and custom mobile apps. Maximize your profits with complimentary marketing strategy, and enjoy 24/7 support.</span></p>
<p><span style="font-weight: 400;">Make online ordering easy and profitable by scheduling a demo today. After all, food this good demands to be shared.</span></p>
            </div>
            <div class="demo__form common-form">
              <div class="gate-c789ef96-e21e-4d17-a443-23e40b0530c9"></div>
            </div>
            <div class="demo__note">
              <p>Already a ChowNow client or need help with an order? <a href="../contact/index.html">Contact Support</a>.</p>
              <p>888-707-2469 <span>/</span> <a href="mailto:support@chownow.com">support@chownow.com</a></p>
            </div>
          </div>
          <div class="error fixed">
            <div class="container">
              <div class="error__content"></div>
              <div class="error__close common-close"><a href="#"><svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M10.667 0L6 4.666 1.334 0 0 1.333 4.667 6 0 10.665 1.333 12 6 7.333 10.668 12 12 10.666 7.333 6 12 1.332 10.667 0z" fill="#36363D" fill-rule="evenodd"/></svg></a></div>
            </div>
          </div>
        </div>

      </div>

    </div>

    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/script9922.js?ver=1543886077" async>
    </script>

    <link rel='stylesheet' id='lato-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato%3A300%2C400%2C700%2C900&amp;ver=5.1' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/tosrus/js/jquery.tosrus.min.all3c94.js?ver=2.1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var rlArgs = {"script":"tosrus","selector":"lightbox","customEvents":"","activeGalleries":"1","effect":"slide","infinite":"1","keys":"0","autoplay":"1","pauseOnHover":"0","timeout":"4000","pagination":"1","paginationType":"thumbnails","closeOnClick":"0","woocommerce_gallery":"0","ajaxurl":"https:\/\/get.chownow.com\/wp-admin\/admin-ajax.php","nonce":"104c998189"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/js/front3c94.js?ver=2.1.0'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/wp-embed.minc721.js?ver=5.1'></script>
  </body>


<!-- Mirrored from get.chownow.com/demo/?utm_source=chownow_blog&utm_medium=blog&utm_campaign=chownow_discover_FAQ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2019 04:29:52 GMT -->
</html>
