<!doctype html>
<html lang="en">

<!-- Mirrored from get.chownow.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2019 04:20:29 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
            
    
    <meta charset="utf-8"/>
    <meta content="ie=edge" http-equiv="x-ua-compatible"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="W66cQp7gBOLbAnH38kA5qg4r8rEupJNKs1hMfFrqFyU" />
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width"/>
      
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/leitura.css"/>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/style082b.css?ver=1551900569"/>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/wp-content/themes/chownow4/css/list-preserve.css"/>

    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/modernizr.js" type="text/javascript"></script> <!-- Modernizr Script -->
    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/live-chat.js" type="text/javascript"></script> <!-- Drift Script -->
    
    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
            n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
            document,'script','<?php echo base_url();?>assets/connect.facebook.net/en_US/fbevents.js');

        fbq('init', '327022734331437');
        fbq('track', "PageView");
        fbq('track', 'ViewContent');

    </script>
    <noscript>
      <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=327022734331437&amp;ev=PageView&amp;noscript=1"/>
    </noscript>
            <script>fbq('track', 'Lead');</script>
            <!-- End Facebook Pixel Code -->

    
<!-- This site is optimized with the Yoast SEO Premium plugin v9.7 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Online Food Ordering System &amp; App | ChowNow</title>
<meta name="description" content="ChowNow is an online food ordering system and marketing platform helping restaurants feed their hungry customers."/>
<link rel="canonical" href="index.html" />
<link rel="publisher" href="https://plus.google.com/101895682576973656922"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Online Food Ordering System &amp; App | ChowNow" />
<meta property="og:description" content="ChowNow is an online food ordering system and marketing platform helping restaurants feed their hungry customers." />
<meta property="og:url" content="https://get.chownow.com/" />
<meta property="og:site_name" content="ChowNow" />
<meta property="fb:app_id" content="107023862672798" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="ChowNow is an online food ordering system and marketing platform helping restaurants feed their hungry customers." />
<meta name="twitter:title" content="Online Food Ordering System &amp; App | ChowNow" />
<meta name="twitter:site" content="@ChowNow" />
<meta name="twitter:image" content="https://get.chownow.com/wp-content/uploads/CN_Logo2Color_Horizontal_small.png" />
<meta name="twitter:creator" content="@ChowNow" />
<script type='application/ld+json'>{"@context":"https://schema.org","@type":"WebSite","@id":"https://get.chownow.com/#website","url":"https://get.chownow.com/","name":"ChowNow","potentialAction":{"@type":"SearchAction","target":"https://get.chownow.com/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"https://schema.org","@type":"Organization","url":"https://get.chownow.com/","sameAs":["https://www.facebook.com/ChowNow","https://instagram.com/chownow","https://www.linkedin.com/company/chownow","https://plus.google.com/101895682576973656922","https://www.youtube.com/channel/UCU5PE-NonMTV1WmfMoSBbXQ","https://twitter.com/ChowNow"],"@id":"https://get.chownow.com/#organization","name":"ChowNow","logo":"https://get.chownow.com/wp-content/uploads/CN_LogoPin_google_112x112.png"}</script>
<meta name="p:domain_verify" content="28097f8e4d0642e7a64776a063fb6664" />
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='http://s.w.org/' />
        <script type="text/javascript">
            window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/get.chownow.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1"}};
            !function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
        </script>
        <style type="text/css">
img.wp-smiley,
img.emoji {
    display: inline !important;
    border: none !important;
    box-shadow: none !important;
    height: 1em !important;
    width: 1em !important;
    margin: 0 .07em !important;
    vertical-align: -0.1em !important;
    background: none !important;
    padding: 0 !important;
}
</style>
    <link rel='stylesheet' id='wp-block-library-css'  href='<?php echo base_url();?>assets/wp-includes/css/dist/block-library/style.minc721.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-lightbox-tosrus-css'  href='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/tosrus/css/jquery.tosrus.min.all3c94.css?ver=2.1.0' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/infinitescroll/infinite-scroll.pkgd.minc721.js?ver=5.1'></script>
<link rel='https://api.w.org/' href='<?php echo base_url();?>assets/wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo base_url();?>assets/xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo base_url();?>assets/wp-includes/wlwmanifest.xml" /> 
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="<?php echo base_url();?>assets/wp-json/oembed/1.0/embed2ac3.json?url=https%3A%2F%2Fget.chownow.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="<?php echo base_url();?>assets/wp-json/oembed/1.0/embedfaae?url=https%3A%2F%2Fget.chownow.com%2F&amp;format=xml" />


<!-- Plugin: Open external links a new window. Plugin by Kristian Risager Larsen, http://kristianrisagerlarsen.dk . Download it at http://wordpress.org/extend/plugins/open-external-links-in-a-new-window/ -->
<script type="text/javascript">//<![CDATA[
    function external_links_in_new_windows_loop() {
        if (!document.links) {
            document.links = document.getElementsByTagName('a');
        }
        var change_link = false;
        var force = '';
        var ignore = '';

        for (var t=0; t<document.links.length; t++) {
            var all_links = document.links[t];
            change_link = false;
            
            if(document.links[t].hasAttribute('onClick') == true) {
                // forced if the address starts with http (or also https), but does not link to the current domain
                if(all_links.href.search(/^http/) != -1 && all_links.href.search('get.chownow.com') == -1) {
                    // alert('Changeda '+all_links.href);
                    change_link = true;
                }
                    
                if(force != '' && all_links.href.search(force) != -1) {
                    // forced
                    // alert('force '+all_links.href);
                    change_link = true;
                }
                
                if(ignore != '' && all_links.href.search(ignore) != -1) {
                    // alert('ignore '+all_links.href);
                    // ignored
                    change_link = false;
                }

                if(change_link == true) {
                    // alert('Changed '+all_links.href);
                    document.links[t].setAttribute('onClick', 'javascript:window.open(\''+all_links.href+'\'); return false;');
                    document.links[t].removeAttribute('target');
                }
            }
        }
    }
    
    // Load
    function external_links_in_new_windows_load(func)
    {   
        var oldonload = window.onload;
        if (typeof window.onload != 'function'){
            window.onload = func;
        } else {
            window.onload = function(){
                oldonload();
                func();
            }
        }
    }

    external_links_in_new_windows_load(external_links_in_new_windows_loop);
    //]]></script>
    <link rel='stylesheet' id='ABHfrontend.min.css-css'  href='<?php echo base_url();?>assets/wp-content/plugins/starbox/themes/business/css/frontend.minee9a.css?ver=3.2.2' type='text/css' media='all' />
    <script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/starbox/themes/business/js/frontend.minee9a.js?ver=3.2.2'></script>
<link rel='stylesheet' id='ABHhidedefault.min.css-css'  href='<?php echo base_url();?>assets/wp-content/plugins/starbox/themes/admin/css/hidedefault.minee9a.css?ver=3.2.2' type='text/css' media='all' />

<script src="<?php echo base_url();?>assets/app-ab06.marketo.com/js/forms2/js/forms2.min.js"></script> <!--Marketo form js --><link rel="icon" href="<?php echo base_url();?>assets/wp-content/uploads/CN_LogoPin_google_112x112-100x100.png" sizes="32x32" />
<link rel="icon" href="<?php echo base_url();?>assets/wp-content/uploads/CN_LogoPin_google_112x112.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="<?php echo base_url();?>assets/wp-content/uploads/CN_LogoPin_google_112x112.png" />
<meta name="msapplication-TileImage" content="https://get.chownow.com/wp-content/uploads/CN_LogoPin_google_112x112.png" />

    <!-- Marketo Munchkin -->
    <script type="text/javascript">
    (function() {
      var didInit = false;
      function initMunchkin() {
        if(didInit === false) {
          didInit = true;
          Munchkin.init('129-RCW-450');
        }
      }
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = '<?php echo base_url();?>assets/munchkin.marketo.net/munchkin.js';
      s.onreadystatechange = function() {
        if (this.readyState == 'complete' || this.readyState == 'loaded') {
          initMunchkin();
        }
      };
      s.onload = initMunchkin;
      document.getElementsByTagName('head')[0].appendChild(s);
    })();
    </script>

    <!-- Marketo Dynamic Content RTP tag --> 
    <script type='text/javascript'>
    (function(c,h,a,f,i,e){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
    c[a].a=i;c[a].e=e;var g=h.createElement("script");g.async=true;g.type="text/javascript";
    g.src=f+'?aid='+i;var b=h.getElementsByTagName("script")[0];b.parentNode.insertBefore(g,b);
    })(window,document,"rtp","<?php echo base_url();?>assets/sjrtp-cdn.marketo.com/rtp-api/v1/rtp.js","chownow");
    
    rtp('send','view');
    rtp('get', 'campaign',true);
    </script>
    <!-- End of Marketo Dynamic Content RTP tag -->

    <!-- Wistia Video Embed -->
    <script src="<?php echo base_url();?>assets/fast.wistia.net/assets/external/E-v1.js" async></script>

</head>

<body class="home">
<!-- Google Tag Manager -->
<script>
    var dataLayer = [];
</script>
<noscript>
    <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-TG6Q92"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<script>(function (w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(), event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            '<?php echo base_url();?>assets/www.googletagmanager.com/gtm5445.html?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-TG6Q92');</script>
<!-- End Google Tag Manager -->
<div class="nav">
    <div class="nav__menu">
        <div class="nav__menu__close common-close">
            <a href="<?php echo base_url();?>#">
                <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.667 0L6 4.666 1.334 0 0 1.333 4.667 6 0 10.665 1.333 12 6 7.333 10.668 12 12 10.666 7.333 6 12 1.332 10.667 0z" fill="#36363D" fill-rule="evenodd"/>
                </svg>
            </a>
        </div>
        <div class="nav__menu__options">
                            <ul class="main">
                                            <li><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                            <li><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                            <li><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                            <li><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>
                                <p class="subTitle">Add Ons</p>
                <ul class="sub">
                                            <li><a href="<?php echo site_url('UserController/restraurantMarketing') ?>"
                                target="">Marketing</a></li>
                                            <li><a href="<?php echo site_url('UserController/restraurantWebsite') ?>"
                                target="">Websites</a></li>
                                            <li><a href="<?php echo site_url('UserController/about') ?>"
                                target="">About Us</a></li>
                                            <li><a href="https://jobs.lever.co/chownow"
                                target="_blank">Careers</a></li>
                                            <li><a href="<?php echo site_url('UserController/blog') ?>"
                                target="">Blog</a></li>
                                            <li><a href="<?php echo site_url('UserController/contact') ?>"
                                target="">Contact</a></li>
                                    </ul>
                                <ul class="extras">
                                            <li><a
                                href="<?php echo site_url('UserController/refund') ?>"
                                target="">Refund Policy</a></li>
                                            <li><a
                                href="<?php echo site_url('UserController/termsAndServices') ?>"
                                target="">Terms of Service</a></li>
                                            <li><a
                                href="<?php echo site_url('UserController/privacyPolicy') ?>"
                                target="">Privacy Policy</a></li>
                                    </ul>
                    </div>
        <div class="nav__menu__footer">
            <ol>
                <li class="instagram"><a href="https://instagram.com/ChowNow/"
                                         target="_blank"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M16 2.336v11.328C16 14.954 14.953 16 13.664 16H2.336C1.046 16 0 14.953 0 13.664V2.336C0 1.046 1.047 0 2.336 0h11.328C14.954 0 16 1.047 16 2.336zM14.336 7h-1.773c.07.32.102.656.102 1 0 2.578-2.086 4.664-4.665 4.664-2.578 0-4.664-2.086-4.664-4.664 0-.344.03-.68.102-1H1.664v7c0 .188.15.336.336.336h12c.188 0 .336-.148.336-.336V7zM5 8c0 1.657 1.344 3 3 3 1.657 0 3-1.343 3-3 0-1.656-1.343-3-3-3-1.656 0-3 1.344-3 3zm9.336-6c0-.187-.148-.336-.336-.336h-2c-.187 0-.336.15-.336.336v2c0 .188.15.336.336.336h2c.188 0 .336-.148.336-.336V2z" fill="#36363D" fill-rule="evenodd"/></svg></a></li>
                <li class="twitter"><a href="https://twitter.com/ChowNow"
                                       target="_blank"><svg width="16" height="13" viewBox="0 0 16 13" xmlns="http://www.w3.org/2000/svg"><path d="M14.368 3.235v.43C14.368 8 11.07 13 5.038 13 3.19 13 1.446 12.594 0 11.664c.258.04.516.055.782.055 1.53 0 2.96-.666 4.07-1.557-1.422-.015-2.65-.984-3.055-2.28.203.038.406.062.61.062.297 0 .593-.04.875-.118C1.782 7.53.65 6.203.65 4.61v-.04c.444.243.944.39 1.483.407-.89-.594-1.468-1.594-1.468-2.72 0-.608.17-1.108.445-1.593 1.633 1.985 4.04 3.22 6.757 3.368-.054-.235-.07-.5-.07-.758C7.797 1.46 9.257 0 11.07 0c.946 0 1.798.406 2.415 1.032.734-.15 1.445-.422 2.07-.797-.242.765-.758 1.414-1.445 1.82.67-.078 1.297-.258 1.89-.524-.445.674-1 1.245-1.632 1.706" fill="#36363D" fill-rule="evenodd"/></svg></a></li>
                <li class="facebook"><a href="https://facebook.com/ChowNow"
                                        target="_blank"><svg width="8" height="16" viewBox="0 0 8 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.614 3.1v2.2H0v2.695h1.614V16H4.93V7.996h2.224s.208-1.292.31-2.704H4.942V3.45c0-.276.36-.645.72-.645h1.805V0H5.01C1.532 0 1.614 2.696 1.614 3.1" fill="#36363D" fill-rule="evenodd"/></svg></a></li>
                <li class="linkedin"><a href="https://linkedin.com/company/chownow"
                                        target="_blank"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.96 3.743C.78 3.743 0 2.913 0 1.867 0 .814.797 0 2.016 0 3.22 0 3.986.814 4 1.867c0 1.046-.78 1.876-2.015 1.876H1.96zm-1.624 1.7h3.328V16H.336V5.442zM9 9.87c0-1.363.852-2.042 1.852-2.042s1.812.68 1.812 2.387V16H16V9.87c0-3.063-1.664-4.763-4-4.763-1.335 0-2.336.775-3 1.796l-.11-1.46H5.61c0 .36.054 2.385.054 2.385V16H9V9.87z" fill="#36363D" fill-rule="evenodd"/></svg></a></li>
            </ol>
            <p><a href="<?php echo site_url("UserController/login");?>" class="common-button pill red"
                  target="_blank">Account Login</a></p>
        </div>
    </div>
    <div class="nav__overlay"></div>
</div>
