<?php
$this->load->view("includes/header");
$this->load->view("includes/blogheader");
$this->load->view($page);
$this->load->view("includes/footer");

