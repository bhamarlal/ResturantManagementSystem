

<div class="swipe"></div>

<div class="site">

    <div class="header">
                <div class="header__menu">
                            <div class="h1_logo"><a href="<?php echo site_url('Welcome/index') ?>"><span>ChowNow</span></a></div>
                        <a href="tel:18887072469" class="phone">888-707-2469</a><ul class="center_menu">
                                                    <li class="option how"><a href="<?php echo site_url('Welcome/onlineorder') ?>">How It Works</a></li>
                                                            <li class="option testimonials"><a href="<?php echo site_url('Welcome/testimonials') ?>">Testimonials</a></li>
                                                            <li class="option pricing"><a href="<?php echo site_url('Welcome/pricing') ?>">Pricing</a></li>
                                    </ul><p><a href="#"><svg width="12" height="15" viewBox="0 0 12 15" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 12h-9c-.828 0-1.5.672-1.5 1.5S.672 15 1.5 15h9c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5m0-6h-9C.672 6 0 6.672 0 7.5 0 8.33.672 9 1.5 9h9c.828 0 1.5-.67 1.5-1.5 0-.828-.672-1.5-1.5-1.5m-9-3h9c.828 0 1.5-.672 1.5-1.5S11.328 0 10.5 0h-9C.672 0 0 .672 0 1.5S.672 3 1.5 3" fill="#FFF" fill-rule="evenodd"/></svg></a></p><ul>                        <li class="demo"><a href="<?php echo site_url('UserController/demoRequest') ?>">Request a Demo</a></li>
                                    </ul>

            <div class="header__menu__fill"></div>
        </div>
    </div>

    <div class="main">

        <div class="banner blog center">
          <div class="container">
            <div class="banner__headline">
              <div class="common-table">
                <div class="common-cell">
                  <h1 class="headline_header"><a href="<?php echo site_url('UserController/blog') ?>">The ChowNow Blog</a></h1>
                  <h3>Your source for the latest in restaurant marketing, tech, and takeout.</h3>
                  <div class="banner__headline__categories">
                    <p><span><a href="<?php echo site_url('UserController/blog') ?>">Everything</a></span><span class="selected"><a href="<?php echo site_url('UserController/clientSpotLight') ?>">Client Spotlight</a></span><span><a href="<?php echo site_url('UserController/clientStory') ?>">Client Story</a></span><span><a href="<?php echo site_url('UserController/howTo') ?>">How to</a></span><span><a href="<?php echo site_url('UserController/theNews') ?>">In The News</a></span><span><a href="<?php echo site_url('UserController/marketingBlog') ?>">Marketing</a></span><span><a href="<?php echo site_url('UserController/mobileBlog') ?>">Mobile</a></span><span><a href="<?php echo site_url('UserController/onlineBlog') ?>">Online Ordering System</a></span><span><a href="<?php echo site_url('UserController/restaurantBlog') ?>">Restaurant Tech</a></span><span><a href="<?php echo site_url('UserController/socialMediaBlog') ?>">Social Media</a></span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>