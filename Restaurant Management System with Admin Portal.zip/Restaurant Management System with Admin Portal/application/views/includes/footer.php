
<div class="footer">
            <div class="footer_contact">
            Already a client, or need help with an<span class="notLato">&nbsp;</span>order? Contact ChowNow Support. <br />
                <span class="contactDetails"><span>888-707-2469</span>  or  <a href="<?php echo site_url('UserController/contact') ?>">contact us</a></span>
        </div>
        <div class="container">
        <div class="common-wrap">
            <div class="footer__group left logo">
                <a href="<?php echo site_url('Welcome/index') ?>">ChowNow</a>
            </div>
            <div class="footer__group left">
                <h2>Learn More</h2>
                <ul class="menu">
                                                <li><a href="<?php echo site_url('Welcome/onlineorder') ?>"
                                    target="">How It Works</a>
                            </li>
                                                        <li><a href="<?php echo site_url('Welcome/testimonials') ?>"
                                    target="">Testimonials</a>
                            </li>
                                                        <li><a href="<?php echo site_url('Welcome/pricing') ?>"
                                    target="">Pricing</a>
                            </li>
                                                        <li><a href="<?php echo site_url('UserController/blog') ?>"
                                    target="">Blog</a>
                            </li>
                                            </ul>
            </div>
            <div class="footer__group left">
                <h2>Add-Ons</h2>
                <ul class="menu">
                                                <li><a href="<?php echo site_url('UserController/restraurantMarketing') ?>"
                                    target="">Marketing</a>
                            </li>
                                                        <li><a href="<?php echo site_url('UserController/restraurantWebsite') ?>"
                                    target="">Websites</a>
                            </li>
                                            </ul>
            </div>
            <div class="footer__group left">
                <h2>Company</h2>
                <ul class="menu">
                                                <li><a href="<?php echo site_url('UserController/about') ?>"
                                    target="">About</a>
                            </li>
                                                        <li><a href="https://jobs.lever.co/chownow"
                                    target="">Careers</a>
                            </li>
                                                        <li><a href="<?php echo site_url('UserController/contact') ?>"
                                    target="">Contact</a>
                            </li>
                                            </ul>
            </div>
            <div class="footer__group left">
                <h2>Legal</h2>
                <ul class="menu">
                                                <li><a href="<?php echo site_url('UserController/refund') ?>"
                                    target="">Refund Policy</a>
                            </li>
                                                        <li><a href="<?php echo site_url('UserController/termsAndServices') ?>"
                                    target="">Terms</a>
                            </li>
                                                        <li><a href="<?php echo site_url('UserController/privacyPolicy') ?>"
                                    target="">Privacy Policy</a>
                            </li>
                                            </ul>
            </div>
        </div>
        <div class="common-wrap">
            <div class="footer-callout">
                <span>Looking to order food? <span class="wrap">Find your city’s best eats.</span></span>
                <a href="#" class="common-button pill slim red page">ORDER NOW</a>
            </div>
        </div>
        <div class="common-wrap">
            <div class="footer__group right social">
                <ol>
                    <li class="instagram"><a href="https://instagram.com/ChowNow/"
                                             target="_blank"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M16 2.336v11.328C16 14.954 14.953 16 13.664 16H2.336C1.046 16 0 14.953 0 13.664V2.336C0 1.046 1.047 0 2.336 0h11.328C14.954 0 16 1.047 16 2.336zM14.336 7h-1.773c.07.32.102.656.102 1 0 2.578-2.086 4.664-4.665 4.664-2.578 0-4.664-2.086-4.664-4.664 0-.344.03-.68.102-1H1.664v7c0 .188.15.336.336.336h12c.188 0 .336-.148.336-.336V7zM5 8c0 1.657 1.344 3 3 3 1.657 0 3-1.343 3-3 0-1.656-1.343-3-3-3-1.656 0-3 1.344-3 3zm9.336-6c0-.187-.148-.336-.336-.336h-2c-.187 0-.336.15-.336.336v2c0 .188.15.336.336.336h2c.188 0 .336-.148.336-.336V2z" fill="#36363D" fill-rule="evenodd"/></svg></a>
                    </li>
                    <li class="twitter"><a href="https://twitter.com/ChowNow"
                                           target="_blank"><svg width="16" height="13" viewBox="0 0 16 13" xmlns="http://www.w3.org/2000/svg"><path d="M14.368 3.235v.43C14.368 8 11.07 13 5.038 13 3.19 13 1.446 12.594 0 11.664c.258.04.516.055.782.055 1.53 0 2.96-.666 4.07-1.557-1.422-.015-2.65-.984-3.055-2.28.203.038.406.062.61.062.297 0 .593-.04.875-.118C1.782 7.53.65 6.203.65 4.61v-.04c.444.243.944.39 1.483.407-.89-.594-1.468-1.594-1.468-2.72 0-.608.17-1.108.445-1.593 1.633 1.985 4.04 3.22 6.757 3.368-.054-.235-.07-.5-.07-.758C7.797 1.46 9.257 0 11.07 0c.946 0 1.798.406 2.415 1.032.734-.15 1.445-.422 2.07-.797-.242.765-.758 1.414-1.445 1.82.67-.078 1.297-.258 1.89-.524-.445.674-1 1.245-1.632 1.706" fill="#36363D" fill-rule="evenodd"/></svg></a></li>
                    <li class="facebook"><a href="https://facebook.com/ChowNow"
                                            target="_blank"><svg width="8" height="16" viewBox="0 0 8 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.614 3.1v2.2H0v2.695h1.614V16H4.93V7.996h2.224s.208-1.292.31-2.704H4.942V3.45c0-.276.36-.645.72-.645h1.805V0H5.01C1.532 0 1.614 2.696 1.614 3.1" fill="#36363D" fill-rule="evenodd"/></svg></a>
                    </li>
                    <li class="linkedin"><a href="https://linkedin.com/company/chownow"
                                            target="_blank"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M1.96 3.743C.78 3.743 0 2.913 0 1.867 0 .814.797 0 2.016 0 3.22 0 3.986.814 4 1.867c0 1.046-.78 1.876-2.015 1.876H1.96zm-1.624 1.7h3.328V16H.336V5.442zM9 9.87c0-1.363.852-2.042 1.852-2.042s1.812.68 1.812 2.387V16H16V9.87c0-3.063-1.664-4.763-4-4.763-1.335 0-2.336.775-3 1.796l-.11-1.46H5.61c0 .36.054 2.385.054 2.385V16H9V9.87z" fill="#36363D" fill-rule="evenodd"/></svg></a>
                    </li>
                </ol>
            </div>
            <div class="footer__group left copyright">
                &copy; 2019 ChowNow. All Rights Reserved.
            </div>
        </div>
    </div>
</div>

</div>
    <div class="modal home">
      <div class="modal__close common-close"><a href="#"><svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M10.667 0L6 4.666 1.334 0 0 1.333 4.667 6 0 10.665 1.333 12 6 7.333 10.668 12 12 10.666 7.333 6 12 1.332 10.667 0z" fill="#36363D" fill-rule="evenodd"/></svg></a></div>
      <div class="modal__back"></div>
      <div class="modal__table">
        <div class="modal__cell">
          <div class="modal__content">
            <div class="container">
              <div class="modal__content__video"></div>
              <div class="modal__content__note">
                <p><span>Sound Tasty?</span> <a href="demo/index.html" class="common-button pill red">Request a Demo</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal testimonials">
      <div class="modal__close common-close"><a href="#"><svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M10.667 0L6 4.666 1.334 0 0 1.333 4.667 6 0 10.665 1.333 12 6 7.333 10.668 12 12 10.666 7.333 6 12 1.332 10.667 0z" fill="#36363D" fill-rule="evenodd"/></svg></a></div>
      <div class="modal__back"></div>
      <div class="modal__table">
        <div class="modal__cell">
          <div class="modal__content">
            <div class="container">
              <div class="modal__content__headline">
                <h2>Testimonials</h2>
              </div>
              <div class="modal__content__title"></div>
              <div class="modal__content__video"></div>
              <div class="modal__content__note">
                <p><span>Sound Tasty?</span> <a href="demo/index.html" class="common-button pill red">Request a Demo</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo base_url();?>assets/wp-content/themes/chownow4/js/script9922.js?ver=1543886077" async>
    </script>

    <link rel='stylesheet' id='lato-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato%3A300%2C400%2C700%2C900&amp;ver=5.1' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/assets/tosrus/js/jquery.tosrus.min.all3c94.js?ver=2.1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var rlArgs = {"script":"tosrus","selector":"lightbox","customEvents":"","activeGalleries":"1","effect":"slide","infinite":"1","keys":"0","autoplay":"1","pauseOnHover":"0","timeout":"4000","pagination":"1","paginationType":"thumbnails","closeOnClick":"0","woocommerce_gallery":"0","ajaxurl":"https:\/\/get.chownow.com\/wp-admin\/admin-ajax.php","nonce":"104c998189"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-content/plugins/responsive-lightbox/js/front3c94.js?ver=2.1.0'></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/wp-includes/js/wp-embed.minc721.js?ver=5.1'></script>
  </body>


<!-- Mirrored from get.chownow.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2019 04:21:16 GMT -->
</html>

<script>
    if (window.location.hash == "#video") {

      $("div.modal.home").find("div.modal__content__video").html('<div><iframe src="https://fast.wistia.net/embed/iframe/gb6c2om8g9?videoFoam=true&autoPlay=true" title="Wistia video player" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen oallowfullscreen msallowfullscreen width="100%" height="100%"></iframe></div>');
      var myVideo = $f($("#vimeo")[0]);
      myVideo.addEvent("ready", function() {});

      $("div.modal.home").addClass("modal-open modal-visible");

      $("body").addClass("no-scroll");
    }
</script>