

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Restaurant Guide: How To Maximize Your Success On Instagram                            
                    </h1>

                    <span class="meta">
                      <strong class="date">June 3rd, 2018</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a> <a href="<?php echo site_url('UserController/socialMediaBlog') ?>" >Social Media</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Selena Slavenburg</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone wp-image-7884 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImg-6.png" alt="Instagram for restaurants" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">At well over 500 million active users and rolling out new features on the reg (business analytics, Instagram Stories, live video, and Start Order), <strong><a href="#">Instagram’s audience eclipses that of Twitter, Snapchat, and Pinterest</a></strong>.</span><span style="font-weight: 400;"> If you’ve been at a restaurant, event, or simply stepped foot outside recently, you’ve probably noticed the hunched posture and tell-tale scrolling motion of an Instagram user. I certainly fit the bill.</span></p>
<p><span style="font-weight: 400;">Why care? As a restaurant, you know connecting with customers and keeping your restaurant top-of-mind is an important key to your success. Instagram allows you to put your best food forward, interact with your customers in an authentic way and reach new people. And now that <strong><a href="#" target="_blank" rel="noopener">ChowNow enables restaurants to take online orders directly from their Instagram profile</a></strong>, this social platform is becoming a growing source of revenue. So whether you’ve tapped into Instagram already or need some instruction to get started, here are some tips to help maximize your success on today’s most powerful social media platform.</span></p>
<h2><b>Instagram Posting Basics for Restaurants</b></h2>
<p><b>1. Always post your best images.</b></p>
<p><span style="font-weight: 400;">Your goal is to get a customer’s attention. If you are posting food, make sure the photo is appetizing. Your restaurant interior? Inviting. A photo of your staff? Make me want to work there. Avoid blurry images, images that are too close up, or ones you simply don’t love. For tips on taking better photos, </span><strong><a href="#">here’s a handy guide</a></strong><span style="font-weight: 400;">.</span></p>
<p><b>2. Be consistent.</b></p>
<p><span style="font-weight: 400;">Your Instagram feed is a representation of your brand. When a potential customer is deciding whether or not to follow you or interact with your photos, they are going to base it off of looks. Establish a theme you can maintain, such as a general color scheme, editing technique, or photographic style. Make it even easier with the help of an app like </span><strong><a href="#">Mosaico</a>, </strong><span style="font-weight: 400;">which allow you to visually plan out upcoming posts.</span></p>
<p><b>3. Post often.</b></p>
<p><span style="font-weight: 400;">The more you post, the more likely people are to see your content, and therefore, your restaurant. As a rule of thumb, I aim for one post a day. You can always post more or less often than that, but avoid posting photos too close together (space out photos by at least 4 hours). It’s okay to test out posting more or less often to find your sweet spot.</span></p>
<h2><b>Increasing Your Restaurant’s Instagram Following</b></h2>
<p><b>1. Always use hashtags.</b></p>
<p><span style="font-weight: 400;">This is key for potential new customers to find your restaurant. To determine the best hashtags to use, think of keywords that describe your photo. For instance, if you’ve photographed a burger, search “burger” in Instagram’s hashtag section and use those results as starting point. For instance: when I search #burger, it gives me #bestburgers, which gives me related hashtags such as #burgertime and #burgerlove. Instagram caps you off at 30 hashtags, so maximize the effectiveness of the hashtags you use by choosing ones which relate to your location or cuisine type. You can include hashtags in your caption, or post them separately as a comment below your caption (this is visually cleaner).</span></p>
<p><img class="aligncenter wp-image-7885 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/IG_1.png" alt="food hashtags" width="1000" height="474" /></p>
<p><b>2. Interact with people.</b></p>
<p><span style="font-weight: 400;">It’s important to establish a relationship with your followers. I recommend responding to every comment you<img class="alignright wp-image-7886" src="<?php echo base_url();?>assets/wp-content/uploads/Planoly_full.png" alt="scheduling instagram photos" width="221" height="392" /> receive on your posts, and at the very least, “liking” the comment. Your customers will be incentivized to interact with you more, and that engagement increases the chance that your post stays closer the top of people’s feed, or makes the Popular Page of Instagram.2</span></p>
<p><b>3. Post at strategic times.</b></p>
<p><span style="font-weight: 400;">Having a business account on Instagram makes it easy to see what time of day your customers are seeing and interacting with your posts. Make a note to post during those times, and set reminders for yourself. Services like </span><strong><a href="#">Planoly</a></strong><span style="font-weight: 400;"> allow you to set up photos and times via your computer or phone, and will send you a push notification when your post should go up.</span></p>
<h2><b>Taking Your Restaurant’s Insta-Game Up A Notch</b></h2>
<p><b>1. Put a Start Order button on your profile.</b></p>
<p>ChowNow recently unveiled its newest ordering channel: Instagram. ChowNow’s integration with Instagram gives your followers the ability to place a ChowNow order directly from your restaurant’s Instagram profile. Now, you can take your Instagram followers from scrolling to ordering, with the tap of a button. If you&#8217;re a ChowNow client, make sure to<strong><a href="#" target="_blank" rel="noopener"> reach out to your Restaurant Success Manager</a></strong>, who can help you get this set up in minutes. If you&#8217;re not a ChowNow client and you&#8217;re looking to turn your restaurant&#8217;s Instagram (and website, and Facebook profile) into a revenue stream, <strong><a href="#" target="_blank" rel="noopener">request a ChowNow demo</a></strong> from one of our experts.</p>
<p><b>2. Run Instagram Ads.</b></p>
<p><span style="font-weight: 400;">Instagram makes it easy by allowing you to target locals and set up an ad straight from your phone. Pick an appetizing food image, brainstorm a simple and eye-catching caption with your staff, and get ready to advertise!</span></p>
<p><b>3. Introduce contests or campaigns.</b></p>
<p><span style="font-weight: 400;">Take your brand to the next level by running promotions or campaigns that customers will want to interact with. We recommend giveaways, posts that encourage engagement (such as asking a question), or re-posting customer’s content with a shout-out to them. Check out the examples below for ideas.</span></p>
<p><img class="aligncenter wp-image-7888" src="<?php echo base_url();?>assets/wp-content/uploads/IG_2.png" alt="restaurant instagram contest" width="1000" height="638" /></p>
<p><b>4. Fit Instagram into your in-store strategy.</b></p>
<p><span style="font-weight: 400;">Include your Instagram handle on in-store receipts, takeout menus, or flyers. If you can get staff to spread the word, even better. I once had a server at the register tell me if I followed them on Instagram I’d get a 20% discount. I bought everything I was holding, and it’s now 4 years later and I still see and like their posts on a weekly basis. Don’t underestimate your employees!</span></p>
<hr />
<p style="text-align: justify;"><span style="font-weight: 400;">Want more social media tips for your restaurant? If you’re a ChowNow client, </span><strong><a href="#">reach out</a></strong><span style="font-weight: 400;"> anytime and my team and I are here to chat! If you’re not taking online orders through ChowNow yet, </span><strong><a href="#">get started</a></strong><span style="font-weight: 400;"> with a free demo today!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Selena Slavenburg</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Selena Slavenburg is a member of the ChowNow team and on a constant quest — traveling near and far — to find her new favorite restaurant. She grew up in Northern California but is now location-independent, exploring the world and adding her best food finds to her travel blog @finduslost.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="../wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Selena Slavenburg <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">How to Create a Secret Menu in 5 Easy Steps</a><span> - June 6, 2018</span>				</li>				<li>					<a href="#">Restaurant Guide: How To Maximize Your Success On Instagram</a><span> - June 3, 2018</span>				</li>				<li>					<a href="restaurant-email-marketing-tips.html">Restaurant Guide: Email Marketing Made Easy</a><span> - April 1, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Finstagram-guide-for-restaurants&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

