

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    How to Create a Secret Menu in 5 Easy Steps                            
                    </h1>

                    <span class="meta">
                      <strong class="date">June 6th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Selena Slavenburg</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="aligncenter size-full wp-image-8421" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImage-3-1.png" alt="" width="1000" height="474" /></p>
<p>There’s something about the thrill of “secret menus” at restaurants that people just can’t seem to resist. From In-N-Out’s animal-style everything, to <strong><a href="#" target="_blank" rel="noopener">Starbucks’ Fruity Pebbles Frappuccino</a> </strong>— secret menus create an exclusive experience that excites customers and gets them coming back.</p>
<p><span style="font-weight: 400;">But fast food chains and coffee shops aren’t the only concepts that can profit off of the secret menu trend. One of the most common questions we hear when working with restaurants is: “What marketing strategies can I implement without spending a lot of money?”</span></p>
<p><span style="font-weight: 400;">Generating buzz organically and at a low cost can be difficult. Creating a “secret menu” for your restaurant is easy to implement, and can be done within a day if you focus your efforts online.</span></p>
<p><span style="font-weight: 400;">Read on for why creating a “secret menu” is an effective way to boost orders and improve customer loyalty.</span></p>
<h2><b>Why implement a secret menu?</b></h2>
<h3><b>It’s exclusive. </b></h3>
<p><img class="aligncenter size-full wp-image-8420" src="<?php echo base_url();?>assets/wp-content/uploads/Body-Imgs2-2.png" alt="" width="1000" height="537" /></p>
<p><span style="font-weight: 400;">Customers want to feel special. In an increasingly technical world where face-to-face interaction becomes rarer by the day, customers still want to feel like they are a “regular.” Why? Regulars often get perks! </span></p>
<p><span style="font-weight: 400;">If your customers are using your branded online ordering, they are already loyal to you and this channel offers an easy way to reward them and provide an “exclusive” touch. Even better if that reward is exclusively available on your restaurant’s app and website!</span></p>
<h3><b>It creates buzz. </b></h3>
<h4><span style="font-weight: 400;">Word-of-mouth is powerful, and social proof and peer recommendations are key to the growth of any business. Would you be more inclined to check out a restaurant if their site claimed they had the best burgers in town, or if a friend you trust said their secret menu has the best burger in town? 92% of consumers say &#8212; the friend [</span><strong><a href="#" target="_blank" rel="noopener">source</a></strong><span style="font-weight: 400;">]. Give ‘em something to talk about! </span></h4>
<h3><b>It’s free!</b></h3>
<p><span style="font-weight: 400;">If budget is an issue, this is one of the easiest and most cost-effective ways to implement new marketing. Instead of printing new menus or advertising in a print ad, this new menu is best promoted in a low key way. You can post about it on social media, have staff let customers know about it in the restaurant, even add it to your online menu without saying a word! Use it as an opportunity to offer something new and exciting, and the menu items will sell themselves. </span></p>
<h2><b>How to set up a secret menu.</b></h2>
<h3><b>Determine your items.</b></h3>
<p><span style="font-weight: 400;">It’s important to pick items that are adventurous but still stay true to your brand. You can approach this in a few different ways: choose items that you’ve tested as a “special” in the past and have sold well, capitalize on a new food trend, or create something new and totally unique. Avocado toast selling out at a neighboring restaurant? Promote “The Ultimate Avocado Toast” on your secret menu.</span></p>
<h3><b>Have fun with names and descriptions. </b></h3>
<p><span style="font-weight: 400;">Don’t just throw a handful of items up that sound like they could be on your day-to-day menu. This is an opportunity to be creative and mysterious, and to encourage customers to try something different. Here are some fun examples to get your creative juices flowing:</span></p>
<p><img class="aligncenter wp-image-8427 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2017-07-06-at-4.35.01-PM.png" alt="" width="1014" height="636" /></p>
<h3><b>Loop in your staff. </b></h3>
<p><span style="font-weight: 400;">It’s a given that your staff should know about the new items, but you can also take it one step further and ask them to engage customers who have ordered them. This can be as simple as having them ask the customer how they enjoyed the dish, or organizing them to high-five or congratulate a customer for ordering off the secret menu. It’s your show, after all&#8230;</span></p>
<h3><b>Get it online.</b></h3>
<p><span style="font-weight: 400;">The most important, and easiest part of this promotion: get the menu online! You can easily create a new menu section and add in your items — if you’re a ChowNow client, it’s possible to do this yourself by signing into your ChowNow Dashboard. Or, you can just email our support team <strong>(</strong></span><strong><a href="mailto:support@chownow.com" target="_blank" rel="noopener">support@chownow.com</a></strong><span style="font-weight: 400;"><strong>)</strong> with the menu name and items. Once it’s up, just wait for the orders to start flowing in.</span></p>
<p><img class="size-full wp-image-8419 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/Body-Imgs-2.png" alt="" width="1000" height="445" /></p>
<h3><b>Keep it going.</b></h3>
<p><span style="font-weight: 400;">There’s no time frame for this promotion, so you can keep it running as short or as long as you’d like. I recommend trying out a new tactic to promote your secret menu every few weeks, and allowing time for word to spread. Mention it on social media, bring it up in conversations, or even write a line about it into your to-go menus! The more you promote its presence on your online ordering, the more of a response you’ll see as a result.</span></p>
<hr />
<p>If you’re a ChowNow restaurant client and want some feedback on your secret menu build, <a href="#"><b>schedule a call</b></a> — we’re happy to help. If you don’t already have online ordering at your restaurant, now’s a great time to get started. <a href="#"><b>Get a free ChowNow demo</b></a> from one of our experts to get started today!</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Selena Slavenburg</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Selena Slavenburg is a member of the ChowNow team and on a constant quest — traveling near and far — to find her new favorite restaurant. She grew up in Northern California but is now location-independent, exploring the world and adding her best food finds to her travel blog @finduslost.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Selena Slavenburg <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">How to Create a Secret Menu in 5 Easy Steps</a><span> - June 6, 2018</span>				</li>				<li>					<a href="#">Restaurant Guide: How To Maximize Your Success On Instagram</a><span> - June 3, 2018</span>				</li>				<li>					<a href="#">Restaurant Guide: Email Marketing Made Easy</a><span> - April 1, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-to-create-a-secret-menu&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

