

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    How Marketplaces Are Eating Away at Your Restaurant&#8217;s Bottom Line                            
                    </h1>

                    <span class="meta">
                      <strong class="date">February 19th, 2019</strong>
                                                <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a> <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a>                     </span>

                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone size-full wp-image-9101" src="<?php echo base_url();?>assets/wp-content/uploads/Header-2-1.jpg" alt="Third-Party Online Ordering Marketplace Commissions" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">On their surface, third-party marketplace online ordering services like Postmates, Grubhub, and Uber Eats may seem like a smart choice for your restaurant. After all, </span><a href="<?php echo site_url('UserController/whyYouNeddOnlineOrder');?>" target="_blank" rel="noopener noreferrer"><span style="font-weight: 400;">it pays to have online ordering</span></a><span style="font-weight: 400;">, and these services can offer you a large audience of new customers. If you currently work with one of these delivery middlemen, you may very well have a steady stream of orders lighting up your tablet, announcing yet another customer hungry for your food. </span></p>
<p><span style="font-weight: 400;">The volume of orders, though, masks a sobering truth: these third-party marketplaces are eroding your margins and undermining your business.</span></p>
<h2><b>How Much Are They Taking?</b></h2>
<p><span style="font-weight: 400;">Third-party marketplace online ordering platforms charge commissions on each and every order, which can range between 15% to 40%. </span></p>
<p><span style="font-weight: 400;">Grubhub, for example, might charge you a base of 20% per order just to appear on their site and accept online orders. If your restaurant is in a competitive area and you’re eager for marketing help, though, you’ll want to opt for a sponsored listing, which would place your restaurant near the top of search results. That, though, might cost 30% of each order instead. Delivery is another 10% of your order. Even if you have your own delivery person and charge your customers a delivery fee, Grubhub will take 10% of that too. All in all, you could be paying out 40% of what you take in for each order.</span></p>
<h2><b>It Adds Up</b></h2>
<p><span style="font-weight: 400;">Perhaps you’re not paying anything close to 40% of each order—maybe your third-party marketplace charges you 15%, for now at least. Even then, these commissions can put a large dent in your profits.</span></p>
<p><span style="font-weight: 400;">Say your restaurant operates at a 10% profit margin. On a $50 ticket, you’d actually keep $5 in profit after accounting for your food, supplies, labor, rent, and all the rest. Even if you’re giving just 15% of each ticket to your marketplace, that equates to $7.50, which leaves you with a loss of $2.50. </span></p>
<p><span style="font-weight: 400;">That loss wouldn’t be significant if it only applied to a customer’s first order. After all, you’re using third-party marketplaces to reach a new audience, right? However, most third-party marketplaces charge the same take rates whether it’s a diner’s first or fifteenth order. That $2.50 loss gets multiplied, and you end up paying these marketplaces a massive sum of money to sell your food.</span></p>
<h2><b>The Tide Is Turning</b></h2>
<p><span style="font-weight: 400;">When orders are flowing in, it can be challenging to accurately assess your losses. However, some restaurateurs are waking up.</span></p>
<p><a href="#" target="_blank" rel="noopener noreferrer"><i><span style="font-weight: 400;">The New Yorker</span></i></a> <span style="font-weight: 400;">reported on this problem, interviewing a independent restaurant owner who states, “We know for a fact that as delivery increases, our profitability decreases.” Third-party marketplace ordering platforms, she continues, are “a far bigger problem than a lot of operators realize.” Another restaurateur admits, “Sometimes it seems like we’re making food to make Seamless profitable.”</span></p>
<p><span style="font-weight: 400;">Media outlets all over </span><span style="font-weight: 400;">highlight similar stories about the problem with third-party marketplaces harming restaurants&#8217; profits. Here are just a few examples:</span></p>
<ul>
<li><em>Forbes</em>: <a href="#">Why Uber Eats Will Eat You into Bankruptcy</a></li>
<li><em>CNN Business</em>: <a href="#">Why Uber Eats and Grubhub Partnerships Are Risky for Restaurants</a></li>
<li><em>The Wall Street Journal</em>: <a href="#">Soggy Fries vs. Sagging Profits: Restaurants Face Delivery Dilemma</a></li>
<li><em>Gizmodo</em>: <a href="#">Stop Using Seamless</a></li>
<li><em>Democrat &amp; Chronicle</em>: <a href="#">Food Delivery Apps Are Impacting Your Favorite Restaurants, Taking a Bite Out of Profits</a></li>
<li><em>Eater</em>: <a href="#">Why Some Restaurants Are Cutting Ties With Mobile Ordering Apps</a></li>
<li><em>Fox Business</em>: <a href="#">Ex-Food Network Star Says Delivery Apps Killing Restaurants</a></li>
<li><em>Boston Globe</em>: <a href="#">You May Love High-End Restaurant Delivery—But the Chefs Kind of Hate It</a></li>
<li><em>Times-Union</em>: <a href="#">Not So Fast: Some Restaurants Resist Third-Party Delivery</a></li>
<li><em>Tribeca Citizen</em>: <a href="#">Why Restaurants Hate Grubhub Seamless</a></li>
<li><em>News.com.au</em> [Australia]<em>:</em> <a href="#">Cafe Bans Uber Eats, Calling Food Delivery Platform &#8216;Incredibly Exploitative&#8217;</a></li>
<li><em>TVO </em>[Canada]: <a href="#">How Meal-Delivery Apps Are Hurting Your Favorite Restaurants</a></li>
<li><em>SFist</em>: <a href="#">How Food Delivery Services Are Taking a Bite Out of Restaurant Profits</a></li>
<li><em>SBS News </em>[Australia]: <a href="#">Are Food Delivery Services Worth the Cost for Small Businesses?</a></li>
<li><em>Food &amp; Wine</em>: <a href="#">Uber Eats Is Going to Take a Huge Cut From Restaurants for Delivering Food</a></li>
<li><em>San Francisco Chronicle</em>: <a href="#">Online Order, Delivery Services Taking Bite Out of S.F. Restaurant Profits</a></li>
<li><em>Miami New Times</em>: <a href="#">Delivery Apps Put Miami Restaurants in a Bind</a></li>
</ul>
<p><span style="font-weight: 400;">These articles paint a vivid picture: It’s time for restauranteurs to fight back.   </span></p>
<p><span style="font-weight: 400;">At ChowNow, we believe that takeout shouldn&#8217;t take out the neighborhood. That&#8217;s why we put online ordering back in restaurants&#8217; hands with flat monthly fees and valuable marketing and data provided at no extra cost. Learn more about escaping from unfair third-party marketplace fees by <a href="#gate-c789ef96-e21e-4d17-a443-23e40b0530c9">getting in touch with the ChowNow team</a>.</span></p>

                         <div class="abh_box abh_box_down abh_box_"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Eliza Fisher"></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Eliza Fisher</a></h3><div class="abh_job" ></div><div class="description note abh_description" ></div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Eliza Fisher"></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Eliza Fisher <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>             <li>                    <a href="#">How Marketplaces Are Eating Away at Your Restaurant&#8217;s Bottom Line</a><span> - February 19, 2019</span>               </li>               <li>                    <a href="#">Tutorial: How to Enroll Your Restaurant in ChowNow&#8217;s Apple Developer Program (Canadian Version)</a><span> - January 4, 2019</span>               </li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-marketplaces-are-eating-away-at-your-restaurants-bottom-line%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><b class="common-button pill disabled slim">Previous</b></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

