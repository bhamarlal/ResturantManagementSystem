

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    [Case Study] How Two Boots Doubled Revenue and Scaled Brand Online                            
                    </h1>

                    <span class="meta">
                      <strong class="date">April 27th, 2016</strong>
                                                                    </span>

                    
                    
                    
                    
                    <div class="content">
                        <p>Two Boots owner Leon Hartman harnessed the power of the extensive customer data he gathered through ChowNow&#8217;s online ordering platform to present the restaurant&#8217;s impressive growth to outside investors. With ChowNow as an essential part of it&#8217;s launch playbook, Two Boots has grown to 18 locations &#8211; and counting.</p>
<p>Leon highlights three features of ChowNow that have helped scale his brand and transform the way Two Boots engages with their loyal customers.</p>
<div class="page" title="Page 1">
<div class="section">
<div class="layoutArea">
<blockquote>
<div class="column">
<ul>
<li><strong>Smooth onboarding process </strong>&#8211; ChowNow was easy to to set up and got us taking orders online right away.</li>
<li><strong>Extensive customer data</strong> &#8211; Ownership over customer data means that we can continue to market the Two Boots brand.</li>
<li><b>Measurable success </b>&#8211; Charting restaurant growth and online ordering sales success has never been easier.</li>
</ul>
</div>
</blockquote>
</div>
</div>
</div>
<hr />
<p>Download the full case study <a href="<?php echo base_url();?>assets/wp-content/uploads/Two-Boots-Case-Study.pdf">here</a> or check it out below.</p>
<p><div class="image">
  <div class="source"><img src="<?php echo base_url();?>assets/wp-content/uploads/Two-Boots-Case-Study.jpg" alt="" /></div>
</div><div class="image">
  <div class="source"><img src="<?php echo base_url();?>assets/wp-content/uploads/Two-Boots-Case-Study-p2.jpg" alt="" /></div>
</div></p>
<p>&nbsp;</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Hayley Thayer</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Hayley Thayer is a member of the ChowNow Marketing team. In her free time, you’ll find Hayley eating salmon sashimi, ruminating on culture and politics, and obsessing over the latest men’s haircut and clothing trends.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Hayley Thayer <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a><span> - May 4, 2018</span>				</li>				<li>					<a href="#">Mouth-Watering Menus: 4 Ways to Write Enticing Menu Descriptions</a><span> - April 2, 2018</span>				</li>				<li>					<a href="#">Why You Need to Secure Your Restaurant&#8217;s Website with SSL Right Now</a><span> - March 3, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fonline-ordering-case-study-Two-Boots&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

