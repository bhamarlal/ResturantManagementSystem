

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Celebrating Day of the Dead at L.A. Restaurant Toca Madera                            
                    </h1>

                    <span class="meta">
                      <strong class="date">October 6th, 2017</strong>
                                                <a href="<?php echo site_url('UserController/clientSpotLight') ?>" >Client Spotlight</a>                     </span>

                    
                    
                    
                    
                    <div class="content">
                        <p><img class="aligncenter wp-image-8478 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_4.jpg" alt="" width="1280" height="720" /></p>
<p><span style="font-weight: 400;">Day of the Dead, or Dia de los Muertos, is a three-day long celebration of life and death where families commemorate their deceased loved ones. The tradition originates in Mexico, but the holiday is also observed in many Mexican-American communities — like Los Angeles. </span></p>
<p><span style="font-weight: 400;">Day of the Dead  recognizes death as a natural part of the human experience, a continuum with birth, childhood, and growing up to become a contributing member of the community. It is believed that on Day of the Dead, the dead are awakened from their eternal sleep to share celebrations with their loved ones.</span></p>
<h2><strong>When is it celebrated?</strong></h2>
<p><span style="font-weight: 400;">The three-day long celebration begins on October 31st and ends on November 2nd. </span></p>
<h2><strong>How is it celebrated?</strong></h2>
<p><span style="font-weight: 400;">While Halloween is commonly celebrated by dressing up as pop culture icons, going through haunted mazes, and carving pumpkins—people celebrate Day of the Dead by bringing offerings for their loved ones, participating in community festivals, and enjoying their favorite foods. </span></p>
<p><span style="font-weight: 400;">Gather a group of friends and celebrate the Day of the Dead with some traditional dishes. The most popular food is Pan de Muerto, “bread of the dead”, which is a sweet, brioche-like bread&#8211;usually shaped like a skull. Other popular foods include tamales (masa wrapped around fillings and steamed in a corn husk) and mole (a complex, flavorful sauce made with ground chiles, chocolate and numerous other ingredients).</span></p>
<h2><strong>Where can you celebrate?</strong></h2>
<p><span style="font-weight: 400;">There’s no shortage of places to celebrate Day of the Dead in Los Angeles. Events take place across the city, from L.A.’s oldest district to museums to a cemetery of Hollywood stars. Many LA restaurants and bars also offer Day of the Dead&#8211;themed food and drinks. But not many restaurants embrace Day of the Dead quite like <a href="http://www.tocamadera.com/" target="_blank" rel="noopener"><strong>Toca Madera</strong></a>.</span></p>
<p><img class="aligncenter wp-image-8489 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_3-1.jpg" alt="" width="1280" height="720" /></p>
<h2><strong>Toca Madera</strong></h2>
<p><strong><span style="font-weight: 400;">The name translates to “knock on wood” because the wood they sourced (imported from a Oaxacan jungle) is thought to bring fortune and good luck. The interior architecture was designed with Day of the Dead in mind. Co-founder, Tosh Berman, envisioned an alluring and inviting space that showcased elements of the earth. The organic space features a color palette of gold and flame-inspired yellow. The earthy elements range from the custom-reclaimed ceiling planks, quartz stone, walnut-wood fixtures, and numerous fire details.</span></strong></p>

		<style type='text/css'>
			#gallery-3 {
				margin: auto;
			}
			#gallery-3 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 50%;
			}
			#gallery-3 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-3 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-3' class='gallery galleryid-8479 gallery-columns-2 gallery-size-full'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_5-1.jpg' title="Toca Madera welcomes customers with various live performers" data-rl_title="Toca Madera welcomes customers with various live performers" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-3"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_5-1.jpg" class="attachment-full size-full" alt="toca_madera_live_performers" aria-describedby="gallery-3-8491" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-3-8491'>
				Toca Madera welcomes customers with various live performers
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_6-2.jpg' title="From fire breathers, to flaming drinks, there is bound to be something that catches your eye" data-rl_title="From fire breathers, to flaming drinks, there is bound to be something that catches your eye" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-3"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_6-2.jpg" class="attachment-full size-full" alt="" aria-describedby="gallery-3-8490" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-3-8490'>
				From fire breathers, to flaming drinks, there is bound to be something that catches your eye
				</dd></dl><br style="clear: both" />
		</div>

<p><span style="font-weight: 400;">Customers can expect an intimate and captivating atmosphere: from the various photographs of Calavera Catrina dolls, to the amber glow from Edison bulb light fixtures, to the 100-foot long quartz bar, to the unique grid of skull sculptures. Toca Madera is full of eye-catching decor pieces, but the back wall of the dining room reveal individually lit skull sculptures installed in raw steel and wooden boxes. </span></p>
<h3><strong>Flaming wall and flaming drinks</strong></h3>
<p><span style="font-weight: 400;">Toca Madera’s menu highlights local farm-sourced ingredients, sustainable seafood with an emphasis on organic ingredients. If you want elevate your dining experience with a dose of theatrics, make sure to try the </span><i><span style="font-weight: 400;">A La Roca—</span></i><span style="font-weight: 400;">which is American Wagyu beef served on a sizzling hot stone and seared at your table. It comes with a plethora of sauces and spices (jus de vino mojo, diablo salsa, chipotle crema, and habanero salt) to add to the interactive element. Pair your dinner with their popular flaming cocktail, </span><i><span style="font-weight: 400;">Ghost Rider</span></i><span style="font-weight: 400;">—which comes with a flaming 151-soaked sugar skull candy garnish.</span></p>

		<style type='text/css'>
			#gallery-4 {
				margin: auto;
			}
			#gallery-4 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 50%;
			}
			#gallery-4 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-4 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-4' class='gallery galleryid-8479 gallery-columns-2 gallery-size-full'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_1-1.jpg' title="The Shrimp Picante is served with a crispy black bean dumpling" data-rl_title="The Shrimp Picante is served with a crispy black bean dumpling" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_1-1.jpg" class="attachment-full size-full" alt="shrimp_picante" aria-describedby="gallery-4-8488" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8488'>
				The Shrimp Picante is served with a crispy black bean dumpling
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_2-1.jpg' title="The Enchiladas De Mole is filled with organic free-range chicken tinga and queso fresco" data-rl_title="The Enchiladas De Mole is filled with organic free-range chicken tinga and queso fresco" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/TocaMadera_2-1.jpg" class="attachment-full size-full" alt="enchiladas_de_mole" aria-describedby="gallery-4-8487" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8487'>
				The Enchiladas De Mole is filled with organic free-range chicken tinga and queso fresco
				</dd></dl><br style="clear: both" />
		</div>

<hr />
<p><span style="font-weight: 400;">If you’re a restaurant owner, you can get in the spirit too by incorporating your own Day of the Dead decorations. Some examples of festive decor include bouquets of marigolds (a traditional flower displayed during this holiday), vibrant colored paper picado (tissue paper cut into different patterns), or Calavera Catrina doll figurines.  </span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Kristy Mai"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/kristy.jpg" class="photo" width="80" alt="Kristy Mai" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Kristy Mai</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Kristy is a member of the ChowNow Discover team. In her free time, you can find Kristy drinking copious amounts of nitro cold brew, trying out a new spin studio or obsessing over the latest food trends. She is a Southern California native and grew up working at her parent’s Chinese restaurant in San Diego.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Kristy Mai"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/kristy.jpg" class="photo" width="80" alt="Kristy Mai" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Kristy Mai <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">The Ultimate Guide: 7 Tips to Kick Your Snapchat Strategy Up a Notch</a><span> - October 30, 2017</span>				</li>				<li>					<a href="#">Celebrating Day of the Dead at L.A. Restaurant Toca Madera</a><span> - October 6, 2017</span>				</li>				<li>					<a href="#">The Essential Snapchat Starter Kit for Restaurants</a><span> - August 31, 2017</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fcelebrating-day-of-the-dead-at-toca-madera%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

