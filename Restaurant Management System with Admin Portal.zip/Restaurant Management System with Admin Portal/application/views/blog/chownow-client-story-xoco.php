

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    ChowNow Client Story: XOCO                            
                    </h1>

                    <span class="meta">
                      <strong class="date">December 30th, 2014</strong>
                                                                    </span>

                                            <span class="meta2"><span class="author">Written by Emily Neudorf</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><iframe src="https://player.vimeo.com/video/114934362" width="500" height="281" frameborder="0" title="XOCO Client Story - ChowNow Testimonials and Reviews" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></p>
<p>&nbsp;</p>
<p>Arthur Mullen, Manager at Rick Bayless’ Mexican street food restaurant <a href="#">XOCO</a>, uses ChowNow to process high to-go order volumes at his bustling downtown Chicago location.</p>
<p>And you could say he’s a fan of his online ordering solution. “Asking my favorite thing about ChowNow is really a hard question for me to answer. It’s almost as if you said, ‘what’s your favorite part of Diet Coke?’ I like every part of it.”</p>
<p><strong><strong> </strong></strong></p>
<p><strong>Arthur pinpoints three ChowNow features that have helped streamline to-go operations and strengthen customer relationships at XOCO:</strong></p>
<p><strong><strong> </strong></strong></p>
<ol>
<li><b>Little to no training required.</b> The ChowNow software is iPad-based and highly intuitive, unlike some restaurant operating solutions that Arthur and his staff have had to learn in the past.</li>
<li><b>Customize menus on the fly. </b>As XOCO’s menu changes seasonally, Arthur can log into the ChowNow Dashboard and change their offerings in real time.</li>
<li><b>Track customer trends.</b> With ChowNow, Arthur’s team has visibility into their top to-go customers, so they can ensure XOCO regulars feel like a VIP at every visit.</li>
</ol>
<p><strong><br />
</strong><em>Be sure to watch the rest for more insights—and mouthwatering shots of XOCO’s signature dishes.</em></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="https://get.chownow.com/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Emily Neudorf</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Emily Neudorf is on the Marketing Team at ChowNow and loves architecture, music and of course, discovering great restaurants. She considers Chicago and Los Angeles two of the world’s finest food cities — though the quest is far from over.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="https://get.chownow.com/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Emily Neudorf <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Introducing Instagram Ordering with ChowNow</a><span> - May 8, 2018</span>				</li>				<li>					<a href="#">Why Your Restaurant Needs to Take Advantage of Customer Data</a><span> - May 2, 2018</span>				</li>				<li>					<a href="#">4 New Year’s Resolutions Every Restaurant Should Make, and How to Nail Them</a><span> - January 2, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fchownow-client-story-xoco&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

