

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    5 Fresh Marketing Promotions for Your Restaurant to Try This Spring                            
                    </h1>

                    <span class="meta">
                      <strong class="date">March 2nd, 2018</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/socialMediaBlog') ?>" >Social Media</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Selena Slavenburg</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone wp-image-7944 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImg-3-1.png" alt="restaurant marketing" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">Springtime means the promise of something new. New beginnings, new growth, new energy — and if you can be productive during the Spring months, that feeling of success can carry you through the rest of the year.</span></p>
<p><span style="font-weight: 400;">Unfortunately I’m no motivational speaker, so let’s cut to the chase here: if I could choose your new mantra for spring (both professionally and personally) it would be</span> <b><i>try a fresh marketing approach to achieve success</i></b><span style="font-weight: 400;">.</span></p>
<p><span style="font-weight: 400;">So, we’ve sourced our latest promotional ideas and are excited to share them with you here, as inspiration to grow your bottom line, delight your customers, and launch you into spring (and beyond) successfully. How’s that for productive?</span></p>
<h1>5 Fresh Spring Marketing Promotions for Your Restaurant</h1>
<h2><strong>1. The Big Reveal: Offer a First Look at Your New Menu/Items</strong></h2>
<p><span style="font-weight: 400;">Whether it’s time for a full facelift, a couple seasonal specials, or just some basic copyedits </span><strong><a href="#" target="_blank" rel="noopener">to increase ticket sizes</a></strong><span style="font-weight: 400;">, don’t forget to promote your new offerings to your customers.</span></p>
<p><span style="font-weight: 400;">Generate some excitement around your updated menu by offering a “first look” special of 10% off online for one week only, or printing flyers highlighting your new menu items. If you’re not sure where to begin, </span><strong><a href="#" target="_blank" rel="noopener">reach out</a></strong><span style="font-weight: 400;"> and we’d be happy to share some strategic tips to give your menu a quick facelift.</span></p>
<h2><strong>2. Keep in Touch: Boost Loyalty with Automated Email Marketing</strong></h2>
<p><span style="font-weight: 400;">Want to boost customer loyalty, but don’t have the time or budget for a big campaign? Take a tip from our restaurant partners and encourage customers to enroll in an automated email loyalty program. Simply place a fishbowl at the host stand to collect email addresses. Even better, with ChowNow each time a customer places an order you’ll get their email address. If you’re a ChowNow client, </span><strong><a href="#" target="_blank" rel="noopener">contact us</a></strong><span style="font-weight: 400;"> to activate our monthly email marketing program at any time and we’ll handle the legwork of emails every month, and send you the results!</span></p>
<p><img class="alignnone size-full wp-image-8620" src="<?php echo base_url();?>assets/wp-content/uploads/Body-Imgs_2-1.png" alt="Restaurant Email Marketing" width="1000" height="445" /></p>
<h2><strong>3. Everyone’s a Winner: Add a Surprise Item to One Order a Day</strong></h2>
<p>Give your customers something to talk about. Rather than running a social media contest and selecting one winner, highlight a winner every day. Simply choose one low cost food item (think a slice of pizza, a piece of cake, a fountain drink, it can vary each day) and slip it into a customer’s to-go order. The more people order, the more they have a chance to be surprised with something different, and they’ll be telling all their friends to get in on the fun too! <strong><a href="#" target="_blank" rel="noopener">For tips on running a successful social media contest, click here</a></strong>.</p>
<h2><strong>4. #Winning: Hashtag Your Food Photo, Get Rewarded</strong></h2>
<p><img class="alignnone size-full wp-image-7945" src="<?php echo base_url();?>assets/wp-content/uploads/IG_3.png" alt="Instagram for restaurants" width="1000" height="638" /></p>
<p><span style="font-weight: 400;">This one is perfect for social media. Choose a hashtag that corresponds to your restaurant, such as #springathudsons, and invite customers to take photos of your food and use that hashtag. At the end of each week, you’ll pick a lucky winner whose photo you will feature online, and they will also receive a $25 credit to your restaurant. It’s the perfect way to generate buzz, and you’ll benefit from the user-generated content as well! Best of all, you can issue online credits through ChowNow easily for this promotion by emailing support@chownow.com with the customer’s name and amount, and we’ll handle the rest.</span></p>
<h2><strong>5. Insta-Incentive: Flash Promo for Your Followers</strong></h2>
<p><span style="font-weight: 400;">If you haven’t invested anything into Instagram yet, spring is the perfect time to start. Running a flash promotion with an enticing incentive on social media is a great way to reach your customers and their friends. Try something like “Experience our new protein bowls for $7 this weekend only, usecode: INSTA for your discount”. Check out our </span><strong><a href="#" target="_blank" rel="noopener">Instagram Guide</a></strong><span style="font-weight: 400;"> for quick tips and advice on how other restaurants are cashing in on this growing platform.</span></p>
<p><span style="font-weight: 400;">Want more spring marketing inspiration? If you’re a ChowNow client, </span><strong><a href="#" target="_blank" rel="noopener">reach out</a></strong><span style="font-weight: 400;"> anytime and my team and I are here to chat! If you’re not taking online orders through ChowNow yet, </span><strong><a href="#" target="_blank" rel="noopener">get started</a></strong><span style="font-weight: 400;"> with a free demo today!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Selena Slavenburg</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Selena Slavenburg is a member of the ChowNow team and on a constant quest — traveling near and far — to find her new favorite restaurant. She grew up in Northern California but is now location-independent, exploring the world and adding her best food finds to her travel blog @finduslost.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Selena Slavenburg"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/selena.jpg" class="photo" width="80" alt="Selena Slavenburg" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Selena Slavenburg <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="how-to-create-a-secret-menu.html">How to Create a Secret Menu in 5 Easy Steps</a><span> - June 6, 2018</span>				</li>				<li>					<a href="#">Restaurant Guide: How To Maximize Your Success On Instagram</a><span> - June 3, 2018</span>				</li>				<li>					<a href="#">Restaurant Guide: Email Marketing Made Easy</a><span> - April 1, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fspring-marketing-promotions-for-your-restaurant&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

