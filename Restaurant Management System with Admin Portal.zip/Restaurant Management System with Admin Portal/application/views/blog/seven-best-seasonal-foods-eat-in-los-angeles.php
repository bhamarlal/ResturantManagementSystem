

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Seven In-Season Foods and Where to Eat Them in Los Angeles                            
                    </h1>

                    <span class="meta">
                      <strong class="date">August 7th, 2017</strong>
                                                <a href="<?php echo site_url('UserController/clientSpotLight') ?>" >Client Spotlight</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Erin Doll</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="size-full wp-image-8354 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImage-2-1.png" alt="Milo_and_Olive_ChowNow" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">Some argue that Los Angeles lacks seasons. Some say that’s not true… we just skip the crummy ones. However, there’s a special place in L.A. that’s </span><i><span style="font-weight: 400;">always</span></i><span style="font-weight: 400;"> seasonal — with shades changing from green to red to violet to yellow, ever-abiding by the calendar’s color wheel. Here, flavors mimic the earth’s annual orbit — with the sweetest flavors peaking in the summer, suddenly transitioning into crisp winter textures. Of course, I’m talking about L.A.’s renowned farmers markets.</span></p>
<p><span style="font-weight: 400;">Visit one of L.A.’s many farmers markets (we enjoy <strong><a href="http://www.santamonica.com/santa-monica-restaurants/santa-monica-farmers-market/" target="_blank" rel="noopener">Santa Monica’s</a></strong>, <strong><a href="http://studiocityfarmersmarket.com/" target="_blank" rel="noopener">Studio City’s</a></strong>, and <strong><a href="http://www.everythingbrentwood.com/brentwoodfarmersmarket.html" target="_blank" rel="noopener">Brentwood’s</a></strong>) and you’ll find stacks of rich green kale in October, colorful sweet berries in July, and deep purple plums through September. Farmers markets not only enrich communities and support local, they give residents the opportunity to learn more about the importance of eating seasonally.</span></p>
<p><span style="font-weight: 400;">Eating seasonally is good for the body, good for the environment, and good for the soul. This month, there is nothing better than a handful of ripe berries or the sweet taste of roasted garlic. August offers some of our favorite seasonal produce, and Los Angeles chefs take full advantage of this late summer flourish. Here are seven of our favorite summer bites and where you can chow down right now.</span></p>
<h1><b>Seven Seasonal Foods and Where to Eat Them in Los Angeles<br />
</b></h1>
<h2><b>1. Arugula</b></h2>

		<style type='text/css'>
			#gallery-8 {
				margin: auto;
			}
			#gallery-8 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-8 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-8 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-8' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/1_ArtsTable.jpg' title="Steak Salad at Art&#039;s Table" data-rl_title="Steak Salad at Art&#039;s Table" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-8"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/1_ArtsTable.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-8-8356" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-8-8356'>
				Steak Salad at Art&#8217;s Table
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong>Click the image above to enlarge</strong></h6>
<p><strong>WHERE TO EAT IT: Art’s Table</strong><br />
<strong> WHAT TO ORDER: Art’s Steak Salad</strong><br />
<strong> WHAT’S IN IT? Baby arugula, frisee, roasted tomato, shallot crisps, pecorino cheese, grilled hanger steak, balsamic gastrique, extra virgin olive oil</strong><br />
<strong> WEBSITE: <a href="http://artstablesm.com/">http://artstablesm.com/</a></strong><span style="font-weight: 400;"><br />
</span><span style="font-weight: 400;"><br />
This peppery green is packed full of health benefits, including antioxidants and a powerful detoxifying boost from natural enzymes. It’s also an excellent source of fiber, vitamins A, C (to boost the immune system), and K (for bone strength). But that’s not all. It’s also rich in folate, calcium, iron, magnesium, phosphorus, potassium and manganese.</span></p>
<h2><b>2. Tomatoes</b></h2>

		<style type='text/css'>
			#gallery-9 {
				margin: auto;
			}
			#gallery-9 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-9 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-9 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-9' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/2_PaperPlastik.jpg' title="Shakshuka at Paper or Plastik" data-rl_title="Shakshuka at Paper or Plastik" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-9"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/2_PaperPlastik.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-9-8357" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-9-8357'>
				Shakshuka at Paper or Plastik
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong>Click the image above to enlarge</strong></h6>
<h5><strong>WHERE TO EAT IT: Paper or Plastik<br />
WHAT TO ORDER: Shakshuka<br />
WHAT’S IN IT? Roasted tomatoes, feta cheese, chino valley eggs, toast</strong><br />
<strong> WEBSITE: <a href="http://www.paperorplastikcafe.com/">http://www.paperorplastikcafe.com/</a></strong></h5>
<p>Everyone knows ripe tomatoes are delicious in caprese when paired with silky, fresh mozzarella — so we’re thinking outside the box this month and eating ours roasted and topped with poached eggs. If you haven’t tried Shakshuka, a delicious dish with strong roots in Arabic history, put Paper or Plastik on your short list.</p>
<h2><b>3. Corn</b></h2>
<h5></h5>

		<style type='text/css'>
			#gallery-10 {
				margin: auto;
			}
			#gallery-10 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-10 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-10 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-10' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/3_Clutch.jpg' title="Shrimp &amp; Grits at Clutch" data-rl_title="Shrimp &amp; Grits at Clutch" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-10"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/3_Clutch.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-10-8358" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-10-8358'>
				Shrimp &#038; Grits at Clutch
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong>Click the image above to enlarge</strong></h6>
<p><strong>WHERE TO EAT IT: Clutch<br />
WHAT TO ORDER: Shrimp &amp; Grits<br />
WHAT’S IN IT? Wild caught peeled shrimp, poblano peppers, cheesy grits, grilled corn, cherry tomatoes<br />
WEBSITE: <a href="https://www.clutchcalimex.com/">https://www.clutchcalimex.com/</a></strong><span style="font-weight: 400;"><br />
</span><span style="font-weight: 400;"><br />
We’re double-dipping on this one. Grits are made from corn, coarsely ground and cooked into the most delicious bowl of warmth. Clutch tops this classic Southern dish with additional grilled corn, complementing the cheesy umami flavor with that charred sweetness. </span><span style="font-weight: 400;"> </span></p>
<h2><b>4. Garlic</b></h2>

		<style type='text/css'>
			#gallery-11 {
				margin: auto;
			}
			#gallery-11 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-11 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-11 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-11' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/4_Milo.jpg' title="Wood Fired Garlic Knot at Milo &amp; Olive" data-rl_title="Wood Fired Garlic Knot at Milo &amp; Olive" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-11"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/4_Milo.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-11-8359" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-11-8359'>
				Wood Fired Garlic Knot at Milo &#038; Olive
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong> </strong><strong>Click the image above to enlarge</strong></h6>
<h5><strong>WHERE TO EAT IT: Milo &amp; Olive<br />
WHAT TO ORDER: Wood Fired Garlic Knot<br />
WHAT’S IN IT? Garlic, pizza dough, extra virgin olive oil, sea salt<br />
WEBSITE: <a href="http://www.miloandolive.com/">http://www.miloandolive.com/</a></strong></h5>
<p>Garlic isn’t just delicious, it does wonders for your overall health. Garlic is proven to battle sickness (including the common cold) as well as reduce the risk of heart disease. It can aid in lowering blood pressure and slowing down the aging process with naturally occurring antibiotics. Why eat it at Milo &amp; Olive? Because the Wood Fired Garlic Knot is hands down one of the best bites in Los Angeles. Golden brown on the outside, salty-sweet on the inside. Try it, and you’re welcome.</p>
<h2><b>5. Berries</b></h2>

		<style type='text/css'>
			#gallery-12 {
				margin: auto;
			}
			#gallery-12 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-12 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-12 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-12' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/5_Superba.jpg' title="Seasonal Crostata at Superba Food &amp; Bread" data-rl_title="Seasonal Crostata at Superba Food &amp; Bread" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-12"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/5_Superba.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-12-8360" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-12-8360'>
				Seasonal Crostata at Superba Food &#038; Bread
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong> </strong><strong>Click the image above to enlarge</strong></h6>
<p><strong>WHERE TO EAT IT: Superba Food &amp; Bread<br />
WHAT TO ORDER: Seasonal Crostata<br />
WHAT’S IN IT? Seasonal fruit picked at its peak, flaky pastry, coarse sugar<br />
WEBSITE: <a href="http://www.superbafoodandbread.com/">http://www.superbafoodandbread.com/</a></strong><span style="font-weight: 400;"><br />
</span><span style="font-weight: 400;"><br />
Superba rotates pastry fillings depending on what fruit is seasonally best. In the later months, this isn’t just limited to berries. Check out Superba in fall and winter for apple, pumpkin, and persimmon baked goods that will satisfy any sweet tooth. </span><span style="font-weight: 400;"> </span></p>
<h2><b>6. Carrots</b></h2>

		<style type='text/css'>
			#gallery-13 {
				margin: auto;
			}
			#gallery-13 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-13 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-13 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-13' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/6_Sycamore.jpg' title="Turkey Banh Mi at Sycamore Kitchen" data-rl_title="Turkey Banh Mi at Sycamore Kitchen" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-13"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/6_Sycamore.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-13-8361" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-13-8361'>
				Turkey Banh Mi at Sycamore Kitchen
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong> </strong><strong>Click the image above to enlarge</strong></h6>
<h5><strong>WHERE TO EAT IT: Sycamore Kitchen<br />
WHAT TO ORDER: Turkey Banh Mi<br />
WHAT’S IN IT? Roasted turkey, pickled carrots, cucumber, herbs, red chili sauce, soy mayo, fresh bread<br />
WEBSITE: http://thesycamorekitchen.com/</strong></h5>
<p>Carrots are available year-round in North America, but their true season is late summer to fall. We love to find new ways to enjoy them, like the house-made pickled carrots added to Sycamore Kitchen’s Banh Mi. One bite and you’ll appreciate that fresh, seasonal crunch.</p>
<h2><b>7. Eggplant</b></h2>

		<style type='text/css'>
			#gallery-14 {
				margin: auto;
			}
			#gallery-14 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 100%;
			}
			#gallery-14 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-14 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-14' class='gallery galleryid-8339 gallery-columns-1 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/7_Angelini.jpg' title="Grilled Vegetable Toast at Angelini Alimentari" data-rl_title="Grilled Vegetable Toast at Angelini Alimentari" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-14"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/7_Angelini.jpg" class="attachment-large size-large" alt="" aria-describedby="gallery-14-8362" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-14-8362'>
				Grilled Vegetable Toast at Angelini Alimentari
				</dd></dl><br style="clear: both" />
		</div>

<h6><strong> </strong><strong>Click the image above to enlarge</strong></h6>
<h5><strong>WHERE TO EAT IT: Angelini Alimentari<br />
WHAT TO ORDER: Grilled Vegetable Toast<br />
WHAT’S IN IT? Grilled zucchini, grilled eggplant, vegan mayonnaise, toast<br />
WEBSITE: <a href="https://www.angelinialimentari.com/">https://www.angelinialimentari.com/</a></strong></h5>
<p>First of all, how beautiful is this toast? You can practically taste it by looking at it. Angelini makes everything the old school Italian way: with whole ingredients, from scratch, and with lots of olive oil. The Grilled Vegetable Toast tastes like a trip to Tuscany. Just add wine.</p>
<p><span style="font-weight: 400;">Seasonal eating means brighter colors, bigger flavors, and the opportunity to introduce your palate to newly discovered favorites. Looking for something a little more adventurous? August is also the season for bitter melon, fennel, Jerusalem artichokes, and shishito peppers. Wake up early this weekend and head to your nearest farmers market for restaurant quality, seasonal, sustainable ingredients that are just waiting to be a part of your next home cooked meal.</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Erin Doll"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/erin.jpg" class="photo" width="80" alt="Erin Doll" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Erin Doll</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Erin Doll is a member of the ChowNow team and can usually be found interviewing the chefs/owners of partnering restaurants. She is a Los Angeles native and co-founder of @ForkedUp, a local food blog and social media marketing firm. </div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Erin Doll"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/erin.jpg" class="photo" width="80" alt="Erin Doll" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Erin Doll <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Back to School: In the Kitchen with 3 Restaurant Chefs</a><span> - September 6, 2017</span>				</li>				<li>					<a href="#">Seven In-Season Foods and Where to Eat Them in Los Angeles</a><span> - August 7, 2017</span>				</li>				<li>					<a href="#">Five Los Angeles BBQ Spots You Have to Try This Summer</a><span> - July 7, 2017</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fseven-best-seasonal-foods-eat-in-los-angeles&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

