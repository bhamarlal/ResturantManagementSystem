

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    5 Ways to Win Back Your Restaurant&#8217;s Customers from Grubhub                            
                    </h1>

                    <span class="meta">
                      <strong class="date">July 11th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Stephanie Capretta</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><span style="font-weight: 400;"><img class="alignnone size-full wp-image-8880" src="<?php echo base_url();?>assets/wp-content/uploads/1-Header-2.png" alt="Convert Grubhub customers" width="1000" height="474" /></span></p>
<p><span style="font-weight: 400;">Similar to many other third party online ordering portals, Grubhub, Eat24 and UberEATS take hefty commissions from each and every order a restaurant receives through their platforms. Not to mention, they fail to provide restaurants with valuable customer data, prohibiting restaurants from marketing to their customers in a smart and targeted manner. You may be asking yourself, ‘<em>Why</em></span><i><span style="font-weight: 400;"> would a restaurant owner sign up for this?’ </span></i><span style="font-weight: 400;">Here at ChowNow, we ask ourselves the same question.</span></p>
<p><span style="font-weight: 400;">We help our restaurant clients see the value behind having a branded online ordering solution. Read on to learn about the benefits of</span> converting third-party delivery app customers to your restaurant&#8217;s own online ordering channels — and some simple ways to convert them in practice.</p>
<h2><b>Why You Want to Convert Customers from Grubhub</b></h2>
<h3>Increase your profit margin.</h3>
<p><span style="font-weight: 400;">Let’s face it. It’s time to stop paying over and over again for your own customers. With Grubhub, you could be paying 15-30% commission on each and every order you receive. If the phone company charged you 30% for every phone order you processed, you would have stopped taking orders over the phone a long time ago. Not only are these large commissions cutting into your bottom line, but they are inhibiting you from using your money wisely. This financial freedom allows you to create room for a marketing budget that focuses on </span><b>your brand, </b><i><span style="font-weight: 400;">not Grubhub’s brand</span></i><span style="font-weight: 400;">.</span></p>
<h3>Market to your customers directly.</h3>
<p><img src="<?php echo base_url();?>assets/wp-content/uploads/HeroImgs-6.png" alt="restaurant retention" /></p>
<p><span style="font-weight: 400;">While Grubhub may bring in new customers and a high order volume, you aren’t receiving any valuable customer data from them. Instead, you’re forced to </span><i><span style="font-weight: 400;">rent</span></i><span style="font-weight: 400;"> your customers, while Grubhub </span><i><span style="font-weight: 400;">owns</span></i><span style="font-weight: 400;"> all of the information surrounding your customer database. This makes it very difficult for you to tailor your promotions and directly market to or communicate with your customers. With a branded ordering solution, you will have the ability to see and </span><b>own</b><span style="font-weight: 400;"> all of your customer data, including email addresses and ordering behavior. Having this valuable data can help you increase repeat orders and build loyalty with your customers.</span></p>
<h3>Stand out among competitors without paying for it.</h3>
<p><span style="font-weight: 400;">Let’s say you own an Italian restaurant and you’re known for your famous calzones. About a month ago, you had a new customer stop in to the restaurant to try one and they </span><b>loved</b><span style="font-weight: 400;"> it. You pass them a promotional card that you received from Grubhub to market your restaurant. </span><i><span style="font-weight: 400;">Fast forward to present day.</span></i><span style="font-weight: 400;"> That same customer may not remember your restaurant name, but they remember your famous calzones and seeing “Grubhub” at the top of the card you handed them. They search “calzones” in Grubhub’s search bar. Can you guess how many restaurants come up? </span></p>
<p><span style="font-weight: 400;">Not only will they be inundated with marketing for other restaurants that have paid to be at the top of the search results, but </span><b>your</b><span style="font-weight: 400;"> customer is now a loyal Grubhub customer. Can you imagine if they were handed a promotional card with your restaurant&#8217;s name at the top? This is yet another reason why having online ordering that is branded to your restaurant is so important.</span></p>
<h2><strong>How to Convert Grubhub Customers in 5 Easy Steps</strong></h2>
<h3><strong>1. Offer promotions on your website only.</strong></h3>
<h3><img class="alignnone size-full wp-image-8881" style="font-size: 16px;" src="<?php echo base_url();?>assets/wp-content/uploads/3-Body-PromoCard.png" alt="" width="1000" height="445" /></h3>
<p><span style="font-weight: 400;">To create an incentive for your customers to order directly from you, create a promotion that only applies on your website. If you want to get even more targeted with this promotion, create a specific promo code (e.g., </span><i><span style="font-weight: 400;">Get 20% off your next online order with code NOGRUBHUB</span></i><span style="font-weight: 400;">) to apply to their order. This will push customers to order less from the third party marketplace and more from your website. Offering a website-only promotion will not only drive customers directly to your branded ordering, but it will help to create a habitual ordering pattern and increase your order volume.</span></p>
<h3>2. Increase brand visibility.</h3>
<p><span style="font-weight: 400;">One thing Grubhub, UberEATS and others do well is promote themselves. Consider how they promote their platform. They send out email campaigns, promotional cards, signage, etc. Now it’s time to spread the word about </span><b>your</b><span style="font-weight: 400;"> brand in the same fashion, without losing your customer base to competitors. One easy way to convert your customers is by getting branded promotional cards for your restaurant and taping them to your takeout containers. Avoid just dropping them in the takeout bags or stapling them to the outside because you’ll run the risk of the Grubhub staff member tossing it out. </span></p>
<p><span style="font-weight: 400;">Do you have a hold message or voicemail for your phone line? Record a new one stating your website-only special and your website URL. Print your special on all of your takeout menus. Add branded table tents to every table. Think about all of the places your customers can see and put something there that mentions your branded online ordering. You’ll be sure to convert those customers in no time.</span></p>
<h3>3. Remove Grubhub as an option from your website.</h3>
<p><span style="font-weight: 400;">If you have multiple online ordering buttons listed on your website, you will most likely confuse your customers. How will they know which option to pick? If you’d like to prevent customers from ordering on Grubhub, the first step is to make sure their button is not visible on your website. If a customer has a choice between “Order on Grubhub” and “Order Online,&#8221; they will be more inclined to choose Grubhub because they recognize the name. Instead of running this risk, don’t give them an option!</span></p>
<h3><strong>4. Be transparent.</strong></h3>
<p><span style="font-weight: 400;">Your loyal customers deserve to know why you don’t want them to order from Grubhub. Be honest and open with them about the commissions they take. Customers care more than one might think and will always appreciate your honesty. Establish how they can help your business instead of hurt your business, by ordering directly from your branded ordering channels.</span></p>
<h3><strong>5. Get new customers through a restaurant-friendly marketplace.</strong></h3>
<p>If you&#8217;re still interested in acquiring new customers through an online ordering marketplace, make sure to sign up with one with restaurant-friendly pricing. Believe it or not, it is possible to sign up for a service that doesn&#8217;t charge you again and again for orders processed through their app. With a ChowNow subscription, you can not only take unlimited, commission-free orders through your website, Instagram and Facebook, but you also have the option to get listed on our top-rated mobile app and website. While other marketplaces charge a fee on every order, ChowNow takes a small finder’s fee on each <em><strong>new</strong></em> customers’ <em><strong>first</strong></em> order that we send you from our community of diners — all following orders are commission-free. Restaurants are never charged again and again for their own customers.</p>
<p>Even better, we equip you with the tools to convert newly acquired customers to your own ordering channels. ChowNow provides your restaurant with a Dashboard complete with customer email addresses and ordering behavior, so you can communicate with your customers directly with our suite of print and digital marketing products. New customers <em>and</em> free repeat business? That sounds like a win-win.</p>
<hr />
<p><span style="font-weight: 400;">Want more tips for converting your customers to your branded ordering system? If you’re a ChowNow client, reach out anytime and my team and I are here to chat! If you’re not taking online orders through ChowNow yet, get started with a <strong><a href="#">free demo</a></strong> today!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Stephanie Capretta"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/stephc.jpg" class="photo" width="80" alt="Stephanie Capretta" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Stephanie Capretta</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Stephanie is a member of the Restaurant Success Team at ChowNow and has worked in the restaurant industry since she was 16 years old. In her spare time, you’ll find Stephanie playing beach volleyball, adventuring/hiking outdoors, and hanging out with her boyfriend and their husky, Slater.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Stephanie Capretta"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/stephc.jpg" class="photo" width="80" alt="Stephanie Capretta" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Stephanie Capretta <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">5 Ways to Win Back Your Restaurant&#8217;s Customers from Grubhub</a><span> - July 11, 2018</span>				</li>				<li>					<a href="#">The Do’s and Don’ts of Running Restaurant Promotions</a><span> - July 10, 2018</span>				</li>				<li>					<a href="#">How to Crush Your Restaurant Marketing Goals in 2018</a><span> - January 10, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-to-win-back-your-customers-and-profits-from-grubhub%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

