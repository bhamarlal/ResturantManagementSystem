



    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Back to School: In the Kitchen with 3 Restaurant Chefs                            
                    </h1>

                    <span class="meta">
                      <strong class="date">September 6th, 2017</strong>
                                                <a href="<?php echo site_url('UserController/clientSpotLight') ?>" >Client Spotlight</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Erin Doll</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="aligncenter size-full wp-image-8412" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImage-4.png" alt="ChowNow_Pho_Saigon" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">What skill do you want to learn from a restaurant chef? If you could go to your favorite restaurant and ask the chef to teach you how to make one thing from the menu, what would you choose? Chefs not only have the talent to dream up delicious dishes, they have the ability to predict what separate ingredients will taste, feel, and smell like once they apply pressure, heat, and their own refined skill. </span></p>
<p><span style="font-weight: 400;">Turns out this skill is part talent and part rigorous training. Here at ChowNow, we are lucky to work with incredible chefs. Some are classically trained, some are self taught. Some are apprentices of culinary masters, some are famous chefs. Our restaurant partners are brilliant creatives whose dexterity is fueled by their passion for food. They are innovative in their craft and take pride not only in creating, but in teaching. So, we asked three of our chef partners to make us their apprentices. We asked them to take us behind the scenes and teach us to make three of our favorite (and most impressive) bites from their menus. </span></p>
<p><span style="font-weight: 400;">First, a perfectly crispy poached egg by Chef Andrea Uyeda of ediBOL. And we mean PERFECT. This molten yolk center will burst with the soft touch of a fork against its crispy outer shell. She adds these delicate dollops to her healthful and brightly colored bowls, impressing the eye and satisfying cravings every time. Second, bone broth as a base for the most warming pho you’ll ever enjoy. Chef Bernard Hoang of Pho Saigon Pearl has been simmering bone broth for years using traditional Vietnamese techniques. The umami flavors pack a powerful punch and pair perfectly with fresh toppings like basil, jalapeno, and bean sprouts. Third, pizza dough. Chef Or Amsalam of Lodge Bread Co. is a master of everything dough, from seeded rye to cinnamon roll. Every loaf is naturally leavened, and wildly fermented. Handmade dough makes all the difference when it comes to the perfect crust. As Or describes it, “this dough almost melts in your mouth.” </span></p>
<p><span style="font-weight: 400;">Let’s get started, class! School is officially in session. </span></p>
<h4></h4>

		<style type='text/css'>
			#gallery-4 {
				margin: auto;
			}
			#gallery-4 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-4 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-4 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-4' class='gallery galleryid-8402 gallery-columns-3 gallery-size-medium'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/ediBOL_1.jpg' title="The vegiBol with the perfectly crispy poached egg" data-rl_title="The vegiBol with the perfectly crispy poached egg" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/ediBOL_1.jpg" class="attachment-medium size-medium" alt="vegibol_ChowNow_ediBol" aria-describedby="gallery-4-8404" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8404'>
				The vegiBol with the perfectly crispy poached egg

				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/ediBOL_2.jpg' title="Chef in her DTLA kitchen" data-rl_title="Chef in her DTLA kitchen" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/ediBOL_2.jpg" class="attachment-medium size-medium" alt="Chef_Andrea_ediBol_ChowNow" aria-describedby="gallery-4-8407" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8407'>
				Chef in her DTLA kitchen
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/ediBOL_Headshot.jpg' title="Chef Andrea Uyeda" data-rl_title="Chef Andrea Uyeda" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/ediBOL_Headshot.jpg" class="attachment-medium size-medium" alt="ediBol_Chef_Andrea_ChowNow" aria-describedby="gallery-4-8406" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8406'>
				Chef Andrea Uyeda
				</dd></dl><br style="clear: both" />
		</div>

<h6>Click the images above to enlarge</h6>
<h4>HOW TO: <em>Make the Perfect Crispy Poached Egg<br />
</em>FROM: <em>ediBOL</em><br />
WHERE: <em>Arts District, Downtown LA, CA<br />
</em>CHEF: <em>Andrea Uyeda</em></h4>
<h4><b>ChowNow: </b><b>What flavors are customers expecting from ediBol?</b></h4>
<p><span style="font-weight: 400;">Andrea: Fresh &amp; bold! Customers always comment on how great they feel after their meal. They love that our food is light, healthy, refreshing…and also so satisfying and full of bright, bold flavors.</span></p>
<h4><b>C: How does the crispy poached egg balance out the flavors in your bowls? </b></h4>
<p><span style="font-weight: 400;">A: There are sweet, sour, bitter, salty, and savory (umami) tastes in each of our bowls. The crispy outer layer and creamy yolk binds these tastes…in a way that they are distinctive and complementary at the same time.</span></p>
<h4><b>C: Describe the important steps you take in making the crispy poached egg.</b></h4>
<p><span style="font-weight: 400;">A: 90 minutes of sous vide cooking, ice bath to stop the cooking, the hardest part of the process is applying the seasoned coating without cracking the yolk, set the eggs overnight, dip in fryer to order</span></p>
<h4><b>C: What advice would you give a reader who is interested in making the perfect crispy poached egg at home?</b></h4>
<p><span style="font-weight: 400;">A: Try this when you have lots of time. The process takes patience and can’t be rushed. Applying the coating is a 4 step process that requires a lot of gentle handling…carefully cracking the egg and holding one egg at a time in your hand as you apply the first coating, dip in binding mixture, and apply the second coating.</span></p>

		<style type='text/css'>
			#gallery-5 {
				margin: auto;
			}
			#gallery-5 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-5 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-5 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-5' class='gallery galleryid-8402 gallery-columns-3 gallery-size-medium'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-1.jpg' title="Rare filet mignon slowly cooks in the housemade bone broth" data-rl_title="Rare filet mignon slowly cooks in the housemade bone broth" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-5"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-1.jpg" class="attachment-medium size-medium" alt="Pho_Saigon_ChowNow_Filet_Mignon" aria-describedby="gallery-5-8410" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-5-8410'>
				Rare filet mignon slowly cooks in the housemade bone broth
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-2.jpg' title="Beef &amp; Oxtail bone broth individually spooned into each bowl" data-rl_title="Beef &amp; Oxtail bone broth individually spooned into each bowl" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-5"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-2.jpg" class="attachment-medium size-medium" alt="Beef_and_Oxtail_Broth_ChowNow_Pho_Saigon" aria-describedby="gallery-5-8411" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-5-8411'>
				Beef &#038; Oxtail bone broth individually spooned into each bowl
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-headshot.jpg' title="Chef Bernard Hoang" data-rl_title="Chef Bernard Hoang" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-5"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/PhoSaigon-headshot.jpg" class="attachment-medium size-medium" alt="Pho_Saigon_ChowNow_Chef" aria-describedby="gallery-5-8405" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-5-8405'>
				Chef Bernard Hoang
				</dd></dl><br style="clear: both" />
		</div>

<h6>Click the images above to enlarge</h6>
<h4>HOW TO: <em>Make Bone Broth<br />
</em>FROM: <em>Pho Saigon Pearl</em><br />
WHERE: <em>Beverly Grove, Los Angeles, CA<br />
</em>CHEF: <em>Bernard Hoang</em></h4>
<h4><b>ChowNow: What flavors signify traditional Vietnamese bone broth and how does it influence the traditional pho dish?</b></h4>
<h4><span style="font-weight: 400;">Bernard: The bone broth is like any other bone both base, but once you toast the different spices such as star anise, cinnamon, licorice slices it gives the broth it&#8217;s unique aroma.  Adding charred onions and ginger gives the broth its smokey sweet flavor.</span></h4>
<h4><b>C: What techniques are practiced in the making of traditional Vietnamese bone broth?</b></h4>
<h4><span style="font-weight: 400;">B: There are many techniques out there depending on the region as well as the cook.  Techniques such using different cut of beef bones to even adding chicken bones gives the broth a sweeter taste. I think one of the most important techniques is to be able to get a clear bone broth. You want to blanch the bones to get rid off all the impurities (trust me it does not look good or taste good if you skip this step). This will give the broth a nice clear, clean golden brown color once it is all done.  </span></h4>
<h4><b>C: Describe the important steps you take in creating the broth.</b></h4>
<p><span style="font-weight: 400;">B: As mentioned always blanch the bones. Very important. Since the bones we choose are thick and hearty there is a lot off flavor in them, so we like to cook the bones for over 20 hours to extract all that goodness within. After those 20 hours we toast the spices and char the onions &amp; ginger as well as add our seasonings such as salt, rock sugar and fish sauce. We then add brisket, oxtail, flank and fatty brisket and simmer for an additional 3-4 hours.  This gives the broth a rich hearty flavor. MSG is a big factor in Asian cooking.  We like to keep our broth as pure as possible so we do not use the packaged msg in our pho broth, which many pho restaurants do.  We use natural ways to get this umami flavor such as fish sauce and using the right amount and cut of bones etc.</span></p>
<h4><b>C: Do you make the broth differently than other restaurants in Los Angeles?</b></h4>
<p><span style="font-weight: 400;">B: We like to keep the broth pure and use no artificial flavorings (msg, bouillon etc.) And not skimp out on our ingredients.  We use high quality bones and use a large amount in each pot we make. Also we use oxtail which has a good balance of meat, fat and bone marrow.  This adds a rich beef flavor to the broth.</span></p>
<h4><b>C: What advice would you give a reader who is interested in making pho at home?</b></h4>
<p><span style="font-weight: 400;">B: My best advice would be is to take your time; there is no fast way or shortcut to making pho (unless you are making a chicken broth which takes about 3-4 hours). Blanch the bones and let it simmer for hours.  Pull all those wonderful sweet flavors out from the bones and you will have a great bone broth.</span></p>
<h4></h4>

		<style type='text/css'>
			#gallery-6 {
				margin: auto;
			}
			#gallery-6 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-6 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-6 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-6' class='gallery galleryid-8402 gallery-columns-3 gallery-size-medium'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-1.jpg' title="Pizza at Lodge Bread Co. is made in the traditional Neapolitan style" data-rl_title="Pizza at Lodge Bread Co. is made in the traditional Neapolitan style" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-6"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-1.jpg" class="attachment-medium size-medium" alt="Lodge_Bread_Co_ChowNow_pizza_dough" aria-describedby="gallery-6-8408" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-6-8408'>
				Pizza at Lodge Bread Co. is made in the traditional Neapolitan style
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-2.jpg' title="Slightly chewy, consistently fluffy crust makes pizza perfection" data-rl_title="Slightly chewy, consistently fluffy crust makes pizza perfection" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-6"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-2.jpg" class="attachment-medium size-medium" alt="Lodge_Bread_Co_ChowNow_pizza_crust" aria-describedby="gallery-6-8409" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-6-8409'>
				Slightly chewy, consistently fluffy crust makes pizza perfection
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-headshot.jpg' title="Chef Or Amsalam" data-rl_title="Chef Or Amsalam" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-6"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/LodgeBreadCo-headshot.jpg" class="attachment-medium size-medium" alt="Lodge_Bread_Co_Chef_Owner_Or" aria-describedby="gallery-6-8403" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-6-8403'>
				Chef Or Amsalam
				</dd></dl><br style="clear: both" />
		</div>

<h6>Click the images above to enlarge</h6>
<h4>HOW TO: <em>Make Pizza Dough<br />
</em>FROM: <em>Lodge Bread Co. </em><br />
WHERE: <em>Culver City, Los Angeles, CA<br />
</em>CHEF: <em>Or Amsalam</em></h4>
<h4><b>ChowNow: </b><b>What flavors and textures are customers expecting from a Lodge Bread Co. pizza?</b></h4>
<p><span style="font-weight: 400;">Or: It is more of a traditional wood-fire pizza where it is a little less crispy and much softer. It’s going to be messy—you’re going to have to fork and knife it. It’s a unique type of pizza. The dough almost melts in your mouth.</span></p>
<h4> <b>C: What’s your favorite part about the pizza dough making process?</b></h4>
<p><span style="font-weight: 400;">O: You’re always adapting, you’re always doing something new. You’re not just robot doing a recipe. Or a machine banging out a recipe. You can tell when something is made by hand and actually made by a human. It’s not just something thrown in a machine and made really quickly without any attention or care. </span></p>
<h4><b>C: Briefly describe the important steps you take in making &amp; baking your dough.</b></h4>
<p><span style="font-weight: 400;">O: The yeast that we use is a natural starter. It’s a mother. It’s just flour and water that ferments. It is a natural bacteria yeast in the environment. That starter will get incorporated in the dough and it eats away at the gluten. That’s what makes the dough active, rise and releases gas. This is the time when it ferments, gives it flavor, and a nice rise. It’s not a store bought yeast that is filled with different chemicals and additives—it’s a more natural process. It goes back to the old way of making dough. That’s why it tastes so good and that’s why your body can break it down so well. That’s why 100 years ago you didn’t hear about people having a gluten allergy.  The starter eats away all the tough gluten bonds so the end result is very, very low in gluten. It is far healthier. </span></p>
<h4><b>C: In your own words, describe how Lodge Bread Co. adheres to traditional Neapolitan style pizza making. </b></h4>
<p><span style="font-weight: 400;">O: In Naples, this is the traditional Neapolitan-style wood-fire pizza. It’s all fermented and all-natural flour. If you ask any Italian, they will tell you that real pizza is suppose to highlight the dough and not the other way around. If you go to traditional restaurants like Sotto or like Bestia—the pizza isn’t going to be a crispy pizza where you can pick it up and hold it. The pizza highlights the dough. The toppings are suppose to be delicate and not in your face. You get use the crust to soak up all the juices after. The dough really stands out.</span></p>
<h4> <b>C: What advice would you give a reader who is interested in making their own pizza at home?</b></h4>
<p><span style="font-weight: 400;">O: It’s a mix of care and attention that goes into our dough. it’s important to take time when making a good product and not rushing things. We mess with the recipe all the time. We constantly push to be better. That’s why it stands out—because it is a work in progress all the time.</span></p>
<p><span style="font-weight: 400;">And that’s the bell! Class dismissed. We cannot promise that you’re ready to sidle up to Gordon Ramsay, but at least you’re three tricks of the trade closer to pulling off an impressive meal for that date. Now go straight home, you’ve got some homework to do!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Erin Doll"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/erin.jpg" class="photo" width="80" alt="Erin Doll" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Erin Doll</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Erin Doll is a member of the ChowNow team and can usually be found interviewing the chefs/owners of partnering restaurants. She is a Los Angeles native and co-founder of @ForkedUp, a local food blog and social media marketing firm. </div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Erin Doll"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/erin.jpg" class="photo" width="80" alt="Erin Doll" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Erin Doll <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Back to School: In the Kitchen with 3 Restaurant Chefs</a><span> - September 6, 2017</span>				</li>				<li>					<a href="#">Seven In-Season Foods and Where to Eat Them in Los Angeles</a><span> - August 7, 2017</span>				</li>				<li>					<a href="#">Five Los Angeles BBQ Spots You Have to Try This Summer</a><span> - July 7, 2017</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fback-to-school-in-the-kitchen-with-three-chefs&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

