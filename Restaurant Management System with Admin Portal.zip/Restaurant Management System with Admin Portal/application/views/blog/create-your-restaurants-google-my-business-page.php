

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    How to Cash in on Mobile Searches with ChowNow &#038; Google Search                            
                    </h1>

                    <span class="meta">
                      <strong class="date">August 15th, 2016</strong>
                                                <a href="<?php echo site_url('UserController/mobileBlog') ?>" >Mobile</a> <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a>                     </span>

                    
                    
                    
                    
                    <div class="content">
                        <p style="text-align: justify;"><img class="size-full wp-image-7587 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/ChowNow-Google-Search-Ordering-gif.gif" alt="ChowNow Google Search Ordering gif" width="500" height="262" /></p>
<p><span style="font-weight: 400;">We learned at Connect Mobile Innovation Summit that mobile searches related to restaurants have a </span><b>90%</b><span style="font-weight: 400;"> conversion rate. Meaning, when someone is looking for you, they’re ready to be your customer. </span></p>
<p><span style="font-weight: 400;">The question for you as a restaurant owner then becomes, “what am I doing to make sure </span><i><span style="font-weight: 400;">I’m</span></i><span style="font-weight: 400;"> ready for </span><i><span style="font-weight: 400;">them</span></i><span style="font-weight: 400;">?”</span></p>
<p><span style="font-weight: 400;">ChowNow and Google have partnered up to give your customers the ability to place food orders directly from your Google business profile — enabling you to turn their searches into transactions for your restaurant.</span></p>
<p><b>How It Works</b></p>
<p><span style="font-weight: 400;">When a customer Googles your restaurant from their mobile device, they can “place an order” from your Google <img class=" wp-image-7588 alignright" src="<?php echo base_url();?>assets/wp-content/uploads/CN_GoogleOrdering_pressImage%402x.png" alt="CN_GoogleOrdering_pressImage@2x" width="279" height="412" />business profile and navigate directly to your menu. </span><span style="font-weight: 400;">Voilà</span><span style="font-weight: 400;"> — you’ve just turned Google Search into a revenue stream.<br />
</span></p>
<p><b>Get Set Up</b></p>
<p><span style="font-weight: 400;">The best part: this feature is free for ChowNow clients and ready for your customers to start using. There are two easy steps to get started:</span></p>
<ol>
<li style="font-weight: 400;"><b>Sign up for ChowNow</b><span style="font-weight: 400;"> (if you haven’t already!) </span>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">Fill out </span><strong><a href="#">this info form</a></strong><span style="font-weight: 400;"> to get connected with a ChowNow expert. </span></li>
</ul>
</li>
<li style="font-weight: 400;"><b>Claim your Google My Business Page</b><span style="font-weight: 400;"> (if you haven’t already!)</span>
<ul>
<li style="font-weight: 400;">Visit <strong><a href="#">www.google.com/business</a> </strong>to verify and claim your business listing, for free.</li>
</ul>
</li>
</ol>
<p><span style="font-weight: 400;">We highly recommend claiming your Google My Business page, regardless. From here, you can manage the information about your business that shows up for customers in Google Search and Google Maps. It’s an opportunity to share the key facts, tell your restaurant’s story and now, generate even more orders for your restaurant.</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Hayley Thayer</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Hayley Thayer is a member of the ChowNow Marketing team. In her free time, you’ll find Hayley eating salmon sashimi, ruminating on culture and politics, and obsessing over the latest men’s haircut and clothing trends.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Hayley Thayer <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a><span> - May 4, 2018</span>				</li>				<li>					<a href="#">Mouth-Watering Menus: 4 Ways to Write Enticing Menu Descriptions</a><span> - April 2, 2018</span>				</li>				<li>					<a href="#">Why You Need to Secure Your Restaurant&#8217;s Website with SSL Right Now</a><span> - March 3, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fcreate-your-restaurants-google-my-business-page&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

