

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    The Ultimate Guide: 7 Tips to Kick Your Snapchat Strategy Up a Notch                            
                    </h1>

                    <span class="meta">
                      <strong class="date">October 30th, 2017</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/socialMediaBlog') ?>" >Social Media</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Kristy Mai</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="aligncenter size-full wp-image-8550" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImage-7.png" alt="ChowNow Tocaya Organica Snapchat" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">Overwhelmed with all the latest Snapchat features? Snapchat has changed quite a bit over the past few years, and continues to advance with new tools to connect you with your customers. </span></p>
<p><span style="font-weight: 400;">If you read our </span><a href="#"><b>Essential Starter Kit for Snapchat</b></a><b>,</b><span style="font-weight: 400;"> then you already know the basics for posting on Snapchat, along with tips on how to create engaging and creative content. This guide is about taking your restaurant’s snapchat to the next level—and mastering these features better than your competition. </span></p>
<p><span style="font-weight: 400;">We’ve rounded up the 7 most useful tips that will enhance your Snapchat presence and boost awareness at your restaurant.</span></p>
<h1>The Ultimate Guide: 7 Tips to Kick Your Snapchat Strategy Up a Notch</h1>
<h2><b>1. Create your Own Geofilter</b></h2>
<p><span style="font-weight: 400;">Geofilters are an effective way to build brand awareness and promote your restaurant organically. Restaurants can create their own on-demand custom geofilter </span><a href="#"><b>here</b></a><span style="font-weight: 400;">. If it’s your first rodeo, we recommend using one of their templates. Once designed, pick the geographic location and time—from as short as an hour to as long as 60 days. The price for each varies depending on the length and size, and takes one business day to get approved. </span></p>
<p>First, upload or design your own Geofilter. If it&#8217;s your first time creating a Geofilter, we recommend using one other their templates.</p>
<p><img class="alignnone size-full wp-image-8555" src="<?php echo base_url();?>assets/wp-content/uploads/BodyImage_1-1.png" alt="" width="1000" height="507" /></p>
<p>Second, choose the geographic region users can use your Geofilter. The price of your filter will automatically adjust based on the coverage zone and duration of the ad.</p>
<p><img class="alignnone size-full wp-image-8545" src="<?php echo base_url();?>assets/wp-content/uploads/BodyImage_3.png" alt="Snapchat Geofilter" width="1000" height="445" /></p>
<p>Third, choose the time your Geofilter will start and end. You can opt for a longer term geofilter if you want to establish a permanent filter around your restaurant.</p>
<p><img class="alignnone size-full wp-image-8544" src="<?php echo base_url();?>assets/wp-content/uploads/BodyImage_2.png" alt="Snapchat Geofilter" width="1000" height="445" /></p>
<p><span style="font-weight: 400;">Once your filter has expired, Snapchat provides some basic reporting on how your filter performed, showing you Views (who saw your filter) and Uses (who took a Snap using your filter). We recommend keeping track of this  data because you’ll want to  to refer back to it later on. </span></p>
<p><b>Suggestion:</b><span style="font-weight: 400;"> Encourage customers to use the restaurant’s custom geotag and reward </span><span style="font-weight: 400;">them with a promo code.</span></p>
<h2><b>2. Try the Scissor Tool</b></h2>
<p><span style="font-weight: 400;">The </span><a href="#" target="_blank" rel="noopener"><b>sticker tool</b></a><span style="font-weight: 400;"> is a fun and creative tool to practice your editing skills. It’s essentially a simplified form of Photoshop. First take a Snapchat, then tap the Scissor icon, and then outline the part of the image you want to turn into a sticker. You can resize the sticker to make it smaller or larger, move it anywhere on the screen or save it later for future use. </span></p>
<p><b>Suggestion:</b><span style="font-weight: 400;"> Encourage your customers to send you a sticker of their favorite dish and send them a promo code in return.</span></p>
<h2><b>3. Join in on the Snapchat Lens trend</b></h2>
<p><span style="font-weight: 400;">Snapchat lenses are live effects that actually tracks your face as you move &#8211; a fun and interactive look to a video or photo. Snapchat updates their lenses daily, so show off your social media savviness by keeping up to date with their latest changes. </span></p>
<p><b>Suggestion: </b><span style="font-weight: 400;">Encourage your customers to send you an on-premise Snapchat with their favorite Snapchat lenses. </span></p>
<h2><b>4. Spur discovery with Context Cards</b></h2>
<p><span style="font-weight: 400;">This feature is a great way to find out more information about any Snapchat sent with the white-text, location specific Geofilter. Users can swipe up to any Snapchat with the word “more” on the bottom&#8211;and they’ll see an interactive card pop up with basic details for the restaurant such as address, phone number, website, and hours. Users can also make reservations via OpenTable or order rides to the restaurant via Uber or Lyft. Context cards are essentially a discovery and marketing platform that will enhance a restaurants brand presence. </span></p>
<p><b>Suggestion: </b><span style="font-weight: 400;">Prompt on-premise customers to post on their Snapchat Story with the location specific geofilter. That way your restaurant is exposed to a larger audience and it can promote your restaurant indirectly. </span></p>
<h2><b>5. Do a Snapchat Takeover</b></h2>
<p><img class="alignnone size-full wp-image-8569" src="<?php echo base_url();?>assets/wp-content/uploads/BodyImage_5-1-1.png" alt="" width="1000" height="500" /></p>
<p><span style="font-weight: 400;">A Snapchat takeover is a great way to bring someone else’s perspective and take on the brand. Some different media brands, like Eater and Lucky Peach invite chefs to do Snapchat takeovers—which helps them with reaching new audiences, mix in a new perspective and building your overall brand. </span></p>
<p><b>Suggestion:</b><span style="font-weight: 400;"> Have a different staff member do a takeover&#8211;from the head chef plating to the hostess greeting guests. These new perspectives will make your customers feel more connected to your restaurant. </span></p>
<h2><b>6. Post to your local story</b></h2>
<p><span style="font-weight: 400;">Every city has a local story that is accessible to all Snapchat users in the area. Post your favorite Snapchat story to the local story—and this will increase the chance your Snapchat will reach a larger audience, and promote your restaurant to other Snapchat users in the surrounding area. </span></p>
<p><b>Suggestion:</b><span style="font-weight: 400;"> Make sure to keep track of your Snapchat Story views and note of any big spikes because that means the local Snapchat team saw something they liked. </span></p>
<h2><b>7. Showcase your culture</b></h2>

		<style type='text/css'>
			#gallery-2 {
				margin: auto;
			}
			#gallery-2 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-2 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-2 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-2' class='gallery galleryid-8507 gallery-columns-3 gallery-size-full'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/BodyImage_4.png' title="" data-rl_title="" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-2"><img width="1000" height="445" src="../wp-content/uploads/BodyImage_4.png" class="attachment-full size-full" alt="" /></a>
			</dt></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/BodyImage_6.png' title="" data-rl_title="" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-2"><img width="1000" height="445" src="../wp-content/uploads/BodyImage_6.png" class="attachment-full size-full" alt="" /></a>
			</dt></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/BodyImage_7.png' title="" data-rl_title="" class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-2"><img width="1000" height="445" src="<?php echo base_url();?>assets/wp-content/uploads/BodyImage_7.png" class="attachment-full size-full" alt="" /></a>
			</dt></dl><br style="clear: both" />
		</div>

<p><span style="font-weight: 400;">Your customers come back to your restaurant because they love your food and atmosphere, so why not show them the people behind the counter. Use Snapchat to give your loyal customers a raw, scrappy and exclusive look at what’s going on in your kitchen. Snapchat is all about letting your personality shine through and connecting with your audience on a human level.</span></p>
<p><b>Suggestion: </b><span style="font-weight: 400;">Take your customers behind the scenes by Snapchatting your chefs preparing meals, barista making drinks or staff members. </span></p>
<hr />
<p><span style="font-weight: 400;">If you’re a ChowNow restaurant client and want some feedback on social media marketing, </span><a href="#"><b>schedule a call</b></a> <span style="font-weight: 400;">— we’re happy to help. If you don’t already have online ordering at your restaurant, now’s a great time to get started. </span><a href="#"><b>Get a free ChowNow demo</b></a><span style="font-weight: 400;"> from one of our experts to get started today!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Kristy Mai"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/kristy.jpg" class="photo" width="80" alt="Kristy Mai" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Kristy Mai</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Kristy is a member of the ChowNow Discover team. In her free time, you can find Kristy drinking copious amounts of nitro cold brew, trying out a new spin studio or obsessing over the latest food trends. She is a Southern California native and grew up working at her parent’s Chinese restaurant in San Diego.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Kristy Mai"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/kristy.jpg" class="photo" width="80" alt="Kristy Mai" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Kristy Mai <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">The Ultimate Guide: 7 Tips to Kick Your Snapchat Strategy Up a Notch</a><span> - October 30, 2017</span>				</li>				<li>					<a href="#">Celebrating Day of the Dead at L.A. Restaurant Toca Madera</a><span> - October 6, 2017</span>				</li>				<li>					<a href="#">The Essential Snapchat Starter Kit for Restaurants</a><span> - August 31, 2017</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fultimate-snapchat-guide-for-restaurants&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

