

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Tutorial: How to Enroll in ChowNow&#8217;s Apple Developer Program                            
                    </h1>

                    <span class="meta">
                      <strong class="date">July 9th, 2018</strong>
                                                                    </span>

                                            <span class="meta2"><span class="author">Written by Ebony Kizzee</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <h2><img class="alignnone size-full wp-image-8167" src="<?php echo base_url();?>assets/wp-content/uploads/Mobile-Images.png" alt="mobile food ordering" width="1000" height="445" /></h2>
<p>Eager to establish a stronger connection with your customers and increase repeat orders? Get your very own branded mobile app to put your menu in their hands, wherever they are.</p>
<p>After signing up with your Restaurant Success Manager or Account Coordinator, you can follow the guide below to get a branded iPhone app, built and developed by ChowNow.</p>
<p><b><i>Please Note: </i></b><i><span style="font-weight: 400;">If you already have an Apple Developer account linked to your restaurant brand, please skip to Step 5.</span></i></p>
<h2><b>Step 1:  Prepare your business domain email and business’s DUNS number.</b></h2>
<p>You should have already had a call with our in-house App Specialist before following the steps in this tutorial. If you haven&#8217;t scheduled a call, please refer to the email we sent you to schedule a phone appointment.</p>
<ul>
<li><b>Have your restaurant domain email address ready: </b><span style="font-weight: 400;">Use an email address you frequently access with a business domain (i.e. name@business.com). This cannot be a Gmail, Yahoo, Hotmail, other domain. </span>
<ul>
<li><em><b>Please note:</b><span style="font-weight: 400;"> If you do not have a business domain email address, you cannot enroll in the Apple Developer Program until you create one.  If you do not have one, please contact your ChowNow App Specialist directly to provide you options on how to purchase one.</span></em></li>
</ul>
</li>
</ul>
<p><img class="alignnone size-full wp-image-8877" src="<?php echo base_url();?>assets/wp-content/uploads/01-DomainEmail-1.png" alt="" width="734" height="482" /></p>
<ul>
<li><b>Look Up Your DUNS number: </b><span style="font-weight: 400;">A DUNS number is a unique nine-digit identifier for businesses. Don’t know if you have a DUNS number? </span><span style="font-weight: 400;">Simply </span><span style="font-weight: 400;">search for it</span><a href="#" target="_blank" rel="noopener"> <b>here</b></a><span style="font-weight: 400;"> by using your restaurant address or phone number. If you need to create one, it’s easy to do so and free of cost. Simply </span><a href="#" target="_blank" rel="noopener"><strong>click</strong> <b>here to get started.</b></a>
<ul>
<li style="font-weight: 400;"><b><i>Please note: </i></b><i><span style="font-weight: 400;">Please take the “registration name” your DUNS number is under (whether it’s your restaurant’s name or LLC name) and email it over to your App Specialist, as the ChowNow team will need it for their records. </span></i></li>
</ul>
</li>
</ul>
<h2><b>Step 2: Create a business Apple ID.</b></h2>
<p><b><i>Please note: </i></b><i><span style="font-weight: 400;">If you already have an Apple ID using your business domain email, please skip to Step 3.</span></i></p>
<p><img class="alignnone size-full wp-image-8878" src="<?php echo base_url();?>assets/wp-content/uploads/02-AppleID-1.png" alt="" width="734" height="442" /></p>
<ul>
<li><a href="#"><b>Create an Apple ID</b></a><span style="font-weight: 400;"> using your business domain email address (i.e. info@hudsonscafe.com).</span></li>
<li><span style="font-weight: 400;">Once you fill out the form to create an Apple ID, Apple will send a verification email to your Apple ID email address</span> <span style="font-weight: 400;">with a</span><b> 6-digit confirmation code</b><span style="font-weight: 400;">. Once you receive this email, enter this code into the web form.</span></li>
<li><span style="font-weight: 400;">Finally, click on ‘Verify’ to create your Apple ID.</span>
<ul>
<li><b><i>Please note</i></b><i><span style="font-weight: 400;">: If you are not able to create an Apple ID after inputting the verification code, it is most likely due to Apple’s hours of operation. If this occurs, please contact Apple Support directly at 1-800-275-2273 in order to resolve the problem.</span></i></li>
</ul>
</li>
</ul>
<h2><b>Step 3: Using your newly created Apple ID, complete your Apple Developer form<span style="font-weight: 400;">.</span></b></h2>
<ul>
<li style="font-weight: 400;"><a href="#" target="_blank" rel="noopener"><b>Sign in with your Apple ID</b></a><span style="font-weight: 400;"> onto the Apple Developer page.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Select</span><b> “Company/Organization” </b><span style="font-weight: 400;">from the Entity Type dropdown. </span>
<ul>
<li style="font-weight: 400;"><b><i>Please note: </i></b><i><span style="font-weight: 400;">DO NOT</span></i> <i><span style="font-weight: 400;">select “Individual/Sole Proprietor/Single Person Business.” </span></i></li>
</ul>
</li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Confirm that you have the authority to sign legal agreements on behalf of your organization.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">When it asks for your organization’s number, we recommend inputting your cell phone number rather than the restaurant line, as this will be the easiest way for Apple to contact you.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Proceed to filling out the ‘Organization Information’ section. Here, you will input your restaurant’s </span><b>DUNS number</b><span style="font-weight: 400;">. </span>
<ul>
<li style="font-weight: 400;"><b><i>Please Note</i></b><i><span style="font-weight: 400;">: After you input your DUNS number, t</span></i><i><span style="font-weight: 400;">here is a possibility that an error message will be prompted </span></i><i><span style="font-weight: 400;">that states, “This organization could not be verified as a legal entity…” This is very common. If you experience this error message, please click “update your D&amp;B profile” (image below).  After you submit this update, it normally takes D&amp;B about 14 days to update the DUNS number. This developer form and process has to be put on hold at this point until the updated DUNS number is received—though please make sure to contact your App Specialist, letting them know this error was encountered and the update was submitted.</span></i></li>
</ul>
</li>
</ul>
<p><img class="alignnone size-full wp-image-8876" src="<?php echo base_url();?>assets/wp-content/uploads/03-DUNSError-1.png" alt="" width="734" height="482" /></p>
<ul>
<li style="font-weight: 400;"><b>At the end of the developer form, you will notice a two-factor authentication box. </b><span style="font-weight: 400;">Apple requires <em>two-factor</em> authentication to be turned on to enroll in the Apple Developer Program. It is important to point out that this is different from <em>two-step</em> authentication. In order to get past this step, you must use an Apple product—either an iPhone, iPad, or iPod touch with iOS 9 and later, or a Mac with OS X El Capitan and later. We recommend using an iPhone if available. </span>
<ul>
<li style="font-weight: 400;"><b><i>Please Note</i></b><i><span style="font-weight: 400;">: You can also use a co-worker’s Apple device to complete this step! If you cannot get access to an Apple device, please let your App Specialist know, and we can assist you with this step. </span></i></li>
</ul>
</li>
<li style="font-weight: 400;"><span style="font-weight: 400;">On your trusted device, please go to &#8220;S</span>ettings&#8221;<span style="font-weight: 400;"> and select on your name (the top box).  Scroll to the bottom of the Apple ID page and select “Log Out.” When it issues a prompt that says, “<strong>Merge Accounts,</strong>” we recommend selecting “Yes” to avoid losing your personal data.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Once you log out of your personal ID, sign in again using your business Apple ID.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">After you’ve logged in with your business Apple ID, select</span><b> &#8220;Password &amp; Security&#8221;</b><span style="font-weight: 400;"> under the Apple ID tab.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Next, simply tap</span><b> ‘Turn on Two-Factor Authentication</b><span style="font-weight: 400;">’ and select continue.  A code will be displayed that you will then input into your Apple Developer form in order to complete this step.</span></li>
</ul>
<h2><strong>Step 4: Verify your Apple Developer account.</strong></h2>
<ul>
<li style="font-weight: 400;"><b>Receive a phone call from Apple: </b><span style="font-weight: 400;">Once you submit the enrollment form, an Apple representative will call the phone number you provided. While on that call, you will need to provide them with the following information:  </span>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">Your first and last name</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Date of birth</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">A secondary contact person for this Apple Developer account</span>
<ul>
<li style="font-weight: 400;"><b><i>Please Note:</i></b><span style="font-weight: 400;"> If you do not hear from them within 24 hours, we recommend logging back into your Developer account and requesting a call from Apple in order to speed up this process. To do so, you can simply select the “contact us page, “development &amp; technical,” “developer forum issue,” and select on request call.</span></li>
</ul>
</li>
</ul>
</li>
<li style="font-weight: 400;"><b>Receive an email to accept terms</b><span style="font-weight: 400;">: After the successful verification call, you will receive an email from Apple containing a license agreement. </span><b>Select “Review Now” </b><span style="font-weight: 400;">in the email and continue through the terms. After agreeing, you will automatically proceed to the payment page.</span></li>
<li style="font-weight: 400;"><b>Complete your payment for the Apple Developer Program</b><span style="font-weight: 400;">: You’ll see a final cost of $99 and have the option to select auto-renewal for this annual $99 fee for your developer account — we highly recommend choosing this option to ensure your app does not get removed from the App Store. Select “Purchase” and confirm your login information to submit your billing information and complete the developer process.</span></li>
</ul>
<h2><strong>Step 5: Invite ChowNow as a contributor.</strong></h2>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">First, invite ChowNow to your new </span><b>App Store Connect account.</b>
<ul>
<li style="font-weight: 400;"><a href="#"><b>Log in</b></a><span style="font-weight: 400;"> to App Store Connect with your Apple ID.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Select “Users and Access” and click on the + symbol to add a contributor. Enter “ChowNow” in the “Name” field, and in the “Email Address”  field, enter the ChowNow developer email address that your App Specialist provided you in your ChowNow purchase confirmation email. </span>
<ul>
<li style="font-weight: 400;"><b>Please Note: </b><span style="font-weight: 400;">Be sure to select both “Admin” in addition to “Access to Certificates, Identifiers &amp; Profiles.”</span></li>
</ul>
</li>
</ul>
</li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Second, </span><b>confirm with your App Specialist that the invitation was received</b><span style="font-weight: 400;">.</span>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">At this point, please call or email your App Specialist in order to make sure the invite was received properly. Once we have received and accepted the invite, we will take it from here to build and publish your app. </span></li>
</ul>
</li>
</ul>
<p><b>That’s it!</b><span style="font-weight: 400;"> We will let you know as soon as the app has been published, within 2 weeks of receiving your invite via email. If you have any questions related to this process, please reach out to your App Specialist directly.</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Ebony Kizzee"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/ebony.jpg" class="photo" width="80" alt="Ebony Kizzee" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Ebony Kizzee</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Ebony Kizzee is a member of the Restaurant Success Team and works to help restaurants compete in the mobile app ordering space.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Ebony Kizzee"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/ebony.jpg" class="photo" width="80" alt="Ebony Kizzee" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Ebony Kizzee <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Tutorial: How to Enroll in ChowNow&#8217;s Apple Developer Program</a><span> - July 9, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-to-enroll-apple-developer-program%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

