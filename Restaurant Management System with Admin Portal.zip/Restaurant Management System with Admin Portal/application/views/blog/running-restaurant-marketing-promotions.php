

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    The Do’s and Don’ts of Running Restaurant Promotions                            
                    </h1>

                    <span class="meta">
                      <strong class="date">July 10th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Stephanie Capretta</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone size-full wp-image-8062" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImg-5-1.png" alt="restaurant promotions" width="1000" height="475" /></p>
<p>We know that saving money is the #1 concern for restaurant owners &amp; managers everywhere. It’s easy to shy away from the idea of selling your food for a smaller profit. In reality, running a promotion can not only help you stand out and be memorable, but it can give your customers an incentive to purchase more than they would have normally! Take a look at some of our “do’s” and “don’ts” of running promotions, designed to help keep your customers coming back for more.</p>
<h2><strong>Do this:</strong></h2>
<p><strong><b>Keep it simple</b></strong></p>
<p><strong><b><img class="alignnone size-full wp-image-8064" src="<?php echo base_url();?>assets/wp-content/uploads/img-keepitsimple.png" alt="restaurant promotions" width="1000" height="404" /></b></strong></p>
<p>I don’t know about you, but the discount code “123get50percent0FF456” wouldn’t necessarily have me reaching for my phone to place an order. The key to promo codes is keeping it short, sweet, and relevant. Is there a holiday coming up? Think “GREEN” for St. Patrick’s Day. Running a percentage discount? Try “25OFF” to be specific. The easier the code is to type in, the more likely the customer will be to use it.</p>
<p><strong><b>Stay current &amp; on trend</b></strong></p>
<p>In this day and age, there is always something “trending”. Remember <strong><a href="#" target="_blank" rel="noopener">Pokemon Go</a></strong>? Restaurants that advertised as a “PokeStop” were suddenly flooded with hungry gamers. Don’t let your promotions run stale. Stay in the know and act accordingly! If there is a popular event coming up in your community or a trending topic that relates to your business, jump on it before it’s too late.</p>
<p><strong>Run an Instagram contest</strong></p>
<p>An effective and creative way to market your restaurant is to <strong><a href="#" target="_blank" rel="noopener">run a contest on Instagram</a></strong>. Promoting a new dish? Try posting a photo of the item with clear &amp; concise rules for the contest. Followers can compete with their own images and tag your restaurant to enter. The winner gets that new dish for free! The idea is to stay relevant and give your customers more of a reason to be excited about your brand.</p>
<h2><strong>Not this:</strong></h2>
<p><strong>Don&#8217;t keep your promotion a secret</strong></p>
<p><img class="alignnone size-full wp-image-8065" src="<?php echo base_url();?>assets/wp-content/uploads/img-promo-secret.png" alt="restaurant promotions" width="1000" height="392" /></p>
<p><span style="font-weight: 400;">Make sure that no matter where your customers look, they are aware of the promotion going on. Add the details of the promotion to your voicemail message. Enter the promotion into your POS system so it prints out on all receipts. Do you provide table service? Add a promotional card to all of your checkbooks. Does your restaurant have a counter? Place a sign on the counter with the discount details. There are endless ways to inform your customers of great deals, it’s just a matter of you placing it there for them.</span></p>
<p><strong>Don&#8217;t rush your customers</strong></p>
<p><strong><span style="font-weight: 400;">Time is of the essence! Promote your next special at least two weeks in advance, since future party plans could involve a huge order from your restaurant. Promoting a deal with short notice won’t capture the intended audience in time for you to see the expected results. Especially if it’s a holiday or big event (e.g., the Superbowl). If customers are planning to place a big takeout order for a party, more likely than not they already have a restaurant in mind. </span></strong></p>
<p><strong>Don&#8217;t devalue your menu</strong></p>
<p><img class="alignnone size-full wp-image-8063" src="<?php echo base_url();?>assets/wp-content/uploads/img-food-1.png" alt="restaurant promotion food" width="1000" height="445" /></p>
<p><span style="font-weight: 400;">We understand! You want to save money by giving away something that doesn’t cost you much, but let’s face it &#8211; by offering promotions that aren’t attractive, you’re not only devaluing your menu items but you’re wasting your resources by offering something that customers won’t care about. Would a “5% Off” promotion excite you if you found out the order minimum was $300? Exactly. </span></p>
<p><span style="font-weight: 400;">There are many effective ways to promote your restaurant that will increase revenue and create loyal customers. If you’re doing some of the “Don’ts”, don’t sweat it! It’s never too late to change those into “Do’s”.</span></p>
<hr />
<p><span style="font-weight: 400;">If you’re a ChowNow restaurant client and want some feedback on your upcoming promotion, </span><strong><a href="#" target="_blank" rel="noopener">schedule a call</a></strong><span style="font-weight: 400;"> — we’re happy to help. If you don’t already have online ordering at your restaurant, 2017 is a great time to get started. <strong><a href="#" target="_blank" rel="noopener">Get a free ChowNow demo</a></strong> from one of our experts to get started today!</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Stephanie Capretta"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/stephc.jpg" class="photo" width="80" alt="Stephanie Capretta" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Stephanie Capretta</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Stephanie is a member of the Restaurant Success Team at ChowNow and has worked in the restaurant industry since she was 16 years old. In her spare time, you’ll find Stephanie playing beach volleyball, adventuring/hiking outdoors, and hanging out with her boyfriend and their husky, Slater.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Stephanie Capretta"><img src="../wp-content/uploads/gravatar/stephc.jpg" class="photo" width="80" alt="Stephanie Capretta" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Stephanie Capretta <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">5 Ways to Win Back Your Restaurant&#8217;s Customers from Grubhub</a><span> - July 11, 2018</span>				</li>				<li>					<a href="#">The Do’s and Don’ts of Running Restaurant Promotions</a><span> - July 10, 2018</span>				</li>				<li>					<a href="#">How to Crush Your Restaurant Marketing Goals in 2018</a><span> - January 10, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Frunning-restaurant-marketing-promotions&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

