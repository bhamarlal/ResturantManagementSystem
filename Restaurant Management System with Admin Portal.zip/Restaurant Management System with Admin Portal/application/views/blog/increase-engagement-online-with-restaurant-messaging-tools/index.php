

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Increase Engagement Online with Restaurant Messaging Tools                            
                    </h1>

                    <span class="meta">
                      <strong class="date">June 12th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Alec McGuffey</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone wp-image-8866 size-full" src="<?php echo base_url();?>assets/www.chownow.com/wp-content/uploads/1-Header-1.png" alt="Restaurant Messaging Tools" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">The way that people communicate with each other has changed dramatically over the last decade, with </span><strong><a href="#" target="_blank" rel="noopener">a recent report</a></strong><span style="font-weight: 400;"> showing that the average American spends 26 minutes each day texting compared to only 6 minutes talking on the phone. It’s therefore not at all surprising that most consumers now want to speak with businesses via text message as well &#8212; Twilio recently found </span>that a staggering <strong><a href="#" target="_blank" rel="noopener">90% of people</a></strong> would prefer to speak with brands via messaging apps.</p>
<p><span style="font-weight: 400;">With the rise of online ordering and reservations platforms and easy consumer access to restaurant information on sites like Google and Yelp, it’s easy to see why restaurants are more focused than ever on perfecting their online presence with messaging tools. In fact, many restaurants are </span><strong><a href="#" target="_blank" rel="noopener">ditching their landlines</a></strong><span style="font-weight: 400;"> completely in an effort to cut costs and push customers to get answers to their questions online. </span></p>
<p><span style="font-weight: 400;">Read on to learn how your restaurant can embrace restaurant messaging tools to increase engagement with your customers online.</span></p>
<h2><strong>Where can guests message your restaurant online?</strong></h2>
<p><img class="alignnone wp-image-8868 size-full" src="<?php echo base_url();?>assets/www.chownow.com/wp-content/uploads/4_Body-Reply.png" alt="Restaurant Messaging Tools" width="1000" height="665" /><span style="font-weight: 400;">As consumers spend more time texting and less time calling, it’s more important than ever to make it easy for them to connect with your business and let them get answers to their questions quickly from their preferred messaging channels.</span></p>
<p><span style="font-weight: 400;">But how do you let customers interact with your restaurant in real time without hiring new staff and taking your attention away from your restaurant?</span></p>
<p><span style="font-weight: 400;">Let’s first take a step back and talk about how many ways there are for guests to get in touch with your business in messaging apps. Up until a few years ago, there were two ways for guests to get in touch with you &#8212; by phone and by email. Now, however, there are dozens of messaging platforms, which can feel overwhelming at first glance.</span></p>
<p><span style="font-weight: 400;">Nearly all of the major platforms, from Yelp to Facebook, have begun to embrace messaging in the past few years, so having a messaging strategy is not only a great way to chat with customers in their preferred format, but also an effective way to be present on </span><i><span style="font-weight: 400;">new</span></i><span style="font-weight: 400;"> platforms as soon as they are launched. </span></p>
<p><span style="font-weight: 400;">The same can be said for online ordering, with companies like </span><strong><a href="#" target="_blank" rel="noopener">ChowNow</a></strong><span style="font-weight: 400;"> helping restaurants ditch the archaic phone ordering and streamline their ordering process by offering simple ordering to customers everywhere they are online, from Facebook to Instagram to a restaurants’ own website.</span></p>
<p><span style="font-weight: 400;">Here are the major platforms currently embracing messaging:</span></p>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">Facebook (the “Message” button on your page)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Yelp (the “Message the business” button on your page)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Google My Business (a “Message” button on your search results)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Twitter (the “Message” button on your page)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Resy (editing reservations via text message)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Your website (live chat on your website)</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">SMS (the most basic of all &#8212; letting guests text you directly)</span></li>
</ul>
<p><span style="font-weight: 400;">If you can’t tell, most of the sites that you have a restaurant profile on already have messaging options, with more adding messaging every month.</span></p>
<p><span style="font-weight: 400;">However, in many cases, if a customer tries to message your business on any of these platforms, they’ll never get a response. In much the same way that someone leaving a voicemail and never getting a response could result in lost business, the same is true for unanswered messages. In fact, 95% of restaurants have the Message button enabled on Facebook but don’t even realize it!</span></p>
<h2><strong>How to chat-enable your restaurant</strong></h2>
<p><span style="font-weight: 400;">Even if you haven’t embraced messaging yet, it doesn’t change the fact that your customers </span><i><span style="font-weight: 400;">want</span></i><span style="font-weight: 400;"> to message you, and being responsive online is a great way to capture new bookings and keep existing customers coming back. Major restaurant chains across the country are pushing full steam ahead into the world of messaging. Domino’s recently released DOM, it’s </span><strong><a href="#" target="_blank" rel="noopener">online ordering chatbot</a></strong><span style="font-weight: 400;">, which lets you order from any of their locations in a conversational format. Friday’s has had automated messaging enabled on </span><strong><a href="#" target="_blank" rel="noopener">Facebook</a></strong><span style="font-weight: 400;"> for over a year. And if you visit Patron’s </span><strong><a href="https://twitter.com/Patron" target="_blank" rel="noopener">Twitter page</a></strong><span style="font-weight: 400;">, you can have a full conversation with their AI-powered cocktail artist chatbot.</span></p>
<p><span style="font-weight: 400;">Depending on what is most important for your restaurant and how your team is structured, there are a few different ways that you can let your guests message you.</span></p>
<h3><strong>Live Chat Tools</strong></h3>
<p><span style="font-weight: 400;">You’ve probably seen those “Chat with us” icons pop up on many websites recently. Live chat is a tool that many startups and businesses are embracing, because it lets them answer customer questions in real time. Services like </span><strong><a href="#" target="_blank" rel="noopener">Intercom</a></strong><span style="font-weight: 400;"> are great tools for live chat if you can devote the necessary resources to it. For example, diners ordering their lunch on </span><strong><a href="#" target="_blank" rel="noopener">Allset’s website</a></strong><span style="font-weight: 400;"> can chat directly with a rep at the company if they have questions about their orders.</span></p>
<p><img class="alignnone wp-image-8862 size-full" src="<?php echo base_url();?>assets/www.chownow.com/wp-content/uploads/2-Body-Chat.png" alt="Restaurant Messaging Tools" width="1000" height="665" /></p>
<p><span style="font-weight: 400;">Live chat has many advantages because it lets customers chat with a live person at your restaurant in real time. This lets your staff answer difficult questions quickly.</span></p>
<p><span style="font-weight: 400;">The downside of live chat is that it requires someone from your team to be monitoring a dashboard waiting for questions. And if a customer thinks they’re chatting with a real person, they expect answers quickly or else they’ll get frustrated. Live chat is also often limited to certain platforms like your website and Facebook.</span></p>
<h3><strong>Automated Messaging Tools</strong></h3>
<p><span style="font-weight: 400;">If you want the benefits of live chat without having to devote valuable staff time to actually </span><i><span style="font-weight: 400;">answering</span></i><span style="font-weight: 400;"> questions, then an automated tool might be your best bet. There are three main ways automated messaging solutions you can choose.</span></p>
<p><span style="font-weight: 400;">First, you can create your own! Platforms like </span><strong><a href="#" target="_blank" rel="noopener">Chatfuel</a></strong><span style="font-weight: 400;"> and </span><strong><a href="#" target="_blank" rel="noopener">Facebook</a></strong><span style="font-weight: 400;"> let you build your own series of automated responses about your restaurant. The customization for these tools is limitless, but the downside is that you’ll spend dozens of hours creating it. And once you’ve finished it, you’re limited to responding to customers on just your website and Facebook page.</span></p>
<p><img class="alignnone wp-image-8869 size-full" src="<?php echo base_url();?>assets/www.chownow.com/wp-content/uploads/2-Body-Chat-1.png" alt="Restaurant Messaging Tools" width="1000" height="665" /></p>
<p><span style="font-weight: 400;">Second, you can use a solution built specifically for the restaurant industry. </span><strong><a href="#" target="_blank" rel="noopener">Guestfriend</a></strong><span style="font-weight: 400;"> is one such tool. It pulls in all the information you’ve already put on your website and other pages, so it’s fully-customized with no work required on your end. You can easily add it to all of the platforms we listed above, so you can effortlessly answer your customers’ questions anywhere they’re discovering you online. </span></p>
<p><span style="font-weight: 400;">Finally, if you’re hyper-focused on accepting online orders for your restaurant and don’t want to complicate the ordering process by allowing guests to ask additional questions, you can use ChowNow’s Facebook integration to allow guests to make orders directly on your Facebook page and from your Google search results.</span></p>
<p><span style="font-weight: 400;">The way that your customers are learning about restaurants has radically changed in the last few years. Whereas previously people preferred to call restaurants to ask about reservations, menu items, and other hard-to-find information, guests are now spending more time on their phones and computers. </span></p>
<p><span style="font-weight: 400;">If you want to engage with your customers online in their preferred medium, a messaging solution is crucial. If you want to keep control over the exact messaging, you can try out a live chat solution that lets you interact directly with customers in real time. But if you’d prefer an automated solution, then a “virtual host” (like those provided by </span><strong><a href="#" target="_blank" rel="noopener">Guestfriend</a></strong><span style="font-weight: 400;">) might be your best bet.</span></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" target="_blank" title="Alec McGuffey" rel="nofollow"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/alecmcguffeypicture.jpg" class="photo" width="80" alt="Alec McGuffey" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url" target="_blank" rel="nofollow">Alec McGuffey</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Alec McGuffey is Head of Marketing at Guestfriend, a NYC-based company that creates custom virtual hosts for restaurants. Guestfriend's virtual hosts help restaurants get more bookings by engaging with guests in real time and providing instant answers to any questions asked by guests on a restaurant's website and on platforms like Google and Facebook.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" target="_blank" title="Alec McGuffey" rel="nofollow"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/alecmcguffeypicture.jpg" class="photo" width="80" alt="Alec McGuffey" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Alec McGuffey <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Increase Engagement Online with Restaurant Messaging Tools</a><span> - June 12, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fincrease-engagement-online-with-restaurant-messaging-tools%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

