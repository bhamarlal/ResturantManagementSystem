

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Don’t Let Delivery Companies Take Advantage of Your Restaurant                            
                    </h1>

                    <span class="meta">
                      <strong class="date">May 4th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Josephine Myers</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone size-full wp-image-8782" src="<?php echo base_url();?>assets/wp-content/uploads/1-Header.png" alt="Restaurant Delivery" width="1000" height="474" /></p>
<p>Running a restaurant is tough. It requires long hours and margins are thin, but you do it because you love it. You do it because you have a special experience to offer your customers, and unique flavors to share with the community.</p>
<p>But with minimum wage going up every year, the continuing rise in the cost of goods, and the fight for traction with customers, it’s easy to feel like you’re grasping at anything to help fill those seats and get more orders out the door. So it’s understandable that you turn to companies like GrubHub, Postmates and UberEATS to try and add a little pad to the bottom line.</p>
<p>But when you look at the numbers, what seems like a solution may actually be what’s killing many small restaurants.</p>
<h2><strong>Doing the math</strong></h2>
<p>Take Postmates for instance. By the end of 2017, many restaurants reported paying a 30% commission on every Postmates delivery. In Los Angeles, UberEATS also charged 30% for the same service. For a $10 item, that’s $3 right off the top.</p>
<p>The Restaurant Report says <a href="#" target="_blank" rel="noopener"><strong>food and labor should cost restaurants between 50-75%</strong></a>. Let’s imagine your restaurant is running lean and mean at 50%, that’s $5 in food and labor costs. So far, you’ve made $2 and spent $8.</p>
<p>Remember, you haven’t taken into account expenses such as utilities, rent and spoilage. When all is said and done, you’re lucky if you make a penny or two. More likely than not, you’ve just paid someone to eat your food!</p>
<p>The story isn’t much better for the delivery app GrubHub, which will charge restaurants a base fee of 15 percent of every order plus tack on a credit card processing fee, order processing fee and delivery fee.</p>
<p>These delivery companies charge restaurants exorbitant commissions off of every customer order, when the only real the value they bring is helping new customers find your restaurant for the first time. When a customer orders again and again, it’s because your staff was friendly, the food was delicious and they had a great experience. Why should you pay Grubhub a 30% commission every time a customer orders? If the phone company took 15%, 20%, or 30% every time you took an order over the phone, you would have stopped taking phone orders a long time ago.</p>
<h2><strong>But what about marketing?</strong></h2>
<p>The argument can be made that these companies aren’t just delivering food for you, but they’re also promoting your brand to new customers. Marketing is a common selling point of these delivery companies, but requires a closer look to see how it actually impacts your restaurant. Sure, you might be featured on the delivery site, and sometimes you’re part of an email blast — there’s some marketing value to that. However, Restaurant Resource Group reports restaurants should only spend between <strong><a href="#" target="_blank" rel="noopener">3 to 6 percent of their sales</a> </strong>on marketing. That’s far less than what third-party marketplaces are charging. If the marketing exposure is what you’re after, there are less expensive options.</p>
<p>Furthermore, third-party marketplaces like Grubhub and Postmates don’t give restaurants access to their own customers’ email addresses, which makes marketing directly to your own customers virtually impossible. There’s so much value in owning your own customer’s information, so that you can encourage them to order directly from you and not pay marketplace fees time and time again for the same customer.</p>
<h2><strong>How can you fix it?</strong></h2>
<p><span style="font-weight: 400;">It’s easy to think that companies like GrubHub and Postmates are the only options out there. </span><span style="font-weight: 400;">Their sales and marketing teams have done a great job of making you think that’s the case. But there are other options. Companies are finding ways to help you reach new customers, without spending all your money on middlemen. Companies exist that offer affordable alternatives. If you’re already a ChowNow client you know the deal.</span></p>
<p><img class="alignnone size-full wp-image-8766" src="../wp-content/uploads/Family-Portrait_New.png" alt="" width="1396" height="911" /></p>
<p>ChowNow, for example, takes a fresh approach to online ordering. We build you your very own online ordering system that lets you take unlimited, commission-free orders through your website and Facebook for a flat monthly rate. And if you’re interested in getting even more new customers, ChowNow will list you on its mobile app and website, charging you only for the new customers it sends you — all repeat customer orders are commission-free.</p>
<p>The good news doesn’t stop there. ChowNow gives you access to all your customers’ email addresses and will help you build loyalty and drive re-orders through print and digital marketing campaigns that encourage those customers to order again and again. ChowNow&#8217;s powerful analytics tools help you determine which marketing plans work and what your customers like. You’ll receive all your data about your customers that you can use as your business grows.</p>
<p><img class="alignnone size-full wp-image-8783" src="../wp-content/uploads/2-Body-ChowNowApp.png" alt="ChowNow Online Ordering App" width="1000" height="445" /></p>
<p>In other words, ChowNow does many of the things delivery apps fall short of doing, and it will do it for the most restaurant-friendly rates in the industry. Delivery, is not always included in the ChowNow offering, but the separation gives you the autonomy to hire or replace, when necessary, drivers in house or through local courier services to maintain the integrity of your food in transit. If you do the math, you’re coming out ahead. $15/hour for an evening delivery driver or 30% off every order you process. ChowNow partners with local courier services all over the country to help you process orders for delivery.</p>
<p><span style="font-weight: 400;">The point is there are other options. Don’t feel tied down. Don’t feel like you need to </span><span style="font-weight: 400;">use expensive third-party delivery apps because everyone else is. It’s time to change how you do business. It’s time to stop paying companies to sell back your loyal customers to you at a 30% markup every time. It’s time to take back control of your business and your profits.</span></p>
<hr />
<p>If you&#8217;re looking for a more cost-effective option, now’s a great time to get started with ChowNow. <a href="#"><b>Get a free ChowNow demo</b></a> from one of our experts to get started today! If you’re a ChowNow restaurant client and want some ideas about how to convert your customers off these expensive third-party delivery apps, <b><a href="#">schedule a call</a> </b>— we’re happy to help.</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Hayley Thayer</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Hayley Thayer is a member of the ChowNow Marketing team. In her free time, you’ll find Hayley eating salmon sashimi, ruminating on culture and politics, and obsessing over the latest men’s haircut and clothing trends.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Hayley Thayer <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a><span> - May 4, 2018</span>				</li>				<li>					<a href="#">Mouth-Watering Menus: 4 Ways to Write Enticing Menu Descriptions</a><span> - April 2, 2018</span>				</li>				<li>					<a href="#">Why You Need to Secure Your Restaurant&#8217;s Website with SSL Right Now</a><span> - March 3, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Frestaurant-delivery-killing-restaurants&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

