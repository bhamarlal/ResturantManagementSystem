

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    How Seamlessly Online Food Delivery Platforms Are Taking Restaurants’ Orders                            
                    </h1>

                    <span class="meta">
                      <strong class="date">June 6th, 2017</strong>
                                                <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Guest Contributor Grant Turck</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone size-full wp-image-8218" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImgs-1.png" alt="grubhub" width="1000" height="474" /></p>
<p><em>Article written by Grant Turck, digital marketing strategist and restaurant advisor. Originally published December 2015.</em></p>
<p>Is your restaurant monitoring its SEO strategy when it comes to online food delivery ordering? If not, takeout aggregators like GrubHub and Caviar may be exploiting your eatery’s name and reputation to fuel their growth.</p>
<p>From mom-and-pops to national restaurant chains, online takeout ordering platforms are employing questionable business practices on a gluttonous quest for more orders. Read on to see examples and learn what you can do to protect your brand.</p>
<h2><strong>OpenTable-ization</strong></h2>
<p>A brief history lesson is in order. Back in 1998 there was this tiny start-up called OpenTable. Last year the company was <strong><a class="link-underline" href="http://www.eater.com/2014/6/13/6207641/opentable-by-the-numbers-from-launch-to-2-6-billion" target="_blank" rel="noopener noreferrer">bought</a></strong> for $2.6 billion. Not so small anymore, huh? In 2010 restauranteur Mark Pastore wrote this about their biz model:</p>
<p><em>“OpenTable has convinced restaurants to pay it substantial fees while it takes the customer relationship out of the hands of the restaurant and places control into OpenTable’s hands. Then, after having lent their names to the service, enabled OpenTable to attract online diners, and funded the construction of a powerful database of customers loyal to OpenTable, restaurants find that they themselves no longer own the customer relationship. Restaurants that want continued access to those diners now have to pay OpenTable for the privilege. This may be at the core of why many restaurateurs quietly resent OpenTable.”</em></p>
<p><strong>Lesson: </strong>A restaurant should avoid doing business with any service seeking to take the customer relationship out of the hands of the restaurant, unless the restaurant wants to become dependent on the service for survival.</p>
<p>Cut to present day and restaurants are again facing a <strong><a class="link-underline" href="http://wgbhnews.org/post/food-delivery-hits-web-restaurants-pay-price" target="_blank" rel="noopener noreferrer">similar proposition</a></strong>. Only this time it is takeout orders not reservations. With minimum wage going up, food prices going up, healthcare costs going up, and profit margins already razor-thin, restaurants can ill afford another colonization.</p>
<h2><strong>Restaurant Takeout Aggregators</strong></h2>
<p><strong>Objective:</strong> Convince restaurants to pay it significant commissions while it takes the customer relationship out of the hands of the restaurant and places control into its own hands. Sound familiar? Or as <strong><a href="https://www.trycaviar.com/for-restaurants" target="_blank" rel="noopener noreferrer">Caviar</a></strong> puts it:</p>
<p><em>&#8220;You focus on the food. We know you’re the kitchen pro, so we take care of everything but the food prep.”</em></p>
<p><strong>Customer Data: </strong>Platform owns all data it collects. Examples: customers’ name, gender, email, phone number, delivery location(s), order histories (i.e. who orders what, when, where and how), preferences, browsing histories, contacts (i.e. friends, associates, and family members) and more.</p>
<p>Platform determines who, what, where, when, why, how, and if any data collected will be used or shared for <em><strong>its</strong></em> maximum profit. Yes, the platform may share some order data with restaurants, but the platform gets to define “order data” (read the fine print).</p>
<h2 class="p1"><strong>All that Glitters is Not Gold</strong></h2>
<h3><strong>Misleading Restaurant Profiles</strong></h3>
<p>Restaurant pick-up and delivery ordering platform GrubHub creates restaurant profile webpages with search engine optimized URLs containing relevant keywords for existing restaurant locations not in business with the platform. The URL often contains the restaurant’s name, street address, and city, increasing the link’s relevance in local organic search results.</p>
<h3><strong>Examples</strong></h3>
<div class="dummy-url">www.grubhub.com/restaurant/<strong><span class="dummy-urls">california-pizza-kitchen-214-wilshire-blvd-santa-monica</span></strong>/70022</div>
<div class="dummy-url">www.grubhub.com/restaurant/<strong><span class="dummy-urls">seed-1604-pacific-ave-venice</span></strong>/71519</div>
<div class="dummy-url">www.grubhub.com/restaurant/<strong><span class="dummy-urls">smashburger-801-market-st-san-diego</span></strong>/263337</div>
<div class="dummy-url">www.grubhub.com/restaurant/<strong><span class="dummy-urls">tgi-fridays-720-town-center-dr-dearborn</span></strong>/274794</div>
<div class="dummy-url-last">www.grubhub.com/restaurant/<strong><span class="dummy-urls">bonefish-grill-2060-renaissance-park-pl-cary</span></strong>/253875</div>
<p class="p1">In many instances the profiles’ meta descriptions contain deceptive, but search-relevant text, also increasing the likelihood for each profile to rank higher in unpaid Internet search results.</p>
<p class="p1"><em>“Order delivery online from <strong>[Restaurant Name]</strong> in <strong>[City]</strong> instantly! View <strong>[Restaurant Name]</strong>‘s <strong>[Month] [Year]</strong> deals, coupons &amp; menus. Order delivery online right now or by phone from…”<br />
</em></p>
<p class="p1">-Formulaic meta description used by GrubHub (bold added)</p>
<p class="p1">The intent appears clear: trick customers into believing they can order delivery online from the restaurant in the search result via GrubHub.</p>
<h3 class="p1"><strong>Page 1 Organic Search Result Examples</strong></h3>
<h6 class="p1"><img class="alignnone wp-image-8214 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-13-at-4.05.15-PM.png" alt="Grubhub california pizza kitchen" width="535" height="96" /><br />
Google desktop search on 12/13/15<br />
(california pizza kitchen santa monica delivery)</h6>
<h6 class="p1"><img class="alignnone wp-image-8215 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-13-at-4.28.57-PM.png" alt="Grubhub seed restaurant" width="520" height="95" /><br />
Google desktop search on 12/13/15<br />
(seed venice delivery)</h6>
<h6 class="p1"><img class="alignnone wp-image-8238 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Smashburger2.png" alt="Grubhub Smashburger Search Results" width="532" height="97" /><br />
Google mobile search on 12/18/15<br />
(smashburger gaslamp delivery)</h6>
<h6 class="p1"><img class="alignnone wp-image-8216 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-13-at-6.27.52-PM.png" alt="grubhub tgi fridays search results" width="539" height="98" /><br />
Bing desktop search on 12/13/15<br />
(tgi fridays dearborn delivery)</h6>
<h6 class="p1"><img class="alignnone wp-image-8217 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-15-at-4.23.31-PM.png" alt="grubhub bonefish grill search results" width="574" height="101" /><br />
Yahoo! desktop search on 12/15/15<br />
(bonefish grill cary delivery)</h6>
<h3 class="p1"><strong>Digital Bait and Switch</strong></h3>
<p class="p1">A customer searching online for food delivery from a specific restaurant in a specific location (e.g. smashburger gaslamp delivery) is presented a search result with an explicit offer of instant gratification:</p>
<p class="p1"><em>“Order delivery online from Smashburger in San Diego instantly!”</em></p>
<p class="p1">Mere seconds later after clicking the search result link the customer learns the instant gratification offered is not actually available from Smashburger.</p>
<p class="p1">Might this offer and withdrawal of instant gratification create a negative association in the customer’s mind towards Smashburger? If so, what will the present and future cost to Smashburger’s business be from this negative association?</p>
<h3 class="p1"><strong>Now You See It, Now You Don&#8217;t</strong></h3>
<p class="p1">Although the misleading restaurant profiles are made available for indexing by web search engines, the pages are hidden from customers’ view on GrubHub’s internal site search. The result can cause turbidity in local unpaid Internet search results on Google, Yahoo! and Bing for restaurants not in business with GrubHub.</p>
<p class="p1"><img class="aligncenter wp-image-8230 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/RestrauntProfile.png" alt="Grubhub Smashburger Menu" width="1000" height="356" /></p>
<p>This profile contains deceptive statements:</p>
<p><em>“This restaurant does not appear to be taking online orders at this time.”</em></p>
<p><em>“Looks like this restaurant is closed.”</em></p>
<p><em>“Unfortunately does not accept online orders. But rejoice! There are many great places that might deliver to you.”</em></p>
<p>GrubHub’s <strong><a class="link-underline" href="http://www.grubhub.com/restaurant/seed-1604-pacific-ave-venice/71519" target="_blank" rel="noopener noreferrer">misleading profile</a></strong> for Seed in Venice, CA incorrectly lists the restaurant as “closed.” But a glance on <strong><a class="link-underline" href="http://www.seedkitchen.com/" target="_blank" rel="noopener noreferrer">Seed’s</a></strong> homepage states it is open daily 10 a.m. to 9 p.m. and offers delivery. Does GrubHub have a financial responsibility to Seed for customers who rely upon this false information and then make a purchase from a competitor on GrubHub’s platform?</p>
<h3><strong>Search Advertising</strong></h3>
<p>Online takeout ordering companies are using paid search ads featuring restaurants not in business with the platforms. These ads are displayed in search results across Google, Yahoo! and Bing. Their purpose appears to be to confuse customers who are seeking to order food delivery from the restaurant name used in the ad into visiting the respective platform.</p>
<hr />
<p class="p1">The U.S. trademarked Border Grill (Reg. No.: 2359331) is an upscale, Mexican eatery with five locations (+food truck) in Southern California and Las Vegas.</p>
<p class="p1">To build trust, the search ads often include the restaurant name in the display URL. In GrubHub’s Border Grill ad (below), a visit to <strong><a class="link-underline" href="http://www.grubhub.com/Border-Grill">www.grubhub.com/Border-Grill</a> </strong>sends one to a customized 404 error page featuring a cartoon-like naked male sitting on a couch with the accompanying text: “You called our buf-BLUFF. You called our bluff-BUFF! We wanted to put a page here, but you caught us with our pants down. That concludes our nudity jokes. Return home?”</p>
<p class="p1"><img class="alignnone wp-image-8233 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/BorderGrill_2.png" alt="Grubhub Border Grill Search Results" width="505" height="117" /></p>
<p class="p1">When the ad title is clicked, however, customers are delivered to the downtown L.A. Border Grill <strong><a class="link-underline" href="https://www.grubhub.com/restaurant/border-grill-445-south-figeroa-street-los-angeles/311860?gclid=CjwKEAiA18mzBRCo1e_-y_KLpXISJACEsANGlqZINoOPjv0XjQ8ehEdJ2-6Edyx5H7f3JGAO0WXIUBoCcYjw_wcB&amp;utm_source=google&amp;utm_medium=cpc&amp;utm_campaign=Los%20Angeles,%20CA%20%7C%20Los%20Angeles,%20CA%20%7C%20Restaurants&amp;utm_term=%2Bborder%20%2Bgrill%20%2Bdelivery&amp;efkwid=57128382370&amp;ef_id=VlJhKgAABR4D7vbk:20151218072900:s">restaurant profile</a></strong> containing no food menu.</p>
<p class="p1">Here is another example featuring Border Grill. In this GrubHub ad, the display URL <strong><a class="link-underline" href="http://grubhub.com/Border-Grill" target="_blank" rel="noopener noreferrer">grubhub.com/Border-Grill</a> </strong>also sends customers to the page with a cartoon-like naked male sitting on a couch. Click the ad title, however, and customers are delivered to the Santa Monica Border Grill <strong><a class="link-underline" href="https://www.grubhub.com/restaurant/border-grill--1445-4th-street-santa-monica/311851?utm_source=bing&amp;utm_medium=cpc&amp;utm_campaign=Los%20Angeles,%20CA%20%7C%20Santa%20Monica,%20CA%20%7C%20Restaurants&amp;utm_term=%20border%20%20grill%20%20delivery&amp;efkwid=26994650143&amp;ef_id=VlJhKgAABR4D7vbk:20151218072612:s" target="_blank" rel="noopener noreferrer">restaurant profile</a></strong> with no food menu.</p>
<p class="p1"><img class="alignnone wp-image-8237 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/BorderGrill_3.png" alt="Grubhub Border Grill Ad" width="647" height="242" /></p>
<p>Once landing on either the downtown L.A. or Santa Monica Border Grill restaurant profile, GrubHub’s goal seems to be to redirect a customer into ordering food delivery from a restaurant who is in business with the platform.</p>
<p><em>“…we do obtain authorization to use restaurants’ IP and content,”</em> said a GrubHub company spokeswoman in an emailed reply about whether the publicly-held corporation obtains written permission from all trademark holders not in business with the platform prior to its use of said trademarks in search ads.</p>
<p>It is unclear what benefit <strong><a class="link-underline" href="#" target="_blank" rel="noopener noreferrer">Border Grill</a></strong> owners Mary Sue Milliken and Susan Feniger would get out of such a one-sided arrangement, but perhaps they will enlighten us in the comments section.</p>
<hr />
<p class="p1">Border Grill and Caviar were bedfellows back in July 2014. Alas, the relationship was short-lived. It appears, however, Caviar continues to go after the restaurant group’s customers using paid search ads. Caviar did not respond to an email requesting comment on this practice.</p>
<p class="p1">In Caviar’s Border Grill ad below, an attempt to visit the display URL <strong><a class="link-underline" href="http://border-grill.trycaviar.com/" target="_blank" rel="noopener noreferrer">border-grill.trycaviar.com</a></strong> by typing it into a browser results in a “This webpage is not available” message.</p>
<p class="p1"><img class="alignnone wp-image-8236 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/BorderGrill_1-1.png" alt="Caviar Border Grill Ad" width="476" height="93" /></p>
<p class="p1">Click the ad title and customers are sent to <strong><a class="link-underline" href="https://www.trycaviar.com/t/la/border-grill-403">https://www.trycaviar.com/t/la/border-grill-403</a></strong>. This URL instantly redirects to a unique version of Caviar’s homepage containing a banner near the top of the page, and the message, “That restaurant does not exist.”</p>
<hr />
<p>GrubHub’s search ad practices also target national restaurant chains. Ever heard of Chili’s?</p>
<p><img class="alignnone wp-image-8220 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-14-at-4.29.01-PM.png" alt="grubhub chili's restaurant ad" width="466" height="152" /></p>
<p>A click on the ad title sends customers to the Chili’s West Hills, CA <strong><a class="link-underline" href="https://www.grubhub.com/restaurant/chilis--6775-fallbrook-avenue-west-hills/312190?utm_source=bing&amp;utm_medium=cpc&amp;utm_campaign=Los%20Angeles,%20CA%20%7C%20West%20Hills,%20CA%20%7C%20Restaurants&amp;utm_term=%20chili%27s%20%20west%20%20hills&amp;efkwid=26994650529&amp;ef_id=VlJhKgAABR4D7vbk:20151218074108:s" target="_blank" rel="noopener noreferrer">restaurant profile</a></strong>. The profile has no food menu. The display URL <strong><a class="link-underline" href="http://grubhub.com/Chilis" target="_blank" rel="noopener noreferrer">grubhub.com/Chilis</a></strong> generates the guy on a couch.</p>
<p>And here is another GrubHub search ad. It is for Boston Market.</p>
<h3><strong><img class="alignnone wp-image-8221 size-full" src="<?php echo base_url();?>assets/wp-content/uploads/Screen-Shot-2015-12-17-at-7.44.46-PM.png" alt="Grubhub Boston Market Ad" width="677" height="346" /></strong></h3>
<p>A click on the ad title sends customers to the Boston Market’s El Cajon, CA <strong><a class="link-underline" href="https://www.grubhub.com/restaurant/boston-market-706-fletcher-parkway-el-cajon/312357?utm_source=bing&amp;utm_medium=cpc&amp;utm_campaign=San%20Diego,%20CA%20%7C%20El%20Cajon,%20CA%20%7C%20Restaurants&amp;utm_term=%20boston%20%20market%20%20delivery&amp;efkwid=26994674041&amp;ef_id=VlJhKgAABR4D7vbk:20151218074515:s" target="_blank" rel="noopener noreferrer">restaurant profile</a></strong> on GrubHub. Here too there is no food menu. The <strong><a class="link-underline" href="http://grubhub.com/Boston-Market" target="_blank" rel="noopener noreferrer">display URL</a></strong> generates, you got it, guy on a couch.</p>
<h2>James’ Beach Case Study:<br />
How You Can Protect Your Restaurant</h2>
<p>Here is how I protected the <strong><a class="link-underline" href="http://www.jamesbeach.com/">James’ Beach</a></strong> brand online from GrubHub, DoorDash, and Postmates in my role as director of marketing and operations for its parent company Bartok, Inc.</p>
<h3><strong>Step 1: Trademark</strong></h3>
<p>Arranged for James’ Beach <strong><a href="https://www.uspto.gov/trademarks-application-process/filing-online/initial-application-forms">trademark applications</a></strong> (name and logo) to be filed with the USPTO in November 2012 and achieved registration on July 9th and July 23, 2013 respectively.</p>
<h3><strong>Step 2: Reputation Management</strong></h3>
<p>Discovered unauthorized use of James’ Beach trademarks online by GrubHub, Postmates, and DoorDash between November 2014 and January 2015 during online monitoring sessions.</p>
<h3><strong>Step 3: Cease &amp; Desist Notices</strong></h3>
<p>Located legal contact information on <strong><a class="link-underline" href="http://www.allmenus.com/terms-conditions/" target="_blank" rel="noopener noreferrer">GrubHub</a></strong>, <strong><a class="link-underline" href="https://postmates.com/terms" target="_blank" rel="noopener noreferrer">Postmates</a></strong>, and <strong><a class="link-underline" href="https://www.doordash.com/terms/" target="_blank" rel="noopener noreferrer">DoorDash</a></strong> websites and sent trademark cease and desist notices via email, fax, and snail mail until compliance was achieved.</p>
<h3><strong>Step 4: SEO Optimization</strong></h3>
<p>Reoptimized James’ Beach website for keywords like <em>delivery</em>, <em>online ordering</em>, and <em>order online</em> to improve page one organic search results for brand while waiting on compliance.</p>
<p><strong>Results:</strong> All unauthorized URLs, webpages, and meta data referencing the trademarked James’ Beach brand in connection to GrubHub, Postmates, and DoorDash was permanently removed from the Internet.</p>
<p class="p1">Let James’ Beach serve as proof to a restauranteur’s right to decide whether their restaurant’s name, reputation, and <span class="dummy-urls"><strong>customers</strong></span> can be used to grow another company’s business <span class="dummy-urls"><strong>prior</strong></span> to such use.</p>
<p class="p1">In a blog entry posted to <strong><a class="link-underline" href="https://medium.com/@mattmaloney/not-all-that-glitters-is-gold-847c81e211b#.rrmagertj" target="_blank" rel="noopener noreferrer">Medium</a></strong> last month, GrubHub’s CEO Matt Maloney claims to support similar rights. He also writes about the importance of transparency, but actions speak louder than words.</p>
<p class="p1">Good first steps? Remove the deceptive restaurant profiles from the Internet and revise your search ad practices.</p>
<p class="p1">Please be sure to share this article with your friends in the restaurant business to help educate them and others on how to protect their brands online.</p>
<p class="p1">Have you struggled to get unapproved profiles removed? If restaurants’ IP is used without permission to grow another business should it be compensated? Do you think takeout aggregators are good or bad for restaurants? Share your thoughts, questions and feedback in the comments below.</p>
<p class="p1"><em>This article was <a href="https://www.grantturck.com/how-seamlessly-online-food-delivery-platforms-are-taking-restaurants-orders/" target="_blank" rel="noopener noreferrer">originally published by Grant Turck</a> on December 21, 2015.</em></p>
<hr />
<p>If you don’t already have online ordering at your restaurant, now’s a great time to get started. <a href="#"><b>Get a free ChowNow demo</b></a> from one of our experts to get started today!</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Hayley Thayer</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Hayley Thayer is a member of the ChowNow Marketing team. In her free time, you’ll find Hayley eating salmon sashimi, ruminating on culture and politics, and obsessing over the latest men’s haircut and clothing trends.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Hayley Thayer <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a><span> - May 4, 2018</span>				</li>				<li>					<a href="../how-to-write-enticing-menu-descriptions.html">Mouth-Watering Menus: 4 Ways to Write Enticing Menu Descriptions</a><span> - April 2, 2018</span>				</li>				<li>					<a href="#">Why You Need to Secure Your Restaurant&#8217;s Website with SSL Right Now</a><span> - March 3, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-seamlessly-online-food-delivery-platforms-are-taking-restaurants-orders%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

