

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Introducing Instagram Ordering with ChowNow                            
                    </h1>

                    <span class="meta">
                      <strong class="date">May 8th, 2018</strong>
                                                <a href="<?php echo site_url('UserController/theNews') ?>" >In The News</a> <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a> <a href="<?php echo site_url('UserController/socialMediaBlog') ?>" >Social Media</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Emily Neudorf</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><img class="size-full wp-image-8786 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Header.png" alt="ChowNow Instagram Food Ordering" width="1000" height="474" /></p>
<p><span style="font-weight: 400;">Instagram has surpassed 500 million daily active users worldwide, who spend more than 32 minutes a day scrolling, liking, and posting visual content. As consumers spend more time on social media, ChowNow is innovating to ensure your restaurant can reach customers where they are. </span></p>
<p><span style="font-weight: 400;">Today we unveil ChowNow’s newest ordering channel: Instagram. ChowNow’s integration with Instagram gives your followers the ability to place a ChowNow order directly from your restaurant’s Instagram profile.</span></p>
<p><span style="font-weight: 400;">Now, you can take your Instagram followers from scrolling to ordering, with the tap of a button. Read on to learn how L.A. based restaurant HomeState has grown their business with Instagram and ChowNow — and how you can, too.</span></p>
<h1><b>HomeState’s Story</b></h1>
<p><span style="font-weight: 400;">When Briana Valdez opened HomeState in December 2013, she and her team were on a mission to bring the Tex-pat community of Los Angeles together through authentic Tex-Mex cuisine and a nostalgic atmosphere inspired by her childhood in San Antonio. From real-deal breakfast tacos made with handmade tortillas, to thoughtfully curated music, to that undeniable Texas hospitality, Briana successfully created a restaurant that felt like home to those aching for the Lone Star State, and for those simply craving community.</span></p>

		<style type='text/css'>
			#gallery-3 {
				margin: auto;
			}
			#gallery-3 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-3 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-3 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-3' class='gallery galleryid-8785 gallery-columns-3 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel4.png' title="Breakfast Tacos, Queso, and Frito Pie: staple dishes of a Texas Kitchen." data-rl_title="Breakfast Tacos, Queso, and Frito Pie: staple dishes of a Texas Kitchen." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-3"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel4.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState Flat Lay" aria-describedby="gallery-3-8790" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-3-8790'>
				Breakfast Tacos, Queso, and Frito Pie: staple dishes of a Texas Kitchen.
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel1.png' title="L.A.-based HomeState pays homage to the great state of Texas." data-rl_title="L.A.-based HomeState pays homage to the great state of Texas." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-3"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel1.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState interior" aria-describedby="gallery-3-8787" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-3-8787'>
				L.A.-based HomeState pays homage to the great state of Texas.
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel3.png' title="Fresh tortillas, made daily." data-rl_title="Fresh tortillas, made daily." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-3"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel3.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState Team" aria-describedby="gallery-3-8789" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-3-8789'>
				Fresh tortillas, made daily.
				</dd></dl><br style="clear: both" />
		</div>

<p><span style="font-weight: 400;">Since opening their first 800-square-foot location in Los Feliz, HomeState has been — quite literally — overflowing with guests. Online ordering has multiplied their potential reach and introduced an easier guest experience — allowing even more customers the opportunity to try their food and bypass the line by ordering ahead. Briana’s customers will often order with ChowNow, grab their food at the counter, and then proceed to pull up a chair. HomeState just has that effect on people: a quick to-go order turns into drinking Palomas over warm queso and good conversation with new friends.</span></p>
<p><img class="size-full wp-image-8830 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/Quote_1_Briana_Valdez.png" alt="ChowNow Instagram HomeState Briana Valdez" width="997" height="337" /></p>
<h1><b>Taking the Restaurant Experience Beyond Brick and Mortar</b></h1>
<p><span style="font-weight: 400;">Just a few years ago it used to be that you had to visit a restaurant to truly experience it. That’s not the case anymore for local restaurants like HomeState, who are growing their business in the age of storytelling and social media. HomeState’s daily Instagram posts and behind the scenes stories transport you to the restaurant. Today, HomeState has over 11,000 Instagram followers, all tuning in to explore their menu and meet the people that power it.</span></p>
<p><img class="size-full wp-image-8823 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/Quote_2-2.png" alt="ChowNow Instagram HomeState Quote 2" width="997" height="444" /></p>
<h1><b>It’s Here: ChowNow Allows Your Customers to Order from Instagram</b></h1>
<p><span style="font-weight: 400;">Now, restaurants like HomeState are taking their Instagram followers from exploration to action — by giving them the ability to place a ChowNow order directly from their Instagram profile. With ChowNow’s Instagram integration, restaurants are provisioned with a “Start Order” call-to-action button on their Instagram business profile. Mouth watering from that picture of Frito Pie? Order it in an instant. Inspired by the staff cooking up a storm in HomeState’s latest story, but can’t make it for a sit-down dinner? Tap “Start Order,” and get it for pickup or delivery.</span></p>
<p><span style="font-weight: 400;">This past March Briana opened her second HomeState location in Highland Park. While you can (and should) stop by either HomeState location to experience their unique culture and taste their food that’s truly made with love, you can (and should) explore </span><a href="#" target="_blank" rel="noopener"><b>HomeState’s Instagram</b></a><span style="font-weight: 400;"> to get a little taste in the meantime — and place an order for takeout while you’re at it.</span></p>
<p><img class="size-full wp-image-8825 alignnone" src="<?php echo base_url();?>assets/wp-content/uploads/Quote_3-7.png" alt="ChowNow Instagram HomeState Quote 3" width="1000" height="416" /></p>
<h1><b>How to Get Instagram Ordering for Your Restaurant</b></h1>
<p><span style="font-weight: 400;">If you’re a ChowNow client that has an Instagram Business Profile, you’re in luck! We’ll set you up with Instagram Ordering, at no additional cost and included in your ChowNow ordering platform.</span></p>
<p><b>For new ChowNow clients, here are a few tips to ensure you can be set up with Instagram ordering:</b></p>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;">Make sure you have a Business Profile on Instagram. </span><strong><a href="#" target="_blank" rel="noopener">Here’s how to set one up</a></strong><span style="font-weight: 400;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Go to your restaurant’s Facebook Page and link your Instagram Business Profile. </span><a href="#" target="_blank" rel="noopener"><span style="font-weight: 400;"><strong>Here’s how to connect them</strong></span></a><span style="font-weight: 400;">.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Once your Instagram Business Profile is linked to your primary Facebook Page, we’ll add a Start Order button to your Instagram, which will drive customers to your ChowNow menu. No additional cost and no additional work on your end!</span></li>
</ul>
<p><b>Own a restaurant, but not using ChowNow to take orders?</b><span style="font-weight: 400;"> You too can give your followers the ability to discover your food and order it directly through Instagram — included when you sign up for ChowNow. Get started with a free </span><a href="#" target="_blank" rel="noopener"><span style="font-weight: 400;"><strong>ChowNow product demo</strong></span></a><span style="font-weight: 400;"> today.</span></p>

		<style type='text/css'>
			#gallery-4 {
				margin: auto;
			}
			#gallery-4 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-4 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-4 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		</style>
		<div id='gallery-4' class='gallery galleryid-8785 gallery-columns-3 gallery-size-large'><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel6.png' title="Lonestar Migas: organic eggs scrambled with crispy corn strips, onion, cheese, shredded brisket and pico de gallo." data-rl_title="Lonestar Migas: organic eggs scrambled with crispy corn strips, onion, cheese, shredded brisket and pico de gallo." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel6.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState lonestar migas" aria-describedby="gallery-4-8828" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8828'>
				Lonestar Migas: organic eggs scrambled with crispy corn strips, onion, cheese, shredded brisket and pico de gallo.
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel2-1.png' title="Two warm breakfast tacos - coming right up." data-rl_title="Two warm breakfast tacos - coming right up." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel2-1.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState breakfast tacos" aria-describedby="gallery-4-8826" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8826'>
				Two warm breakfast tacos &#8211; coming right up.
				</dd></dl><dl class='gallery-item'>
			<dt class='gallery-icon landscape'>
				<a href='<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel5-1.png' title="Frito Pie in a Bag: chili con carne or black beans, cheddar, lettuce, sour cream, tomato, pickled jalapeño and pickled red onion." data-rl_title="Frito Pie in a Bag: chili con carne or black beans, cheddar, lettuce, sour cream, tomato, pickled jalapeño and pickled red onion." class="rl-gallery-link" data-rl_caption="" data-rel="lightbox-gallery-4"><img width="1280" height="720" src="<?php echo base_url();?>assets/wp-content/uploads/Instagram_Carosel5-1.png" class="attachment-large size-large" alt="ChowNow Instagram HomeState frito pie" aria-describedby="gallery-4-8827" /></a>
			</dt>
				<dd class='wp-caption-text gallery-caption' id='gallery-4-8827'>
				Frito Pie in a Bag: chili con carne or black beans, cheddar, lettuce, sour cream, tomato, pickled jalapeño and pickled red onion.
				</dd></dl><br style="clear: both" />
		</div>


                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Emily Neudorf</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Emily Neudorf is on the Marketing Team at ChowNow and loves architecture, music and of course, discovering great restaurants. She considers Chicago and Los Angeles two of the world’s finest food cities — though the quest is far from over.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Emily Neudorf <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Introducing Instagram Ordering with ChowNow</a><span> - May 8, 2018</span>				</li>				<li>					<a href="#">Why Your Restaurant Needs to Take Advantage of Customer Data</a><span> - May 2, 2018</span>				</li>				<li>					<a href="#">4 New Year’s Resolutions Every Restaurant Should Make, and How to Nail Them</a><span> - January 2, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Forder-food-on-instagram-with-chownow&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

