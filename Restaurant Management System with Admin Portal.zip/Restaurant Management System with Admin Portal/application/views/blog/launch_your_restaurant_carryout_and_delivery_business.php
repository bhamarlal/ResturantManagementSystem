

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Launch Your Restaurant Carryout and Delivery Business                            
                    </h1>

                    <span class="meta">
                      <strong class="date">August 7th, 2015</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/mobileBlog') ?>" >Mobile</a> <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a> <a href="<?php echo site_url('UserController/restaurantBlog') ?>" >Restaurant Tech</a>                     </span>

                    
                    
                    
                    
                    <div class="content">
                        <p style="text-align: justify;"><a href="<?php echo base_url();?>assets/wp-content/uploads/2014/11/customer.png" data-rel="lightbox-gallery-Uz0Td1x5" data-rl_title="" data-rl_caption="" title=""><img class=" size-full wp-image-4838 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/2014/11/customer.png" alt="customer" width="381" height="253" srcset="https://get.chownow.com/wp-content/uploads/2014/11/customer.png 381w, https://get.chownow.com/wp-content/uploads/2014/11/customer-150x99.png 150w" sizes="(max-width: 381px) 100vw, 381px" /></a></p>
<p style="text-align: justify;"> &#8212; <b>Mike Ganino | </b> <i>Mike is a restaurant veteran having served  as COO at Protein Bar and in key roles at Yum! Brands, Lettuce Entertain You, and Potbelly Sandwich Shop. An in-demand speaker and trainer on restaurant and hospitality industry, Mike advises ChowNow on developing the strongest online ordering solutions for restaurants.</i></p>
<hr />
<p>Eating on the run is no longer a luxury in today’s always moving, on-the-go world. Research from National Restaurant Association shows that ⅓ of consumers say that takeout is an essential part of their life. This trend is aimed to continue to climb with 61% of millennials saying that a restaurant’s takeout and delivery options influence their dining decisions (NRA, 2015). Isn&#8217;t it time you launched your restaurant&#8217;s carryout and delivery business?</p>
<p>Most restaurants today offer carryout as a side-option to their already busy dine-in business. It is an easy way to increase revenue without having to add a lot of extra staff. And with so many ways to reach out to consumers and take orders, it&#8217;s easier than ever to get started.</p>
<p>But what does it take to really launch a carryout business successfully? Check out our top four tips for getting your carryout business off the ground:</p>
<h2><span style="color: #ff0000;"><b>Map Your Flow</b></span></h2>
<p>As a successful restaurant, you have your systems and operation down for your regular business. You’ve optimized that experience for your guests. When you first launch the togo side of your business, take some time to do the same. Efficiency is key when customers are waiting to take your food back home. Here are some things to consider:</p>
<ul>
<li>Train your team on the new offering. Make a quick checklist for all the things they will need to know to execute togo business, and then check each employee off as you train them.</li>
<li>Set-up an area in your restaurant to stage and store togo orders. A counter near the phone/register is great. The end of the bar can work too. Also ensure that packaging and supplies are within easy reach of the kitchen and/or expo counter. Save your team from having to hunt down a togo box in the heat of the moment.</li>
<li>Use a Disney technique and map out the entire order from start to finish. Disney calls this “storyboarding,” I call it smart systems design. Take a journey from “order” to “customer’s dining room table” and make sure each step along the way has clarity and greatness.</li>
</ul>
<h2 style="text-align: justify;"><span style="color: #ff0000;"><b>Accuracy First</b></span></h2>
<p>If you check out most complaints about togo business from customers, the number one issue is accuracy. They simply didn’t get exactly what they ordered. And really&#8211;what’s more frustrating than getting home to realize  you don’t have the right food that you’ve paid for? Create a “Recipe for Order Accuracy” to ensure that when the customers they leave, they have exactly what they want. Here is one I’ve adopted over the years from my friends at <a href="#">Zingerman’s</a> in Ann Arbor:</p>
<ol>
<li>Confirm that the ticket is accurate when it hits the kitchen</li>
<li>Double check at the expo/togo counter &amp; have that team member initial it</li>
<li>Ensure the order when the customer gets there by confirming each item in the bag with them</li>
</ol>
<h2><span style="color: #ff0000;"><b>Package Like a Pro</b></span></h2>
<p>You are plating like Picasso in your restaurant&#8211;but how does your food look after it’s been boxed up and arrives at your customer’s home? Here are a few things to keep in mind to ensure you package like a pro:</p>
<ul>
<li>Find sturdy packaging that can make the trip.</li>
<li>Get a few samples from your vendor and actually package your food up and bring it home with you. Nothing like a real case study to help you decide what works.</li>
<li>Does it match your brand and price point? See how close you can match your brand colors, look, and feel without breaking the bank.</li>
<li>Stickers and stamps are an affordable way to add a branded element to your packaging.</li>
</ul>
<p><span style="color: #ff0000;"><b>Don’t Be The Secret Service</b></span></p>
<p>Many restaurants don’t do much to tell their customers about their carryout options in an effective way. Why not? It’s a great convenience for many of your guests for the times when they aren’t looking for a night out. So, don’t keep your offering a secret!</p>
<ul>
<li>Feature your to-go options prominently on your website.</li>
<li>Include a first-time discount for online orders.</li>
<li>Use attractive stickers on your “doggie bags” to share the offering.</li>
<li>Get the word out on social. Change the links in your profiles and bios to take customers directly to your online ordering page.</li>
<li>Get a mobile app that allows for online ordering.</li>
</ul>
<p>If you are looking to launch a lucrative and exciting offering to your customers, check out the offerings from ChowNow. Get your very own online ordering built into your site and a mobile app that&#8217;s branded just for you, and their marketing and sales expertise is included in the package to make sure you launch big. <a href="#" target="_blank" rel="noopener">Set-up a demo today to start boosting your business. </a></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Mike Ganino"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/mikeg.jpg" class="photo" width="80" alt="Mike Ganino" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Mike Ganino</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Mike is the Head of People and Culture at ChowNow. He is a restaurant veteran having served as COO at Protein Bar and in key roles at Yum! Brands, Lettuce Entertain You, and Potbelly Sandwich Shop. With over 100 restaurant openings under his belt, he knows what it takes to succeed in this industry.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Mike Ganino"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/mikeg.jpg" class="photo" width="80" alt="Mike Ganino" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Mike Ganino <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">5 Restaurant Recruiting Tips for Hiring an All-Star Staff</a><span> - March 8, 2018</span>				</li>				<li>					<a href="#">The Pre-Shift Game Every GM Should Play to Increase Restaurant Sales</a><span> - January 27, 2017</span>				</li>				<li>					<a href="#">Back to the Future: Restaurant Technology Edition</a><span> - October 21, 2015</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Flaunch_your_restaurant_carryout_and_delivery_business&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

