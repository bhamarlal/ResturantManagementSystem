

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    4 Ways to Promote Your Digital Dining                            
                    </h1>

                    <span class="meta">
                      <strong class="date">July 6th, 2016</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/mobileBlog') ?>" >Mobile</a> <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a>                     </span>

                    
                    
                    
                    
                    <div class="content">
                        <p><img class="alignnone size-full wp-image-7418" src="<?php echo base_url();?>assets/wp-content/uploads/4-Ways-to-Promote-Your-Digital-Dining.jpg" alt="4 Ways to Promote Your Digital Dining" width="4104" height="2736" /></p>
<p><span style="font-weight: 400;">Everyone is online these days – and so is your business. With the online ordering revolution under way, it’s only a matter of time before your customers want to enjoy your food from the comfort of their homes. Having your website optimized and your mobile app ready is just the first step. Now you have to get the word out and let your customers – new and old – know that they can order from your business and have it served up right to them, for a great digital dining experience.</span></p>
<p><span style="font-weight: 400;">Check out these four tips on how to let your customers know about your digital dining services. </span></p>
<h2>1. Yelp</h2>
<p><span style="font-weight: 400;">Yelp is a must for restaurants and food service businesses. Not only are customers flocking to Yelp to find cool to places to dine, it’s become a one-stop shop for information on your business. Menus, hours and details like whether you take reservations and have online ordering should be readily available for customers.</span></p>
<p><b>Pro Tip:</b><span style="font-weight: 400;"> Do an audit of your business’s Yelp profile every week and make necessary changes. In addition to adding your most up-to-date information, you can also allow customers to place orders from your website through Yelp as an additional channel.</span></p>
<h2>2. In-Store Activations</h2>
<p><span style="font-weight: 400;">Patrons that are dining at your restaurant are the perfect place to start to gain online orders. They have already experienced your cuisine and by simply adding table cards and placards on your registers you can let them know they can enjoy it from their homes as well.</span></p>
<p><b>Pro Tip:</b><span style="font-weight: 400;"> Adding incentives like $10 off your first online order can let customers know that online ordering is available and strongly encouraged!   </span></p>
<h2>3. Facebook Ordering</h2>
<p><span style="font-weight: 400;">Similar to Yelp, customers are using social media and social proof to find new places to dine and keep up with their favorite spots. Adding social ordering to your business’s Facebook page puts your new feature right in front of your loyal customers and fans and allows them to order right from their feeds. </span><a href="#"><span style="font-weight: 400;">ChowNow</span></a><span style="font-weight: 400;"> allows for Facebook ordering and manages all of your digital dining orders through a seamless interface and tablet.</span></p>
<p><b>Pro Tip:</b><span style="font-weight: 400;"> Write and schedule regular status updates promoting online ordering as well as promotions, discounts and coupon codes.</span></p>
<h2>4. Search</h2>
<p><span style="font-weight: 400;">Search is a natural fit for not only letting your customers and potential customers know about your online ordering but also just about your restaurant in general. Advertising on Google, Yahoo and Bing, puts your business in front of thousands of people searching for what to eat.  Location targeting brings consumers local results and when your business is displayed, you can add copy to let people know they can also order online.</span></p>
<p><b>Pro Tip:</b><span style="font-weight: 400;"> When creating campaigns, make sure you have a corresponding Google Business Page, so that it can also be displayed in the search results. </span></p>
<p>Customers are savvy and ordering online more than ever. As a service business, touting your features and ease of online ordering is key. Giving customers incentives for using your app or ordering from your website encourages loyalty and lets them know you have their interests – and appetites – at heart.</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Hayley Thayer</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Hayley Thayer is a member of the ChowNow Marketing team. In her free time, you’ll find Hayley eating salmon sashimi, ruminating on culture and politics, and obsessing over the latest men’s haircut and clothing trends.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Hayley Thayer"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/hayley%20(1).jpg" class="photo" width="80" alt="Hayley Thayer" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Hayley Thayer <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Don’t Let Delivery Companies Take Advantage of Your Restaurant</a><span> - May 4, 2018</span>				</li>				<li>					<a href="#">Mouth-Watering Menus: 4 Ways to Write Enticing Menu Descriptions</a><span> - April 2, 2018</span>				</li>				<li>					<a href="#">Why You Need to Secure Your Restaurant&#8217;s Website with SSL Right Now</a><span> - March 3, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2F4-ways-to-promote-online-ordering&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

