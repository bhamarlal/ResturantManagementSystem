

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Tips To Convert Customers That Discover You Online                            
                    </h1>

                    <span class="meta">
                      <strong class="date">August 11th, 2015</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/mobileBlog') ?>" >Mobile</a> <a href="<?php echo site_url('UserController/socialMediaBlog') ?>" >Social Media</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Emily Neudorf</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><a href="<?php echo base_url();?>assets/wp-content/uploads/2015/08/Customer-Mobile-Search.png" data-rel="lightbox-gallery-wbYQ4Gqn" data-rl_title="" data-rl_caption="" title=""><img class=" size-medium wp-image-5875 aligncenter" src="<?php echo base_url();?>assets/wp-content/uploads/2015/08/Customer-Mobile-Search-650x435.png" alt="Customer Mobile Search" width="650" height="435" srcset="https://get.chownow.com/wp-content/uploads/2015/08/Customer-Mobile-Search-650x435.png 650w, https://get.chownow.com/wp-content/uploads/2015/08/Customer-Mobile-Search-150x100.png 150w, https://get.chownow.com/wp-content/uploads/2015/08/Customer-Mobile-Search-1024x685.png 1024w, https://get.chownow.com/wp-content/uploads/2015/08/Customer-Mobile-Search.png 1117w" sizes="(max-width: 650px) 100vw, 650px" /></a></p>
<hr />
<p><span style="font-weight: 400;">70% of consumers use smartphones or tablets today, according to the National Restaurant Association’s </span><i><span style="font-weight: 400;">Restaurant Industry 2015: Technology Trends</span></i><span style="font-weight: 400;"> report. With a mobile device within arm’s reach, everyone’s a bona fide researcher.</span></p>
<p>We learned at Connect Mobile Innovation Summit last year that mobile searches related to restaurants have a 90% conversion rate. Meaning, when someone is looking for you, they’re ready to be your customer.</p>
<p><span style="font-weight: 400;">The question for you as a restaurant owner then becomes, “what am I doing to make sure </span><i><span style="font-weight: 400;">I’m</span></i><span style="font-weight: 400;"> ready for them?”</span></p>
<p><span style="font-weight: 400;">Here are four popular discovery outlets where customers are searching for and finding your restaurant online, and how to make sure you’re set up to convert their </span><i><span style="font-weight: 400;">search</span></i><span style="font-weight: 400;"> into a </span><i><span style="font-weight: 400;">transaction </span></i><span style="font-weight: 400;">— whether it be an email newsletter signup, a dine-in reservation, or an online to-go order.</span></p>
<p><b>1. <span style="text-decoration: underline;">Yelp</span></b><b>:</b><span style="font-weight: 400;"> Consumers generally search on Yelp to help narrow down their decision, or to get an opinion on a spot before trying it out. Start by </span><a href="#"><span style="font-weight: 400;">claiming</span></a><span style="font-weight: 400;"> your Yelp page to ensure your business info is accurate. From there, upload your menu and some great looking photos of your best dishes to pique the interest of customers that find you there.</span></p>
<p>&nbsp;</p>
<ul>
<li><b>Tip:</b><span style="font-weight: 400;"> To monetize your Yelp page, you can add on features like reservations and online ordering, which will allow your visitors to make a transaction right then and there.</span></li>
</ul>
<p>&nbsp;</p>
<p><b>2. <span style="text-decoration: underline;">Facebook</span></b><b>:</b><span style="font-weight: 400;"> Consumers can get to know your restaurant and your regulars in a social setting via your Facebook page. If you don’t have a Facebook page set up, follow </span><a href="#"><span style="font-weight: 400;">these steps</span></a><span style="font-weight: 400;"> to get started. We recommend focusing on posts that contain images (of your food and atmosphere), linking to your restaurant’s website in each post, and adding a “Facebook feed” to your website once you’ve built a following.</span></p>
<p>&nbsp;</p>
<ul>
<li><b>Tip:</b><span style="font-weight: 400;"> Make your Facebook page a </span><i><span style="font-weight: 400;">transactional</span></i><span style="font-weight: 400;"> platform by posting a link to a secure fill-out form where visitors can share their email address. Each time you collect a new subscription, email the customer a thank-you discount to get them to come in for a visit or place an order online.</span></li>
</ul>
<p>&nbsp;</p>
<p><b>3. <span style="text-decoration: underline;">Google</span></b><b>:</b><span style="font-weight: 400;"> Consumers that Google your restaurant name from their mobile device will see a section containing all of the need-to-knows about your business. Use </span><a href="#"><span style="font-weight: 400;">Google My Business</span></a><span style="font-weight: 400;"> (for free) to manage your business information that shows up in their search results.</span></p>
<p>&nbsp;</p>
<ul>
<li><b>Tip:</b><span style="font-weight: 400;"> If you have, or are thinking about, an online ordering or booking system, you can turn customers’ searches into dollar signs by going into your Google My Business dashboard and </span><a href="#"><span style="font-weight: 400;">enabling order/appointments</span></a><span style="font-weight: 400;">. Google will connect with your existing systems and a “Place an order” link will appear for the customer in their search results.</span></li>
</ul>
<p>&nbsp;</p>
<p><b>4. <span style="text-decoration: underline;">Food Blogs</span></b><b>:</b><span style="font-weight: 400;"> Word of mouth is oldest form of discovery. Today there is a network of “influencers” on both a national and local level. Get to know your local food writers, invite them in to try a new menu item, and let them do what they do best — spread the word about your concept in a spotlight or blog post. Ask that they include a link back to your restaurant’s website, and make sure your website is ready for the new traffic.</span></p>
<p>&nbsp;</p>
<ul>
<li><b>Tip:</b><span style="font-weight: 400;"> Work with your webmaster to make sure your website is mobile-optimized, you have a mailing list widget on your home page, and your online ordering button is placed prominently so it’s easy for new visitors to learn about you and take some type of action that will grow your business.</span></li>
</ul>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">ChowNow’s partner network allows you to add direct online ordering to your Yelp, Facebook, Google, and more. So when a customer finds your restaurant in their search — you’re ready for business. </span></p>
<p>&nbsp;</p>
<p><em><a href="#"><span style="font-weight: 400;">Click here</span></a><span style="font-weight: 400;"> to get a free ChowNow product demo.</span></em></p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Emily Neudorf</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Emily Neudorf is on the Marketing Team at ChowNow and loves architecture, music and of course, discovering great restaurants. She considers Chicago and Los Angeles two of the world’s finest food cities — though the quest is far from over.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Emily Neudorf <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Introducing Instagram Ordering with ChowNow</a><span> - May 8, 2018</span>				</li>				<li>					<a href="#">Why Your Restaurant Needs to Take Advantage of Customer Data</a><span> - May 2, 2018</span>				</li>				<li>					<a href="#">4 New Year’s Resolutions Every Restaurant Should Make, and How to Nail Them</a><span> - January 2, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fhow-to-convert-online-search-customers&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

