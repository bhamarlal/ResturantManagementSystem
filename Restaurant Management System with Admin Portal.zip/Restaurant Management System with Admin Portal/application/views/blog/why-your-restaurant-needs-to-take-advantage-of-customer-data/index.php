

    <div class="main">

<div class="page">
    <div class="container">
        <div class="blog single" id="page-blog" style="text-align:left;">
            <div class="single">
                                <div class="entry">
                    <a href="<?php echo site_url('UserController/blog');?>" id="btn-backBlog">&larr; Back to Blog<span></span></a>

                    <h1>
                                                    Why Your Restaurant Needs to Take Advantage of Customer Data                            
                    </h1>

                    <span class="meta">
                      <strong class="date">May 2nd, 2018</strong>
                                                <a href="<?php echo site_url('UserController/marketingBlog') ?>" >Marketing</a> <a href="<?php echo site_url('UserController/onlineBlog') ?>" >Online Ordering System</a>                     </span>

                                            <span class="meta2"><span class="author">Written by Jason Untracht</span></span>
                    
                    
                    
                    
                    <div class="content">
                        <p><span style="font-weight: 400;"><img class="alignnone size-full wp-image-8343" src="<?php echo base_url();?>assets/wp-content/uploads/HeroImgs-6.png" alt="restaurant retention" width="1000" height="474" /></span></p>
<p><span style="font-weight: 400;">It&#8217;s undeniable that online ordering is revolutionizing the restaurant industry, with <strong><a href="#" target="_blank" rel="noopener">60% of consumers ordering delivery or takeout at least once a week</a></strong>. And while the sheer convenience of online ordering will lead to larger ticket sizes and increased order </span>frequency at your restaurant, it’s having access to the customer ordering data that will create the most value for your business.</p>
<p><span style="font-weight: 400;">Collecting customer data (e.g., names, email addresses, order history, etc.) for orders placed through your online ordering platform gives you the insights needed to retain your hard-earned customers. Unfortunately some online ordering systems withhold this information from their restaurant partners (we’re looking at you, Grubhub).</span></p>
<p><span style="font-weight: 400;">Read on to uncover exactly why harnessing your customer data is the secret sauce to realizing the full potential of your to-go business.</span></p>
<h2><strong>Data is hard to come by these days.</strong></h2>
<p><span style="font-weight: 400;">While it may seem like a no-brainer that your restaurant should have full access to information about your </span><i><span style="font-weight: 400;">own</span></i><span style="font-weight: 400;"> customers, many online ordering companies, like Grubhub and Eat24, withhold this information from their restaurant partners. </span></p>
<p><span style="font-weight: 400;">So, why do these online ordering companies want to keep your customer data for themselves? The answer is simple: They market other restaurants to your customers — sending them to businesses that pay out higher commissions.</span></p>
<p><span style="font-weight: 400;">If you’re in the market to partner with an online ordering company, make sure you choose one that gives you full access to all your customer details. If you’re already a ChowNow client, you know that customer contacts, as well as advanced analytics and reporting, are automatically gathered for you — available anytime in your <a href="#"><strong>ChowNow Dashboard.</strong></a></span></p>
<h2><strong>Why does data matter?</strong></h2>
<h3><strong>Data helps you understand your customers.</strong></h3>
<h2><img class="alignnone size-full wp-image-8346" src="<?php echo base_url();?>assets/wp-content/uploads/Body_Customers-1.png" alt="customer in restaurant" width="1000" height="445" /></h2>
<p><span style="font-weight: 400;">Uncovering core information about your customer’s ordering behavior and grouping them into audience segments is essential for executing effective marketing campaigns down the line. </span><span style="font-weight: 400;">We’ve all heard of the 80/20 rule &#8211; the vast majority of your revenue comes from a minority of your customers that are the most loyal, so understanding who these customers are will allow you to focus your marketing efforts accordingly. </span></p>
<p>Consider this:</p>
<ul>
<li><span style="font-weight: 400;">You might have a core group of loyal customers who order the same thing from your restaurant 3 times a week. </span></li>
<li><span style="font-weight: 400;">There may be a body of customers who have eaten at your restaurant once and have never come back.</span></li>
<li><span style="font-weight: 400;">Some customers order religiously through your website, while others order on mobile when they&#8217;re on the go.</span></li>
</ul>
<p><span style="font-weight: 400;">Understanding who your customers are allows you to use specific, tailored messages that are relevant to your customers. ChowNow helps restaurants understand their customer profiles by providing a Dashboard that stores online and mobile customer information — complete with order history, contact info, analytics and reporting capabilities.</span></p>
<h3><strong>Data helps you retain your customers.</strong></h3>
<p>Getting customers to come back to your restaurant again and again requires a solid marketing strategy, and a solid marketing strategy is fueled by data. With an understanding of who your customers are, you can create personalized email marketing campaigns that allow you to influence their purchasing decisions with things like promo codes, new menu items, special discounts, restaurant event information, and more.</p>
<p><strong>Imagine this</strong>: Based on the customer profiles you&#8217;ve uncovered by digging into your customer data, you start sending one email per month to your customers, offering them incentives to come back into your restaurant. Your loyal customers become brand advocates and your one-time customers become loyal regulars — all groups spend more money and order more often.</p>
<p><img class="alignnone size-full wp-image-8345" src="<?php echo base_url();?>assets/wp-content/uploads/Body_EmailMarketing.png" alt="restaurant marketing" width="1000" height="445" /></p>
<p>We recommend signing up for <strong><a href="#">Mailchimp</a></strong> or utilizing ChowNow&#8217;s ongoing email marketing programs that take care of the heavy lifting. If you&#8217;re looking for more information about how to kickstart a data-driven email program, read our <a href="#" target="_blank" rel="noopener"><strong>Restaurant Guide: Email Marketing Made Easy</strong></a>.</p>
<p>Using customer data to make informed business decisions and dictate smart and effective marketing campaigns, is frankly what is separating the most successful restaurants from restaurants on the brink of shutting their doors. If you don’t already have online ordering at your restaurant and want to harness the power of your customer data, now’s a great time to get started. <a href="#"><b>Get a free ChowNow demo</b></a> from one of our experts to get started today! If you’re a ChowNow restaurant client and want some ideas about how to best use your customer data, <b><a href="#">schedule a call</a> </b>— we’re happy to help.</p>

                         <div class="abh_box abh_box_down abh_box_business"><ul class="abh_tabs"> <li class="abh_about abh_active"><a href="#abh_about">About</a></li> <li class="abh_posts"><a href="#abh_posts">Latest Posts</a></li></ul><div class="abh_tab_content"><section class="vcard abh_about_tab abh_tab" style="display:block"><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h3 class="fn name" ><a href="#" class="url">Emily Neudorf</a></h3><div class="abh_job" ></div><div class="description note abh_description" >Emily Neudorf is on the Marketing Team at ChowNow and loves architecture, music and of course, discovering great restaurants. She considers Chicago and Los Angeles two of the world’s finest food cities — though the quest is far from over.</div></div> </section><section class="abh_posts_tab abh_tab" ><div class="abh_image"><a href="#" class="url" title="Emily Neudorf"><img src="<?php echo base_url();?>assets/wp-content/uploads/gravatar/emily.jpg" class="photo" width="80" alt="Emily Neudorf" /></a></div><div class="abh_social"> </div><div class="abh_text"><h4 >Latest posts by Emily Neudorf <span class="abh_allposts">(<a href="#">see all</a>)</span></h4><div class="abh_description note" ><ul>				<li>					<a href="#">Introducing Instagram Ordering with ChowNow</a><span> - May 8, 2018</span>				</li>				<li>					<a href="#">Why Your Restaurant Needs to Take Advantage of Customer Data</a><span> - May 2, 2018</span>				</li>				<li>					<a href="#">4 New Year’s Resolutions Every Restaurant Should Make, and How to Nail Them</a><span> - January 2, 2018</span>				</li></ul></div></div> </section></div> </div>
                        <iframe src="http://www.facebook.com/plugins/like.php?href=%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20https%3A%2F%2Fget.chownow.com%2Fblog%2Fwhy-your-restaurant-needs-to-take-advantage-of-customer-data%2F&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width=450&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20share=true&amp;height=20&amp;"
                            scrolling="no" frameborder="0"
                            style="border:none; overflow:hidden; width:100%; height:20px;"
                            allowTransparency="true"></iframe>
                    </div>

                    
                    
                    <hr/>

                    <div class="comments">
                        [fbcomments width="670" linklove="0" countmsg="Comments"]                    </div>

                </div>
                            </div>
        </div>
    </div>
</div>

    <div class="blog__pagination">
        <div class="container">
            <div class="blog__pagination__wrap">
                <ul>
                    <li class="previous"><a href="#" class="common-button pill red slim">Previous<span></span></a></li>
                    <li class="next"><a href="#" class="common-button pill red slim">Next<span></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>

